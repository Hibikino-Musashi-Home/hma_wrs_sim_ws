/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_phase.h
 * @defgroup phase phaseモジュール
 */
#ifndef __TARP_PHASE_H__
#define __TARP_PHASE_H__

#include "tarp3/tarp_psqp.h"
#include "tarp3/tarp_robot.h"
#include "tarp3/tarp_track.h"
#include "tarp3/tarp_strap.h"

/**
 * @ingroup phase
 * @brief 拘束条件を適用する時間区間を管理するクラス
 */
typedef struct {

    /** 名前 */
    char name[256];

    /** robot */
    tarp_robot_t* robot;

    /** 経過時間 [s]*/
    double tick;

    /** 経過時間 [s]*/
    double time;

    /** motor list */
    tarp_list_t* motor_list;

    /** strap list */
    tarp_list_t* strap_list;

    /** rivet list */
    tarp_list_t* rivet_list;

    /** 変数ベクトル(速度) */
    tarp_matrix_t* value_1;

    /** 変数ベクトル(加速度) */
    tarp_matrix_t* value_2;

} tarp_phase_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_phase.c */
tarp_phase_t *tarp_phase_create(void);
void tarp_phase_delete(tarp_phase_t *self);
void tarp_phase_set_robot(tarp_phase_t *self, tarp_robot_t *robot);
tarp_robot_t *tarp_phase_get_robot(tarp_phase_t *self);
void tarp_phase_push_rivet(tarp_phase_t *self, tarp_rivet_t *rivet);
void tarp_phase_push_strap(tarp_phase_t *self, tarp_strap_t *strap);
void tarp_phase_update_jacob(tarp_phase_t *self);
void tarp_phase_update_motor_list(tarp_phase_t *self, double step, double tick);
int tarp_phase_update_strap_list(tarp_phase_t *self, double step, double tick);
int tarp_phase_update_rivet_list(tarp_phase_t *self, double step, double tick);
void tarp_psqp_check_calc_time(int init);
void tarp_phase_calc_time(int init);
void tarp_jacob_calc_time(int init);
int tarp_phase_solve(tarp_phase_t *self, double step);
void tarp_phase_update(tarp_phase_t *self, double step, double tick);
void tarp_phase_print(tarp_phase_t *self, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_PHASE_H__ */

