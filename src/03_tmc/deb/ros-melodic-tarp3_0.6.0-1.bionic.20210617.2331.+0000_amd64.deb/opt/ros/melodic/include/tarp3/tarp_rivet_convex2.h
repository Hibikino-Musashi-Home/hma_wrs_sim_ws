/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_rivet_convex2.h
 *
 * 2つの関節の複合角可動範囲を避けるタスク
 */

#ifndef __TARP_RIVET_CONVEX2_H__
#define __TARP_RIVET_CONVEX2_H__

#include "tarp3/tarp_rivet.h"
#include "tarp3/tarp_limit.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t    base;

    /** 対象joint-1 */
    tarp_joint_t*   joint_1;

    /** 対象frame-2 */
    tarp_joint_t*   joint_2;

    /** 2次元凸包 */
    tarp_convex2_t* convex2;

    /** 上下限の計算 */
    tarp_limit_t*   limit;

    /** 変位の目標値 */
    double          ref_dis;

    /** 躍度の目標値 */
    double          ref_jrk;

    /** 変位の目標値下限 */
    double          ref_dis_min;

    /** 変位の目標値上限 */
    double          ref_dis_max;

    /** 変位の現在値 */
    double          act_dis;

    /** 速度の現在値 */
    double          act_vel;

    /** 加速度の現在値 */
    double          act_acc;

    /** 躍度の入力値 */
    double          act_jrk;

    /** 躍度の下限 */
    double          act_jrk_min;

    /** 躍度の上限 */
    double          act_jrk_max;

} tarp_rivet_convex2_t;

/* tarp_rivet_convex2.c */
tarp_rivet_convex2_t *tarp_rivet_convex2_create(void);
void tarp_rivet_convex2_delete(tarp_rivet_convex2_t *self);
void tarp_rivet_convex2_update(tarp_rivet_convex2_t *self, double step, double tick);
void tarp_rivet_convex2_update_jacob(tarp_rivet_convex2_t *self, int numb);
void tarp_rivet_convex2_update_other(tarp_rivet_convex2_t *self);
void tarp_rivet_convex2_print(tarp_rivet_convex2_t *self, FILE *fptr);

#endif /* __TARP_RIVET_CONVEX2_H__ */
