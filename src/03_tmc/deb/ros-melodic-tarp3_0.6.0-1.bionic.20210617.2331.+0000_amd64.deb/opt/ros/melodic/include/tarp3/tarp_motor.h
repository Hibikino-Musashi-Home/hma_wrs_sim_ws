/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor.h
 *  @defgroup motor motor モジュール
 *
 */

#ifndef __TARP_MOTOR_H__
#define __TARP_MOTOR_H__

#include "tarp3/tarp_motor_x.h"
#include "tarp3/tarp_motor_robot_pos.h"
#include "tarp3/tarp_motor_robot_rot.h"
#include "tarp3/tarp_motor_joint.h"
#include "tarp3/tarp_track.h"

/* tarp_motor.c */
void tarp_motor_init(tarp_motor_t *self, int type);
void tarp_motor_exit(tarp_motor_t *self);
void tarp_motor_update(tarp_motor_t *self, double step, double tick);
void tarp_motor_update_track_list(tarp_motor_t *self, double step, double tick);
void tarp_motor_print(tarp_motor_t *self, FILE *fptr);

#endif /* __TARP_MOTOR_H__ */
