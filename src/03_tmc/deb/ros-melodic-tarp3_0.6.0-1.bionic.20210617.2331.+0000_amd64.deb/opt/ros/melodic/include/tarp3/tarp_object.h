/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_object.h
 *  オブジェクト用メモリ領域管理ルーチン。リアルタイム対応。
 */

#ifndef __TARP_OBJECT_H__
#define __TARP_OBJECT_H__

void    tarp_object_init (void* memory, int size);
void    tarp_object_debug (void);
int     tarp_object_check (void);
void*   tarp_object_create (int size);
void*   tarp_object_resize (void* self, int size);
void    tarp_object_delete (void* self);

#endif /* __TARP_OBJECT_H__ */
