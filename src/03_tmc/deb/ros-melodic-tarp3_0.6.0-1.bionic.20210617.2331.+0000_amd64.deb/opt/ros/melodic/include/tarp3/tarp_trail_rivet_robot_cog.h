/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_robot_cog.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_ROBOT_COG_H__
#define __TARP_TRAIL_RIVET_ROBOT_COG_H__

#include "tarp3/tarp_trail_rivet.h"

typedef struct {

    tarp_trail_rivet_t base;

    /** 方向ベクトル */
    tarp_vector3_t  axis;

    double ref_dis;
    int ref_dis_indx;

    double ref_vel;
    int ref_vel_indx;

    double ref_acc;
    int ref_acc_indx;

    double act_dis;
    int act_dis_indx;

    double act_vel;
    int act_vel_indx;

    double act_acc;
    int act_acc_indx;

} tarp_trail_rivet_robot_cog_t;

/* tarp_trail_rivet_robot_cog.c */
tarp_trail_rivet_robot_cog_t *tarp_trail_rivet_robot_cog_create(void);
void tarp_trail_rivet_robot_cog_delete(tarp_trail_rivet_robot_cog_t *self);
void tarp_trail_rivet_robot_cog_update(tarp_trail_rivet_robot_cog_t *self, double step, double tick);
void tarp_trail_rivet_robot_cog_print(tarp_trail_rivet_robot_cog_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_ROBOT_COG_H__ */
