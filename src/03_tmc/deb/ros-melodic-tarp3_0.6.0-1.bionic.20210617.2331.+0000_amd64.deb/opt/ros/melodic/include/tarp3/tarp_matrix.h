/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_matrix.h
 * @brief 行列ライブラリのヘッダファイル
 * @defgroup matrix
 */
#ifndef __MATRIX_H__
#define __MATRIX_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @ingroup matrix
 * @brief 行列クラス
 */
typedef struct {

    /** 行の数 */
    int row;

    /** 列の数 */
    int col;

    /** データ領域 */
    double* data;

} tarp_matrix_t;

/**
 *  @brief  行列の要素にアクセスするためのマクロ
 *
 */
#define MATRIX(m, r, c) (m->data[(r)*(m->col)+(c)])

/* ../../src/tarp_matrix.c */
tarp_matrix_t *tarp_matrix_create(int row, int col);
int tarp_matrix_is_equal(tarp_matrix_t *A, tarp_matrix_t *B);
int tarp_matrix_is_near(tarp_matrix_t *A, tarp_matrix_t *B, double e);
void tarp_matrix_delete(tarp_matrix_t *M);
void tarp_matrix_swap(tarp_matrix_t *A, tarp_matrix_t *B);
int tarp_matrix_copy(tarp_matrix_t *A, int ra, int ca, tarp_matrix_t *B, int rb, int cb, int row, int col);
void tarp_matrix_copy_zero(tarp_matrix_t *A, int ri, int ci, int rs, int cs);
void tarp_matrix_copy_unit(tarp_matrix_t *A, int ri, int ci, int rs, int cs);
void tarp_matrix_copy_args(tarp_matrix_t *A, int row, int col, ...);
int tarp_matrix_crop(tarp_matrix_t *A, tarp_matrix_t *B, int rb, int cb, int row, int col);
tarp_matrix_t *tarp_matrix_create_from_string(int row, int col, char *str);
tarp_matrix_t *tarp_matrix_create_from_argments(int row, int col, ...);
tarp_matrix_t *tarp_matrix_create_from_matrix(int row, int col, tarp_matrix_t *A, int ri, int ci);
tarp_matrix_t *tarp_matrix_duplicate(tarp_matrix_t *A);
int tarp_matrix_copy_array(tarp_matrix_t *A, double *array);
double tarp_matrix_max_abs(tarp_matrix_t *A);
double tarp_matrix_min_abs(tarp_matrix_t *A);
double tarp_matrix_max(tarp_matrix_t *A);
double tarp_matrix_min(tarp_matrix_t *A);
void tarp_matrix_scale(tarp_matrix_t *Ma, tarp_matrix_t *Mb, double c);
int tarp_matrix_add_matrix(tarp_matrix_t *A, tarp_matrix_t *B, tarp_matrix_t *C);
int tarp_matrix_sub_matrix(tarp_matrix_t *A, tarp_matrix_t *B, tarp_matrix_t *C);
int tarp_matrix_mul(tarp_matrix_t *A, tarp_matrix_t *B, tarp_matrix_t *C);
tarp_matrix_t *matrix_create_transpose_mul(tarp_matrix_t *A, tarp_matrix_t *B);
int tarp_matrix_transpose_mul(tarp_matrix_t *A, tarp_matrix_t *B, tarp_matrix_t *C);
int tarp_matrix_copy2(tarp_matrix_t *A, const tarp_matrix_t *B);
tarp_matrix_t *tarp_matrix_create_transpose(tarp_matrix_t *An);
int tarp_matrix_transpose(tarp_matrix_t *At, tarp_matrix_t *An);
int tarp_matrix_copy_from_string(tarp_matrix_t *A, char *str);
int tarp_matrix_set_string(tarp_matrix_t *A, const char *str);
void tarp_matrix_print(tarp_matrix_t *A, FILE *fp);
int tarp_matrix_copy_col(tarp_matrix_t *Ma, int na, tarp_matrix_t *Mb, int nb);
int tarp_matrix_copy_row(tarp_matrix_t *Ma, int na, tarp_matrix_t *Mb, int nb);
int tarp_matrix_forward_substitution(tarp_matrix_t *x, tarp_matrix_t *A, tarp_matrix_t *b);
int tarp_matrix_backward_substitution(tarp_matrix_t *x, tarp_matrix_t *A, tarp_matrix_t *b);
int tarp_matrix_givens_rotation(tarp_matrix_t *A, int n1, int n2, double c, double s);
int tarp_matrix_qr_decomp(tarp_matrix_t *Q, tarp_matrix_t *R, tarp_matrix_t *A);
int tarp_matrix_qr_attach(tarp_matrix_t *Q, tarp_matrix_t *R, tarp_matrix_t *A);
int matrix_transpose_mul_select_vector(tarp_matrix_t *A, tarp_matrix_t *B, int s);
int matrix_qr_attach_select_vector(tarp_matrix_t *Q, tarp_matrix_t *R, int s);
int tarp_matrix_qr_remove_col(tarp_matrix_t *Q, tarp_matrix_t *R, int col, int numb);
tarp_matrix_t *tarp_matrix_create_by_col_join(const tarp_matrix_t *B, const tarp_matrix_t *C);
double tarp_matrix_get_norm2(tarp_matrix_t *M);
double tarp_matrix_normalize(tarp_matrix_t *M);
int tarp_matrix_insert_row(tarp_matrix_t *A, tarp_matrix_t *B, int row, tarp_matrix_t *C);
int tarp_matrix_insert_col(tarp_matrix_t *A, tarp_matrix_t *B, int col, tarp_matrix_t *C);
int tarp_matrix_remove_row(tarp_matrix_t *A, tarp_matrix_t *B, int row, int numb);
int tarp_matrix_remove_col(tarp_matrix_t *A, tarp_matrix_t *B, int col, int numb);
int matrix_getcpy_col(tarp_matrix_t *A, tarp_matrix_t *B, int col, int numb);
int tarp_matrix_choleskey_decomp(tarp_matrix_t *L, tarp_matrix_t *G);
int tarp_matrix_purge_row_col(tarp_matrix_t *A, tarp_matrix_t *B, int row, int col);
double tarp_matrix_get_det(tarp_matrix_t *M);

#ifdef __cplusplus
}
#endif

#endif /*__MATRIX_H__ */
