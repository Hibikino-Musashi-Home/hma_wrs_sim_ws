/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_robot_x.h
 *
 */

#ifndef __TARP_MOTOR_ROBOT_X_H__
#define __TARP_MOTOR_ROBOT_X_H__

#include "tarp3/tarp_motor.h"
#include "tarp3/tarp_robot.h"

enum {
    TARP_MOTOR_TYPE_ROBOT_POS = 0,
    TARP_MOTOR_TYPE_ROBOT_ROT = 1
};

typedef struct {
    tarp_motor_t    base;

    int             type;

    tarp_robot_t*   robot;

    tarp_vector3_t  ref_pos_dis;
    tarp_vector3_t  ref_pos_vel;
    tarp_vector3_t  ref_pos_acc;

    tarp_matrix3_t  ref_rot_dis;
    tarp_vector3_t  ref_rot_vel;
    tarp_vector3_t  ref_rot_acc;

} tarp_motor_robot_t;

#endif /* __TARP_MOTOR_ROBOT_X_H__ */
