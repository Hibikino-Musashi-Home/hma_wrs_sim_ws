/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_touch.h
 */
#ifndef __TARP_TOUCH_H__
#define __TARP_TOUCH_H__

#include "tarp3/tarp_touch_x.h"
#include "tarp3/tarp_touch_frame_pos.h"
#include "tarp3/tarp_touch_frame_rot.h"

enum {
    TARP_TOUCH_TYPE_FRAME_POS,
    TARP_TOUCH_TYPE_FRAME_ROT,
};

void tarp_touch_init (tarp_touch_t* self, int type);
void tarp_touch_print (tarp_touch_t* self, FILE* fptr);

#endif /* __TARP_TOUCH_H__ */
