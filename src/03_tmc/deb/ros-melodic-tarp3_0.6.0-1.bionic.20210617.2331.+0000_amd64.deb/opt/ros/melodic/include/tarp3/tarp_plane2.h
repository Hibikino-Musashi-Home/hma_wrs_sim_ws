/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @defgroup plane2
 *
 */
#ifndef __TARP_PLANE2_H__
#define __TARP_PLANE2_H__

#include "tarp3/tarp_matrix2.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    double a;
    double b;
    double c;
} tarp_plane2_t;

/* tarp_plane2.c */
tarp_plane2_t *tarp_plane2_create(void);
void tarp_plane2_delete(tarp_plane2_t *self);
int tarp_plane2_set_param(tarp_plane2_t *self, double a, double b, double c);
int tarp_plane2_set_points(tarp_plane2_t *self, tarp_vector2_t p0, tarp_vector2_t p1);
int tarp_plane2_have_point(tarp_plane2_t *self, tarp_vector2_t p);
void tarp_plane2_get_normal_vector(tarp_plane2_t *self, tarp_vector2_t vn, tarp_vector2_t vp);

#ifdef __cplusplus
}
#endif

#endif
