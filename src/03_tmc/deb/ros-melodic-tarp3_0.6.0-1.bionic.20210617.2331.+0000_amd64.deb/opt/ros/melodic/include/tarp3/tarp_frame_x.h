/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_frame.h
 *  @defgroup   frame frame モジュール
 *
 */

#ifndef __TARP_FRAME_X_H__
#define __TARP_FRAME_X_H__

#include "tarp3/tarp_gizmo_x.h"

/**
 *  @ingroup    frame
 *  @brief      座標系を表現するクラス
 */
typedef struct {

    /** 親クラス: ロボット要素クラス gizmo */
    tarp_gizmo_t gizmo;

    /** 力(self座標系) */
    tarp_vector3_t pos_frc_self;

    /** トルク(self座標系) */
    tarp_vector3_t rot_frc_self;

} tarp_frame_t;

#endif /* __TARP_FRAME_X_H__ */
