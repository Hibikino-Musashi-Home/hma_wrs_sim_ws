/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_joint.h
 *
 *  ロボットの関節のデータ構造と、操作用の関数群です。
 */

#ifndef __TARP_JOINT_H__
#define __TARP_JOINT_H__

#include "tarp3/tarp_joint_x.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_joint.c */
tarp_joint_t *tarp_joint_create(void);
void tarp_joint_delete(tarp_joint_t *self);
void tarp_joint_set_name(tarp_joint_t *self, const char *name);
const char *tarp_joint_get_name(tarp_joint_t *self);
int tarp_joint_set_type(tarp_joint_t *self, tarp_joint_type_t type);
tarp_joint_type_t tarp_joint_get_type(tarp_joint_t *self);
void tarp_joint_set_mimic_joint(tarp_joint_t *self, tarp_joint_t *mimic, double scale, double offset);
tarp_joint_t *tarp_joint_get_mimic_joint(tarp_joint_t *self);
void tarp_joint_set_axis(tarp_joint_t *self, const tarp_vector3_t axis);
void tarp_joint_get_axis(tarp_joint_t *self, const tarp_vector3_t axis);
void tarp_joint_attach_joint(tarp_joint_t *self, tarp_joint_t *joint);
void tarp_joint_attach_solid(tarp_joint_t *self, tarp_solid_t *solid);
void tarp_joint_attach_frame(tarp_joint_t *self, tarp_frame_t *frame);
void tarp_joint_set_pos(tarp_joint_t *self, const tarp_vector3_t pos_dis, int wrt);
void tarp_joint_get_pos(tarp_joint_t *self, tarp_vector3_t pos_dis, int wrt);
double tarp_joint_get_dis(tarp_joint_t *self);
double tarp_joint_get_vel(tarp_joint_t *self);
double tarp_joint_get_acc(tarp_joint_t *self);
double tarp_joint_get_jrk(tarp_joint_t *self);
double tarp_joint_get_frc(tarp_joint_t *self);
double tarp_joint_set_dis(tarp_joint_t *self, double dis);
double tarp_joint_set_vel(tarp_joint_t *self, double vel);
double tarp_joint_set_acc(tarp_joint_t *self, double acc);
double tarp_joint_set_jrk(tarp_joint_t *self, double jrk);
double tarp_joint_reset_dis(tarp_joint_t *self);
void tarp_joint_reckon_dis(tarp_joint_t *self);
void tarp_joint_travel_dis(tarp_joint_t *self, double step);
void tarp_joint_spread_dis(tarp_joint_t *self);
void tarp_joint_travel_vel(tarp_joint_t *self, double step);
void tarp_joint_spread_vel(tarp_joint_t *self);
void tarp_joint_travel_acc(tarp_joint_t *self, double step);
void tarp_joint_spread_acc(tarp_joint_t *self);
void tarp_joint_spread_jrk(tarp_joint_t *self);
void joint_update_dis(tarp_joint_t *self, double step);
void tarp_joint_gather_force(tarp_joint_t *self);
void tarp_joint_print_data(tarp_joint_t *self, double time, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_JOINT_H__ */
