/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_hash.h
 *
 */

#ifndef __tarp_HASH_H__
#define __tarp_HASH_H__

#include "tarp3/tarp_list.h"

/**
 *  @brief  tarp_hash_list_tの実体はtarp_list_t
 */
typedef tarp_list_t tarp_hash_list_t;

/**
 *  @brief tarp_hash_dataオブジェクト
 *
 *  名前とポインタを保持するオブジェクト。
 *
 */
typedef struct {

    /** ノードの名前 */
    char* name;

    /** データへのポインタ */
    void* data;

} tarp_hash_data_t;

/**
 *  @brief hashオブジェクト
 *  ハッシュテーブルのオブジェクトで、ユーザが直接生成、操作、破壊する
 *  ものです。
 */
typedef struct {

    /** ハッシュテーブルのサイズ */
    int size;

    /** ハッシュ用配列 */
    tarp_list_t** list;

} tarp_hash_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_hash.c */
int tarp_hash_value(tarp_hash_t *hash, const char *name);
tarp_hash_data_t *tarp_hash_data_create(const char *name, void *data);
void *tarp_hash_data_delete(tarp_hash_data_t *self);
void *tarp_hash_list_remove(tarp_hash_list_t *list, const char *name);
void *tarp_hash_list_lookup_by_name(tarp_hash_list_t *list, const char *name);
char *tarp_hash_list_lookup_by_data(tarp_hash_list_t *list, void *data);
tarp_hash_t *tarp_hash_create(int size);
void tarp_hash_delete(tarp_hash_t *hash);
int tarp_hash_append(tarp_hash_t *self, const char *name, void *data);
void *tarp_hash_lookup_by_name(tarp_hash_t *hash, const char *name);
char *tarp_hash_lookup_by_data(tarp_hash_t *hash, void *data);
void *tarp_hash_remove(tarp_hash_t *hash, const char *name);
int tarp_hash_get_data_array(tarp_hash_t *hash, int numb, void **array);
void tarp_hash_list_print(tarp_list_t *list, FILE *fp);
void tarp_hash_print(tarp_hash_t *hash, FILE *fp);

#ifdef __cplusplus
}
#endif

#endif /* __tarp_HASH_H__ */
