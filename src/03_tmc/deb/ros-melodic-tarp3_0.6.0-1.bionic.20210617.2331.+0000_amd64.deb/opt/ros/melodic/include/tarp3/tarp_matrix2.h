/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   matrix2.h
 *  @defgroup matrix2 matrix2モジュール
 *
 *  2行2列の行列を扱うモジュールです。
 */
#ifndef __MATRIX2_H__
#define __MATRIX2_H__

#include "tarp3/tarp_vector2.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef tarp_vector2_t tarp_matrix2_t[2];

/* Some useful constants */
extern tarp_matrix2_t tarp_matrix2_unit;
extern tarp_matrix2_t tarp_matrix2_zero;

/* tarp_matrix2.c */
int tarp_matrix2_is_equal(tarp_matrix2_t A, tarp_matrix2_t B);
void tarp_matrix2_scale(tarp_matrix2_t a, tarp_matrix2_t b, double x);
void tarp_matrix2_copy(tarp_matrix2_t a, tarp_matrix2_t b);
void tarp_matrix2_set_unit(tarp_matrix2_t a);
void tarp_matrix2_set_zero(tarp_matrix2_t a);
void tarp_matrix2_add_matrix2(tarp_matrix2_t a, tarp_matrix2_t b, tarp_matrix2_t c);
void tarp_matrix2_sub_matrix2(tarp_matrix2_t a, tarp_matrix2_t b, tarp_matrix2_t c);
void tarp_matrix2_mul_matrix2(tarp_matrix2_t a, tarp_matrix2_t b, tarp_matrix2_t c);
void tarp_matrix2_mul_vector2(tarp_vector2_t a, tarp_matrix2_t b, tarp_vector2_t c);
void tarp_matrix2_transpose(tarp_matrix2_t a, tarp_matrix2_t b);
double tarp_matrix2_determinant(tarp_matrix2_t m);
int tarp_matrix2_invert(tarp_matrix2_t m1, tarp_matrix2_t m2);
void vector2_get_shift_vector(tarp_vector2_t v1, tarp_vector2_t d0, tarp_vector2_t v0, tarp_vector2_t d1);

#ifdef __cplusplus
}
#endif

#endif	/* __MATRIX2_H__ */
