/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_rivet_frame_pos_rot.h
 * @defgroup rivet_frame_pos_rot rivet_frame_pos_rotモジュール
 * @brief frameの位置姿勢両方の拘束(6自由度)のモジュール
 */
#ifndef __TARP_RIVET_FRAME_POS_ROT_H__
#define __TARP_RIVET_FRAME_POS_ROT_H__

#include "tarp3/tarp_rivet.h"

/**
 * @ingroup rivet_frame_pos_rot
 * @brief frameの位置姿勢すべての拘束(6自由度)
 */
typedef struct {

    /** 親クラス　*/
    tarp_rivet_t base;

    /** 対象frame */
    tarp_frame_t* frame;

    /** 目標変位 */
    tarp_vector3_t ref_pos_dis;

    /** 目標速度 */
    tarp_vector3_t ref_pos_vel;

    /** 目標加速度 */
    tarp_vector3_t ref_pos_acc;

    /** 目標躍度 */
    tarp_vector3_t ref_pos_jrk;

    /** 目標変位 */
    tarp_vector3_t act_pos_dis;

    /** 目標速度 */
    tarp_vector3_t act_pos_vel;

    /** 目標加速度 */
    tarp_vector3_t act_pos_acc;

    /** 基準軸 */
    tarp_vector3_t  axis;

    /** 姿勢行列の指令値 */
    tarp_matrix3_t  ref_rot_dis;

    /** 指令角速度 */
    tarp_vector3_t  ref_rot_vel;

    /** 指令角加速度 */
    tarp_vector3_t  ref_rot_acc;

    /** 実際の姿勢 */
    tarp_matrix3_t  act_rot_dis;

    /** 実際の角速度 */
    tarp_vector3_t  act_rot_vel;

    /** 実際の角加速度 */
    tarp_vector3_t  act_rot_acc;

} tarp_rivet_frame_pos_rot_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_rivet_frame_pos_rot.c */
tarp_rivet_frame_pos_rot_t *tarp_rivet_frame_pos_rot_create(void);
void tarp_rivet_frame_pos_rot_delete(tarp_rivet_frame_pos_rot_t *self);
void tarp_rivet_frame_pos_rot_set_frame(tarp_rivet_frame_pos_rot_t *self, tarp_frame_t *frame);
tarp_frame_t *tarp_rivet_frame_pos_rot_get_frame(tarp_rivet_frame_pos_rot_t *self);
void tarp_rivet_frame_pos_rot_update(tarp_rivet_frame_pos_rot_t *self, double step, double tick);
void tarp_rivet_frame_pos_rot_update_jacob(tarp_rivet_frame_pos_rot_t *self, int numb);
void tarp_rivet_frame_pos_rot_update_other(tarp_rivet_frame_pos_rot_t *self);
void tarp_rivet_frame_pos_rot_print(tarp_rivet_frame_pos_rot_t *self, FILE *fptr);
void tarp_rivet_frame_pos_rot_set_ref(tarp_rivet_frame_pos_rot_t *self, const tarp_vector3_t ref_pos_dis, const tarp_matrix3_t ref_rot_dis);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_RIVET_FRAME_POS_ROT_H__ */
