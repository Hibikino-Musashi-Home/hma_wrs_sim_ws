/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail.h
 *
 */
#ifndef __TARP_TRAIL_H__
#define __TARP_TRAIL_H__

#include <stdio.h>
#include "tarp3/tarp_trail_x.h"
#include "tarp3/tarp_trail_motor.h"
#include "tarp3/tarp_trail_rivet.h"

/* tarp_trail.c */
void tarp_trail_init(tarp_trail_t *self, int type);
void tarp_trail_update(tarp_trail_t *self, double step, double tick);
void tarp_trail_print(tarp_trail_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_H__ */
