/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_robot_pos.h
 *
 */

#ifndef __TARP_MOTOR_ROBOT_POS_H__
#define __TARP_MOTOR_ROBOT_POS_H__

#include "tarp3/tarp_motor.h"
#include "tarp3/tarp_robot.h"

typedef struct {

    tarp_motor_t        base;

    /* 対象robot */
    tarp_robot_t*       robot;

    /* 自由度ベクトル */
    tarp_vector3_t      axis;

    /* 指令変位 */
    double              ref_dis;

    /* 指令速度 */
    double              ref_vel;

    /* 指令加速度 */
    double              ref_acc;

} tarp_motor_robot_pos_t;

/* tarp_motor_robot_pos.c */
tarp_motor_robot_pos_t *tarp_motor_robot_pos_create(void);
void tarp_motor_robot_pos_delete(tarp_motor_robot_pos_t *self);
void tarp_motor_robot_pos_update(tarp_motor_robot_pos_t *self, double step, double tick);
void tarp_motor_robot_pos_print(tarp_motor_robot_pos_t *self, FILE *fptr);

#endif /* __TARP_MOTOR_ROBOT_POS_H__ */
