/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *
 *  @file   tarp_system3.h
 *
 *  3次元同次変換行列クラス
 */

#ifndef __SYSTEM3_H__
#define __SYSTEM3_H__

#include "tarp3/tarp_object.h"
#include "tarp3/tarp_matrix3.h"

/**
 *  @brief  3次元同次変換行列(並進と回転)を表現するクラス
 */
typedef struct {
    /** 変位ベクトル */
    tarp_vector3_t pos;

    /** 回転行列 */
    tarp_matrix3_t rot;

} tarp_system3_t;

/* ../../src/tarp_system3.c */
void tarp_system3_mul_system3(tarp_matrix3_t A, tarp_vector3_t a, const tarp_matrix3_t B, const tarp_vector3_t b, const tarp_matrix3_t C, const tarp_vector3_t c);
void tarp_system3_mul_vector3(tarp_vector3_t a, tarp_matrix3_t B, tarp_vector3_t b, tarp_vector3_t c);
void tarp_system3_invert(tarp_matrix3_t A, tarp_vector3_t a, tarp_matrix3_t B, tarp_vector3_t b);
void tarp_system3_invert_mul_system3(tarp_matrix3_t A, tarp_vector3_t a, tarp_matrix3_t B, tarp_vector3_t b, tarp_matrix3_t C, tarp_vector3_t c);
void tarp_system3_invert_mul_vector3(tarp_vector3_t a, tarp_matrix3_t B, tarp_vector3_t b, tarp_vector3_t c);

#endif /* __SYSTEM3_H__ */
