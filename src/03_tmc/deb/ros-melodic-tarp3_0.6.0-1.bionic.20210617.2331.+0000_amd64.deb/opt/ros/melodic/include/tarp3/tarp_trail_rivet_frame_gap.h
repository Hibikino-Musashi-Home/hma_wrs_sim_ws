/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_frame_gap.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_FRAME_GAP_H__
#define __TARP_TRAIL_RIVET_FRAME_GAP_H__

#include "tarp3/tarp_trail_rivet.h"
#include "tarp3/tarp_rivet_frame_gap.h"

typedef struct {
	
    tarp_trail_rivet_t base;

    double ref_jrk_min;
    int ref_jrk_min_indx;

    double ref_jrk_max;
    int ref_jrk_max_indx;

    double act_dis;
    int act_dis_indx;

    double act_vel;
    int act_vel_indx;

    double act_acc;
    int act_acc_indx;

    double act_jrk;
    int act_jrk_indx;

    double act_jrk_min;
    int act_jrk_min_indx;

    double act_jrk_max;
    int act_jrk_max_indx;

} tarp_trail_rivet_frame_gap_t;

/* tarp_trail_rivet_frame_gap.c */
tarp_trail_rivet_frame_gap_t *tarp_trail_rivet_frame_gap_create(void);
void tarp_trail_rivet_frame_gap_delete(tarp_trail_rivet_frame_gap_t *self);
void tarp_trail_rivet_frame_gap_update(tarp_trail_rivet_frame_gap_t *self, double step, double tick);
void tarp_trail_rivet_frame_gap_print(tarp_trail_rivet_frame_gap_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_FRAME_GAP_H__ */
