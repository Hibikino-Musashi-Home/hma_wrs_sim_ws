/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_track_rivet_joint.h
 *
 */

#ifndef TARP_TRACK_RIVET_JOINT_H_
#define TARP_TRACK_RIVET_JOINT_H_

#include "tarp3/tarp_track_rivet.h"

typedef struct {

    tarp_track_rivet_t base;

    double ref_dis;
    int ref_dis_indx;

    double ref_vel;
    int ref_vel_indx;

    double ref_acc;
    int ref_acc_indx;

} tarp_track_rivet_joint_t;

/* tarp_track_rivet_joint.c */
tarp_track_rivet_joint_t *tarp_track_rivet_joint_create(void);
void tarp_track_rivet_joint_delete(tarp_track_rivet_joint_t *self);
void tarp_track_rivet_joint_update(tarp_track_rivet_joint_t *self, double step, double tick);
void tarp_track_rivet_joint_print(tarp_track_rivet_joint_t *self, FILE *fptr);

#endif /* TARP_TRACK_RIVET_JOINT_H_ */
