/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_joint.h
 *
 */

#ifndef __TARP_MOTOR_JOINT_H__
#define __TARP_MOTOR_JOINT_H__

#include "tarp3/tarp_motor.h"

typedef struct {

    tarp_motor_t    base;
    
    tarp_joint_t*   joint;

    double          ref_dis;
    double          ref_vel;
    double          ref_acc;
    double          ref_jrk;

} tarp_motor_joint_t;

/* tarp_motor_joint.c */
tarp_motor_joint_t *tarp_motor_joint_create(void);
void tarp_motor_joint_delete(tarp_motor_joint_t *self);
void tarp_motor_joint_update(tarp_motor_joint_t *self, double step, double tick);
void tarp_motor_joint_print(tarp_motor_joint_t *self, FILE *fptr);

#endif /* __TARP_MOTOR_JOINT_H__ */
