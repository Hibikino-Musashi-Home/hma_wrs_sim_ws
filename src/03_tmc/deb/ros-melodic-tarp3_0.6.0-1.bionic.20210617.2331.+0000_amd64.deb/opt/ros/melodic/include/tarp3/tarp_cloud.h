/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file       tarp_cloud.h
 *
 *  座標系(cloud)データ構造と操作のための関数群です。
 */

#ifndef __TARP_CLOUD_H__
#define __TARP_CLOUD_H__

#include <stdio.h>
#include "tarp3/tarp_object.h"
// #include "tarp_htrans3.h"
//#include "tarp_world_x.h"
#include "tarp3/tarp_solid_x.h"
#include "tarp3/tarp_cloud_x.h"
#include "tarp3/tarp_gizmo.h"

/* tarp_cloud.c */
tarp_cloud_t *tarp_cloud_create(void);
void tarp_cloud_delete(tarp_cloud_t *self);
int tarp_cloud_get_numb (tarp_cloud_t* self);
void tarp_cloud_set_numb(tarp_cloud_t *self, int numb);
void tarp_cloud_set_pos_dis(tarp_cloud_t *self, int n, tarp_vector3_t pos_dis);
void tarp_cloud_print_data(tarp_cloud_t *self, double time, FILE *fptr);

#endif /* __TARP_CLOUD_H__ */
