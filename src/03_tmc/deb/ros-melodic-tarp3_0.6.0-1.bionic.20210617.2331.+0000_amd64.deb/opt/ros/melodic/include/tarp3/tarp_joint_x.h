/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file       tarp_joint_x.h
 *  @defgroup   joint joint モジュール
 */

#ifndef __TARP_JOINT_X_H__
#define __TARP_JOINT_X_H__

#include "tarp3/tarp_gizmo_x.h"

typedef enum {
  TARP_JOINT_TYPE_NONE = -1,
  TARP_JOINT_TYPE_ROT = 0,
  TARP_JOINT_TYPE_POS = 1,
} tarp_joint_type_t;

typedef struct tarp_joint tarp_joint_t;

/**
 *  @ingroup    joint
 *  @brief      関節を表現するクラス
 *
 *  メンバはすべてlocal基準とする。
 */
struct tarp_joint {
    /** 親クラス：ロボット要素クラス gizmo */
    tarp_gizmo_t gizmo;

    /** 関節種別(回転or直動 */
    tarp_joint_type_t type;

    /** 変位=0での初期位置 (prev座標系)*/
    tarp_vector3_t pos_dis_init;

    /** 変位=0での初期姿勢 (prev座標系)*/
    tarp_matrix3_t rot_dis_init;

    /** 関節の軸方向の単位ベクトル (local) */
    tarp_vector3_t axis;

    /** 関節の中立角度 */
    double neutral;

    /** 関節の変位      [rad or m] */
    double dis;

    /** 関節の角速度    [rad/s] */
    double vel;

    /** 関節の角加速度  [rad/s^2] */
    double acc;

    /** 関節の躍度 */
    double jrk;

    /** 関節のトルク [Nm] */
    double frc;

    /** 関節角制限 MAX  [rad] */
    double max;

    /** 関節角制限 MIN  [rad] */
    double min;

    /** 関節の最大角速度    [rad/s] */
    double vel_max;

    /** 関節の最大角加速度  [rad/s^2] */
    double acc_max;

    /** 関節の最大躍度 [rad/s^3] */
    double max_jrk;

#if 0
    /** 関節のトルク下限 [Nm] */
    double frc_min;

    /** 関節のトルク上限 [Nm] */
    double frc_max;
#endif
    /** 関節角制限用のマージン */
    double max_mgn;

    /** 関節角制限用のマージン */
    double min_mgn;

    /** 関節の角速度退避用 [rad/s] */
    double vel_save;

    /** 関節の角加速度退避用 [rad/s] */
    double acc_save;

    /** 関節の躍度退避用 */
    double jrk_save;

    /** この関節が従属する関節へのポインタ */
    tarp_joint_t* mimic;

    /** 従属関節のスケール値 */
    double mimic_scale;

    /** 従属関節のオフセット値 */
    double mimic_offset;

};

#endif /* __TARP_JOINT_X_H__ */
