/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_strap.h
 *
 */
#ifndef __TARP_TRACK_STRAP_H__
#define __TARP_TRACK_STRAP_H__

#include "tarp3/tarp_track_strap_x.h"
#include "tarp3/tarp_track_strap_robot_pos.h"
#include "tarp3/tarp_track_strap_robot_rot.h"
#include "tarp3/tarp_track_strap_joint.h"

/* tarp_track_strap.c */
void tarp_track_strap_init(tarp_track_strap_t *self, int type);
void tarp_track_strap_print(tarp_track_strap_t *self, FILE *fptr);
void tarp_track_strap_update(tarp_track_strap_t *self, double step, double tick);

#endif /* __TARP_TRACK_STRAP_H__ */
