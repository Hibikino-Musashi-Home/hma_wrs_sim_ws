/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_oport.h
 *
 *  Created on: 2010/07/16
 *      Author: tajima
 */

#ifndef TARP_OPORT_H_
#define TARP_OPORT_H_

#include <stdio.h>
#include "tarp3/tarp_matrix.h"
#include "tarp3/tarp_traj.h"

/**
 *  @brief  入力を定義するクラス
 *
 *  tickを指定してデータをもらえるAPI
 */
typedef struct {

    /** name */
    char name[256];

    /** ファイル名 */
    char file[256];

    /** ファイルポインタ */
    FILE* fptr;

    /** サイズ */
    int size;

    /** データ */
    double data[128];

    /** 軌道データ */
    tarp_traj_t* traj;

} tarp_oport_t;

/* tarp_oport.c */
tarp_oport_t *tarp_oport_create(void);
void tarp_oport_delete(tarp_oport_t *self);
void tarp_oport_set_data(tarp_oport_t *self, int numb, double data);
void tarp_oport_setup(tarp_oport_t *self, double tick);
void tarp_oport_update(tarp_oport_t *self, double step, double tick);
void tarp_oport_print(tarp_oport_t *self, FILE *fptr);

#endif /* TARP_OPORT_H_ */
