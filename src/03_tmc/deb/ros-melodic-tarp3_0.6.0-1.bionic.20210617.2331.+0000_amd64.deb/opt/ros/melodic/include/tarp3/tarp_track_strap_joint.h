/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_track_strap_joint.h
 *
 */

#ifndef __TARP_TRACK_STRAP_JOINT_H__
#define __TARP_TRACK_STRAP_JOINT_H__

#include "tarp3/tarp_track_strap.h"

typedef struct {

    tarp_track_strap_t base;

    tarp_strap_joint_t* strap;

    double ref_dis;
    double ref_vel;
    double ref_acc;

} tarp_track_strap_joint_t;

tarp_track_strap_joint_t* tarp_track_strap_joint_create (void);
void tarp_track_strap_joint_delete (tarp_track_strap_joint_t* self);
void tarp_track_strap_joint_print (tarp_track_strap_joint_t* self, FILE* fptr);

#endif /* __TARP_TRACK_STRAP_JOINT_H__ */
