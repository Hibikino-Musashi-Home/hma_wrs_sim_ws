/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_rivet_robot_cog.h
 *
 */
#ifndef __TARP_TRACK_RIVET_ROBOT_COG_H__
#define __TARP_TRACK_RIVET_ROBOT_COG_H__

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_robot_cog.h"

typedef struct {

    tarp_track_rivet_t base;

    tarp_frame_t* frame;

    double ref_dis;
    int ref_dis_indx;

    double ref_vel;
    int ref_vel_indx;

    double ref_acc;
    int ref_acc_indx;

} tarp_track_rivet_robot_cog_t;

/* tarp_track_rivet_robot_cog.c */
tarp_track_rivet_robot_cog_t *tarp_track_rivet_robot_cog_create(void);
void tarp_track_rivet_robot_cog_delete(tarp_track_rivet_robot_cog_t *self);
void tarp_track_rivet_robot_cog_update(tarp_track_rivet_robot_cog_t *self, double step, double tick);
void tarp_track_rivet_robot_cog_print(tarp_track_rivet_robot_cog_t *self, FILE *fptr);

#endif /* __TARP_TRACK_RIVET_ROBOT_COG_H__ */
