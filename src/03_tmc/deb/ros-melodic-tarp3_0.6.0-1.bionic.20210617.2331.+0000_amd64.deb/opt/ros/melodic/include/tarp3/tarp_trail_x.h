/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_x.h
 *
 */
#ifndef __TARP_TRAIL_X_H__
#define __TARP_TRAIL_X_H__

#include "tarp3/tarp_oport.h"

enum {
    TARP_TRAIL_TYPE_MOTOR,
    TARP_TRAIL_TYPE_RIVET,
};

/**
 *  @brief 出力を管理する
 *
 */
typedef struct {

    /* name */
    char name[256];

    /* 種別 */
    int type;

    /* 出力ポート */
    tarp_oport_t* oport;

} tarp_trail_t;

#endif /* __TARP_TRAIL_X_H__ */
