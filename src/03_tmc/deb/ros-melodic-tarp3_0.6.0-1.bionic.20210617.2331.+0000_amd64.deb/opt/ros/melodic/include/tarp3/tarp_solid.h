/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_solid.h
 *
 *  ロボットのリンクのデータ構造とそれを操作する関数群です。
 */

#ifndef __TARP_SOLID_H__
#define __TARP_SOLID_H__

#include "tarp3/tarp_gizmo.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_solid.c */
tarp_solid_t *tarp_solid_create(void);
void tarp_solid_delete(tarp_solid_t *self);
void tarp_solid_set_name(tarp_solid_t *self, const char *name);
const char *tarp_solid_get_name(tarp_solid_t *self);
void tarp_solid_set_weight(tarp_solid_t *self, double weight);
void tarp_solid_set_inertia(tarp_solid_t *self, double Ixx, double Iyy, double Izz, double Ixy, double Iyz, double Izx);
double tarp_solid_get_weight(tarp_solid_t *self);
void tarp_solid_set_pos_dis(tarp_solid_t *self, const tarp_vector3_t pos_dis, int wrt);
void tarp_solid_get_pos_dis(tarp_solid_t *self, tarp_vector3_t pos_dis, int wrt);
void tarp_solid_get_inertia(tarp_solid_t *self, tarp_matrix3_t inertia, char wrt);
void tarp_solid_gather_weight(tarp_solid_t *self);
void tarp_solid_gather_cog(tarp_solid_t *self);
void tarp_solid_gather_inertia(tarp_solid_t *self);
void tarp_solid_gather_moment(tarp_solid_t *self);
void tarp_solid_gather_frc(tarp_solid_t *self);
void tarp_solid_print_data(tarp_solid_t *self, double time, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_SOLID_H__ */
