/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_rot.h
 *
 *  Created on: 2009/11/10
 *      Author: tajima
 */

#ifndef TARP_RIVET_ROT_H_
#define TARP_RIVET_ROT_H_

#include "tarp3/tarp_rivet_x.h"

tarp_rivet_t* tarp_rivet_rot_xyz_create (tarp_gizmo_t* gizmo);
int tarp_rivet_rot_xyz_setup (tarp_rivet_t* self);
void tarp_rivet_rot_xyz_update_jacobian (tarp_rivet_t* self, int no);
void tarp_rivet_rot_xyz_set_ref_vel (tarp_rivet_t* self, tarp_vector3_t rot_vel);
void tarp_rivet_rot_xyz_set_ref_rpy (tarp_rivet_t* self, double step, tarp_vector3_t rot_rpy);
int tarp_rivet_rot_xyz_set_ref_dis_file (tarp_rivet_t* self, double step);

#endif /* TARP_RIVET_ROT_H_ */
