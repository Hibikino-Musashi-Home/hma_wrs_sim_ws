/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_robot.h
 *
 */

#ifndef __TARP_MOTOR_ROBOT_H__
#define __TARP_MOTOR_ROBOT_H__

#include "tarp3/tarp_motor_robot_x.h"
#include "tarp3/tarp_motor_robot_pos.h"
#include "tarp3/tarp_motor_robot_rot.h"

/* tarp_motor_robot.c */
int tarp_motor_robot_init(tarp_motor_robot_t *self, int type);
tarp_motor_robot_t *tarp_motor_robot_create(void);
void tarp_motor_robot_delete(tarp_motor_robot_t *self);
void tarp_motor_robot_add_pos_jrk(tarp_motor_robot_t *self, tarp_vector3_t pos_jrk);
void tarp_motor_robot_update(tarp_motor_robot_t *self, double step);
void tarp_motor_robot_print(tarp_motor_robot_t *self, FILE *fptr);

#endif /* __TARP_MOTOR_ROBOT_H__ */
