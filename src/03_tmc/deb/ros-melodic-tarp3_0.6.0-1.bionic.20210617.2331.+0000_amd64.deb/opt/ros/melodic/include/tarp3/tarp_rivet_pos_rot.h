/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_pos_rot.h
 *
 *  Created on: 2009/11/10
 *      Author: tajima
 */

#ifndef __TARP_RIVET_POS_ROT_H__
#define __TARP_RIVET_POS_ROT_H__

#include "tarp3/tarp_rivet.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t rivet;

    /** 対象gizmo */
    tarp_gizmo_t* target;

    /** 指令位置 */
    tarp_vector3_t pos_dis;

    /** 指令姿勢 */
    tarp_vector3_t rot_rpy;

} tarp_rivet_pos_rot_t;

tarp_rivet_pos_rot_t* tarp_rivet_pos_rot_create (void);
void tarp_rivet_pos_rot_delete (tarp_rivet_pos_rot_t* self);
void tarp_rivet_pos_rot_set_target_numb (tarp_rivet_pos_rot_t* self, int numb);
void tarp_rivet_pos_rot_set_target (tarp_rivet_pos_rot_t* self, tarp_gizmo_t* target);
int tarp_rivet_pos_xyz_rot_xyz_setup (tarp_rivet_t* self);
void tarp_rivet_pos_xyz_rot_xyz_update_jacobian (tarp_rivet_pos_rot_t* self, int value_numb);
void tarp_rivet_pos_xyz_rot_xyz_set_ref_vel (tarp_rivet_pos_rot_t* self, tarp_vector3_t pos_vel, tarp_vector3_t rot_vel, int wrt);
void tarp_rivet_pos_xyz_rot_xyz_set_ref_vel_min_max (tarp_rivet_pos_rot_t* self, tarp_vector3_t pos_vel_min, tarp_vector3_t pos_vel_max, tarp_vector3_t rot_vel_min, tarp_vector3_t rot_vel_max);
int tarp_rivet_pos_xyz_rot_xyz_set_ref_dis (tarp_rivet_pos_rot_t* self, double step, tarp_vector3_t pos_dis, tarp_vector3_t rot_rpy);
int tarp_rivet_pos_xyz_rot_set_ref_dis (tarp_rivet_pos_rot_t* self, double step, tarp_vector3_t pos_dis, tarp_matrix3_t rot_dis);
int tarp_rivet_pos_xyz_rot_xyz_set_ref_dis_min_max (tarp_rivet_pos_rot_t* self, double step, tarp_vector3_t pos_dis_min, tarp_vector3_t pos_dis_max, tarp_vector3_t rot_rpy_min, tarp_vector3_t rot_rpy_max);
void tarp_rivet_pos_rot_print (tarp_rivet_pos_rot_t* self, FILE* fp);

#endif /* __TARP_RIVET_POS_ROT_H__ */
