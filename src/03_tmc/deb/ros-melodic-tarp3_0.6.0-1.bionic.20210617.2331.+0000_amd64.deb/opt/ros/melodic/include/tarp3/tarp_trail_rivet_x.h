/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_x.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_X_H__
#define __TARP_TRAIL_RIVET_X_H__

#include "tarp3/tarp_trail.h"
#include "tarp3/tarp_rivet.h"

enum {
    TARP_TRAIL_RIVET_TYPE_ROBOT_POS,
    TARP_TRAIL_RIVET_TYPE_ROBOT_ROT,
    TARP_TRAIL_RIVET_TYPE_ROBOT_COG,
    TARP_TRAIL_RIVET_TYPE_ROBOT_MOI,
    TARP_TRAIL_RIVET_TYPE_ROBOT_ZMP,
    TARP_TRAIL_RIVET_TYPE_FRAME_POS,
    TARP_TRAIL_RIVET_TYPE_FRAME_ROT,
    TARP_TRAIL_RIVET_TYPE_FRAME_DIR,
    TARP_TRAIL_RIVET_TYPE_FRAME_GAP,
    TARP_TRAIL_RIVET_TYPE_JOINT,
    TARP_TRAIL_RIVET_TYPE_SHAPE_SSV,
    TARP_TRAIL_RIVET_TYPE_NUMB,
};

typedef struct {

    /* 親クラス */
    tarp_trail_t base;

    /* type */
    int type;

    /* 対象rivet */
    tarp_rivet_t* rivet;

} tarp_trail_rivet_t;

#endif /* __TARP_TRAIL_RIVET_X_H__ */
