/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_moi.h
 *
 *  Created on: 2010/07/30
 *      Author: tajima
 */

#ifndef TARP_TRACK_MOI_H_
#define TARP_TRACK_MOI_H_

#include "tarp3/tarp_track.h"

typedef struct {
    tarp_track_t track;

    tarp_vector3_t moi_vel;
    tarp_vector3_t moi_vel_head;
    tarp_vector3_t moi_vel_tail;

    /* 補間用 */
    interp_poly3_t intp_moi_dis[3];

} tarp_track_moi_t;

tarp_track_moi_t* tarp_track_moi_create (void);
void tarp_track_moi_delete (tarp_track_moi_t* self);
void tarp_track_moi_setup (tarp_track_moi_t* self);
int tarp_track_moi_load_fptr (tarp_track_moi_t* self, FILE* fptr);

#endif /* TARP_TRACK_MOI_H_ */
