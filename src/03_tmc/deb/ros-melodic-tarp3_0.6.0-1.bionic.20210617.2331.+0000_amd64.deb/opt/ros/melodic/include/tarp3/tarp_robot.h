/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file robot.h
 *  @defgroup robot robotモジュール
 *
 *  ロボットのデータ構造を扱うモジュールです。
 */

#ifndef __TARP_ROBOT_H__
#define __TARP_ROBOT_H__

#include "tarp3/tarp_matrix3.h"
#include "tarp3/tarp_frame_x.h"
#include "tarp3/tarp_solid_x.h"
#include "tarp3/tarp_joint_x.h"
#include "tarp3/tarp_robot_x.h"
#include "tarp3/tarp_gizmo.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_robot.c */
tarp_robot_t *tarp_robot_create(void);
void tarp_robot_delete(tarp_robot_t *self);
const char *tarp_robot_get_name(tarp_robot_t *self);
void tarp_robot_set_name(tarp_robot_t *self, const char *name);
void tarp_robot_attach_frame(tarp_robot_t *self, tarp_frame_t *frame);
void tarp_robot_attach_joint(tarp_robot_t *self, tarp_joint_t *joint);
void tarp_robot_attach_solid(tarp_robot_t *self, tarp_solid_t *solid);
void tarp_robot_save_vel(tarp_robot_t *self);
void tarp_robot_load_vel(tarp_robot_t *self);
void tarp_robot_save_acc(tarp_robot_t *self);
void tarp_robot_load_acc(tarp_robot_t *self);
int tarp_robot_append(tarp_robot_t *self, tarp_gizmo_t *gizmo);
tarp_gizmo_t *tarp_robot_remove_by_name(tarp_robot_t *self, const char *name);
void *tarp_robot_lookup(tarp_robot_t *self, const char *name);
int tarp_robot_get_frame_numb(tarp_robot_t *self);
int tarp_robot_get_solid_numb(tarp_robot_t *self);
int tarp_robot_get_joint_numb(tarp_robot_t *self);
int tarp_robot_get_joint_array(tarp_robot_t *self, tarp_joint_t *joints[], int numb);
void tarp_robot_update_dis(tarp_robot_t *self, double step);
void tarp_robot_update_vel(tarp_robot_t *self, double step);
void tarp_robot_update_acc(tarp_robot_t *self, double step);
void tarp_robot_update_jrk(tarp_robot_t *self, double step);
void tarp_robot_update_frc(tarp_robot_t *self, double step);
double tarp_robot_get_weight(tarp_robot_t *self);
void tarp_robot_get_cog_dis(tarp_robot_t *self, tarp_vector3_t cog_dis, int wrt);
void tarp_robot_get_zmp_dis(tarp_robot_t *self, tarp_vector3_t zmp_dis, double z);
void tarp_robot_print_data(tarp_robot_t *self, double time, FILE *fptr);
void tarp_robot_debug(tarp_robot_t *self, FILE *fptr);
void tarp_robot_travel_dis(tarp_robot_t *self, double step);
void tarp_robot_travel_vel(tarp_robot_t *self, double step);
void tarp_robot_travel_acc(tarp_robot_t *self, double step);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_ROBOT_H__ */

