/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_rivet_shape_cloud.h
 *
 */

#ifndef __TARP_RIVET_SHAPE_CLOUD_H__
#define __TARP_RIVET_SHAPE_CLOUD_H__

#include "tarp3/tarp_shape.h"
#include "tarp3/tarp_cloud.h"
#include "tarp3/tarp_rivet.h"
#include "tarp3/tarp_limit.h"
#include "tarp3/tarp_linseg.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t  base;

    /** 対象shape(今のところ球を仮定) */
    tarp_shape_t* shape;

    /** 対象cloud */
    tarp_cloud_t* cloud;

    /** 変位上下限 */
    double          ref_dis_min;
    double          ref_dis_max;

    /** 目標速度 */
    double          ref_vel;

    /** 目標加速度 */
    double          ref_acc;

    /** 目標躍度 */
    double          ref_jrk;

    /** 現在変位 */
    double          act_dis;

    /** 現在速度 */
    double          act_vel;

    /** 現在加速度 */
    double          act_acc;

    /** 現在躍度 */
    double          act_jrk;

	/** 躍度の下限 */
    double          act_jrk_min;

	/** 躍度の上限 */
    double          act_jrk_max;

    /** 上下限の計算 */
    tarp_limit_t*   limit;

} tarp_rivet_shape_cloud_t;

/* tarp_rivet_shape_cloud.c */
tarp_rivet_shape_cloud_t *tarp_rivet_shape_cloud_create(void);
void tarp_rivet_shape_cloud_delete(tarp_rivet_shape_cloud_t *self);
void tarp_rivet_shape_cloud_setup (tarp_rivet_shape_cloud_t* self);
double tarp_rivet_shape_cloud_get_act_vel(tarp_rivet_shape_cloud_t *self);
double tarp_rivet_shape_cloud_get_act_acc(tarp_rivet_shape_cloud_t *self);
double tarp_rivet_shape_cloud_get_act_jrk(tarp_rivet_shape_cloud_t *self);
void tarp_rivet_shape_cloud_update(tarp_rivet_shape_cloud_t *self, double step, double tick);
void tarp_rivet_shape_cloud_update_jacob(tarp_rivet_shape_cloud_t *self, int numb);
void tarp_rivet_shape_cloud_update_other (tarp_rivet_shape_cloud_t* self);
void tarp_rivet_shape_cloud_print(tarp_rivet_shape_cloud_t *self, FILE *fptr);

#endif /* __TARP_RIVET_SHAPE_CLOUD_H__ */
