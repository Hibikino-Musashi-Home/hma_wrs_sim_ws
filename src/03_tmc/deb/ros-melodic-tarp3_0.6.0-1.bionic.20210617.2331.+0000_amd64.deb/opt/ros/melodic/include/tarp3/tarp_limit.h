/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_limit.h
 *  @defgroup limit limitモジュール
 *
 *  上下限制約を満たすような躍度入力を計算するモジュール。
 */
#ifndef __TARP_LIMIT_H__
#define __TARP_LIMIT_H__

#include "tarp3/tarp_limit_x.h"
#include "tarp3/tarp_limit_max.h"
#include "tarp3/tarp_limit_min.h"

#ifdef __cplusplus
extern "C" {
#endif

/* tarp_limit.c */
void tarp_limit_set_debug(int on);
tarp_limit_t *tarp_limit_create(double step);
void tarp_limit_delete(tarp_limit_t *self);
void tarp_limit_set_ref_dis_min(tarp_limit_t *self, double dis_min);
void tarp_limit_set_ref_dis_max(tarp_limit_t *self, double dis_max);
void tarp_limit_set_ref_vel_min(tarp_limit_t *self, double vel_min);
void tarp_limit_set_ref_vel_max(tarp_limit_t *self, double vel_max);
void tarp_limit_set_ref_acc_min(tarp_limit_t *self, double acc_min);
void tarp_limit_set_ref_acc_max(tarp_limit_t *self, double acc_max);
void tarp_limit_set_ref_jrk_min(tarp_limit_t *self, double jrk_min);
void tarp_limit_set_ref_jrk_max(tarp_limit_t *self, double jrk_max);
double tarp_limit_get_ref_dis_min(tarp_limit_t *self);
double tarp_limit_get_ref_dis_max(tarp_limit_t *self);
double tarp_limit_get_ref_vel_min(tarp_limit_t *self);
double tarp_limit_get_ref_vel_max(tarp_limit_t *self);
double tarp_limit_get_ref_acc_min(tarp_limit_t *self);
double tarp_limit_get_ref_acc_max(tarp_limit_t *self);
double tarp_limit_get_ref_jrk_min(tarp_limit_t *self);
double tarp_limit_get_ref_jrk_max(tarp_limit_t *self);
double tarp_limit_get_act_dis_min(tarp_limit_t *self);
double tarp_limit_get_act_dis_max(tarp_limit_t *self);
double tarp_limit_get_act_vel_min(tarp_limit_t *self);
double tarp_limit_get_act_vel_max(tarp_limit_t *self);
double tarp_limit_get_act_acc_min(tarp_limit_t *self);
double tarp_limit_get_act_acc_max(tarp_limit_t *self);
double tarp_limit_get_act_jrk_min(tarp_limit_t *self);
double tarp_limit_get_act_jrk_max(tarp_limit_t *self);
double tarp_limit_get_ans_jrk_min(tarp_limit_t *self);
double tarp_limit_get_ans_jrk_max(tarp_limit_t *self);
int tarp_limit_get_mode_min(tarp_limit_t *self);
int tarp_limit_get_mode_max(tarp_limit_t *self);
double tarp_limit_cut_ans_jrk(tarp_limit_t *self, double jrk);
void tarp_limit_update_act_limits(tarp_limit_t *self, double step, double coef);
int tarp_limit_update(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
double minval(int n, ...);
double maxval(int n, ...);
double poly_solve(double *a, int n, double dt);
double poly_solve_alt(double *a, int n, double dt);
double poly_solve2(double *a, int n, double dt, double ts);
int solve_poly2(double *xn, double *xp, double a0, double a1, double a2);
int tarp_limit_check_step_response(tarp_limit_t *limit, double step, double xdr, double xd0, double xv0, double xa0);
int tarp_limit_check_step_response_vgcs(tarp_limit_t *limit, double step, double xdr, double xd0, double xv0, double xa0);
double tarp_limit_get_input_jerk(double step, double ref_dis, double ref_vel, double ref_acc, double act_dis, double act_vel, double act_acc);
double tarp_limit_get_input_jerk_vgcs(tarp_limit_t *self, double step, double ref_dis, double ref_vel, double ref_acc, double act_dis, double act_vel, double act_acc);
int tarp_limit_check_sine_response_vgcs(tarp_limit_t *limit, double step, double a, double f, double xd0, double xv0, double xa0);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_LIMIT_H__ */
