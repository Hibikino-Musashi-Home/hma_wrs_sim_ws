/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_rivet_frame_pos_dir.h
 *  @defgroup rivet_frame_pos_dir rivet_frame_pos_dirモジュール
 *  @brief frame原点の位置に対する拘束のクラス
 */
#ifndef __TARP_RIVET_FRAME_POS_DIR_H__
#define __TARP_RIVET_FRAME_POS_DIR_H__

#include "tarp3/tarp_rivet.h"

/**
 * @ingroup rivet_frame_pos_dir
 * @brief frameの原点に対してある軸方向(世界座標系で)の拘束を定義する
 */
typedef struct {

    /** 親クラス　*/
    tarp_rivet_t    base;

    /** 対象frame */
    tarp_frame_t*   frame;

    /** 拘束する軸方向 */
    tarp_vector3_t  axis;

    /** 目標変位 */
    double          ref_dis;

    /** 目標速度 */
    double          ref_vel;

    /** 目標加速度 */
    double          ref_acc;

    /** 目標躍度 */
    double          ref_jrk;

    /** 目標変位 */
    double          act_dis;

    /** 目標速度 */
    double          act_vel;

    /** 目標加速度 */
    double          act_acc;

} tarp_rivet_frame_pos_dir_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_rivet_frame_pos_dir.c */
tarp_rivet_frame_pos_dir_t *tarp_rivet_frame_pos_dir_create(void);
void tarp_rivet_frame_pos_dir_delete(tarp_rivet_frame_pos_dir_t *self);
void tarp_rivet_frame_pos_dir_set_frame(tarp_rivet_frame_pos_dir_t *self, tarp_frame_t *frame);
tarp_frame_t *tarp_rivet_frame_pos_dir_get_frame(tarp_rivet_frame_pos_dir_t *self);
void tarp_rivet_frame_pos_dir_set_axis(tarp_rivet_frame_pos_dir_t *self, tarp_vector3_t axis);
void tarp_rivet_frame_pos_dir_update(tarp_rivet_frame_pos_dir_t *self, double step, double tick);
void tarp_rivet_frame_pos_dir_update_jacob(tarp_rivet_frame_pos_dir_t *self, int numb);
void tarp_rivet_frame_pos_dir_update_other(tarp_rivet_frame_pos_dir_t *self);
void tarp_rivet_frame_pos_dir_print(tarp_rivet_frame_pos_dir_t *self, FILE *fptr);
void tarp_rivet_frame_pos_dir_set_ref(tarp_rivet_frame_pos_dir_t *self, double ref_dis, double ref_vel, double ref_acc);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_RIVET_FRAME_POS_DIR_H__ */
