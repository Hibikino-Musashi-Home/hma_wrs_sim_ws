/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_vect.h
 *  @defgroup vect vectモジュール
 */
#ifndef __TARP_VECT_H__
#define __TARP_VECT_H__

#include "tarp3/tarp_object.h"

/**
 * @ingroup vect
 * @brief  固定長配列データのクラス
 */
typedef struct {

    /** ベクタの要素数 */
    int                 size;

    /** データ配列へのポインタ */
    void**              data;

} tarp_vect_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_vect.c */
tarp_vect_t *tarp_vect_create(int size);
void tarp_vect_delete(tarp_vect_t *vect);
int tarp_vect_get_size(tarp_vect_t *vect);
void *tarp_vect_get_data(tarp_vect_t *vect, int no);
void *tarp_vect_set_data(tarp_vect_t *vect, int no, void *data);
int tarp_vect_get_index(tarp_vect_t *tarp_vect, void *data);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_VECT_H__ */
