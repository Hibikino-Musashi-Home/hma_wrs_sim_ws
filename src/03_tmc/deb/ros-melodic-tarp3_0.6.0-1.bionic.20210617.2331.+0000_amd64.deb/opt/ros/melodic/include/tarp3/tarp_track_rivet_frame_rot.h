/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_track_rivet_frame_rot.h
 *
 */

#ifndef __TARP_TRACK_RIVET_FRAME_ROT_H__
#define __TARP_TRACK_RIVET_FRAME_ROT_H__

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_frame_rot.h"

typedef struct {

    tarp_track_rivet_t  base;

    tarp_matrix3_t      ref_dis;
    int                 ref_dis_indx[9];
    int                 ref_dis_flag;

    tarp_vector3_t      ref_vel;
    int                 ref_vel_indx;
    int                 ref_vel_flag;

    tarp_vector3_t      ref_acc;
    int                 ref_acc_indx;
    int                 ref_acc_flag;

    tarp_vector3_t      ref_rpy;
    int                 ref_rpy_indx[3];
    int                 ref_rpy_flag;

} tarp_track_rivet_frame_rot_t;

/* tarp_track_rivet_frame_rot.c */
tarp_track_rivet_frame_rot_t *tarp_track_rivet_frame_rot_create(void);
void tarp_track_rivet_frame_rot_delete(tarp_track_rivet_frame_rot_t *self);
void tarp_track_rivet_frame_rot_update(tarp_track_rivet_frame_rot_t *self, double step, double tick);
void tarp_track_rivet_frame_rot_print(tarp_track_rivet_frame_rot_t *self, FILE *fptr);

#endif /* __TARP_TRACK_RIVET_FRAME_ROT_H__ */
