/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  凸二次計画法
 *
 */
#ifndef __BQP2_H__
#define __BQP2_H__

#include "tarp3/tarp_object.h"
#include "tarp3/tarp_matrix.h"

typedef struct {

    /** 変数の数 n */
    /* int n; */

    /** 条件の数 m */
    /* int m; */

    /** もともとの条件の係数行列 */
    tarp_matrix_t* A;

    /** 有効制約条件の係数行列 */
    tarp_matrix_t* B;

    /** 有効制約条件の右辺ベクトル */
    tarp_matrix_t* b;

    /** BのQR分解 */
    tarp_matrix_t* Q;
    tarp_matrix_t* R;

    /** (L^T)^-1 Q */
    tarp_matrix_t* N;

    /* N1とN2に分解して保持する方がいいみたい */
    tarp_matrix_t* N1;
    tarp_matrix_t* N2;

    /* d1 と　d2 */
    tarp_matrix_t* d1;
    tarp_matrix_t* d2;

    /** Dのコレスキー分解 */
    tarp_matrix_t* L;
    tarp_matrix_t* Lt;

    /** 等式条件の係数行列 */
    /* tarp_matrix_t* A0; */

    /** 等式条件の右辺ベクトル */
    /* tarp_matrix_t* b0; */

    /** 目的関数の係数ベクトル */
    tarp_matrix_t* c;

    /** 目的関数の係数行列 */
    tarp_matrix_t* D;

    /** 最小値 */
    tarp_matrix_t* min;

    /** 最大値 */
    tarp_matrix_t* max;

    /** 完全反復で選んだ不等式条件の添え字 */
    int s;

    /** t1を計算する際の添え字 */
    int k;

    /** 主題変数 */
    tarp_matrix_t* x;

    /** 主題変数 */
    /* tarp_matrix_t* x0; */

    /** 双対変数 */
    tarp_matrix_t* v;

    /** 主題変数のstepベクトル */
    tarp_matrix_t* z;

    /** 双対変数のstepベクトル */
    tarp_matrix_t* r;

    /** t1 */
    double t1;

    /** t2 */
    double t2;

    /** 上下限制約のうち、有効制約に入っているものの、A内での添え字を保持した配列 */
    tarp_matrix_t* e;

    double vs;

} tarp_bqp2_t;


/* tarp_bqp2.c */
tarp_bqp2_t *tarp_bqp2_create(tarp_matrix_t *A, tarp_matrix_t *b, tarp_matrix_t *c, tarp_matrix_t *G, tarp_matrix_t *min, tarp_matrix_t *max);
void tarp_bqp2_delete(tarp_bqp2_t *self);
void tarp_bqp2_get_answer(tarp_bqp2_t *self, tarp_matrix_t *x);
void tarp_bqp2_print(tarp_bqp2_t *self, FILE *fp);
int _bqp2_calc_init(tarp_bqp2_t *self);
void _bqp2_select_nearest(tarp_bqp2_t *self);
void _bqp2_calc_step(tarp_bqp2_t *self);
void _bqp2_calc_param_t1(tarp_bqp2_t *self);
void _bqp2_calc_param_t2(tarp_bqp2_t *self);
int _bqp2_update_t2(tarp_bqp2_t *self);
int _bqp2_update_t1(tarp_bqp2_t *self);
int _bqp2_attach_neq(tarp_bqp2_t *self);
int tarp_bqp2_solve(tarp_bqp2_t *self);
void _tarp_bqp2_drop(tarp_bqp2_t *self);
void tarp_bqp2_check(tarp_bqp2_t *self);

#endif /*__BQP2_H__ */

