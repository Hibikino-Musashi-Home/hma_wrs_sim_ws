/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_motor_x.h
 *
 */
#ifndef __TARP_TRACK_MOTOR_X_H__
#define __TARP_TRACK_MOTOR_X_H__

#include "tarp3/tarp_track.h"
#include "tarp3/tarp_motor.h"

enum {
    TARP_TRACK_MOTOR_TYPE_ROBOT_POS,
    TARP_TRACK_MOTOR_TYPE_ROBOT_ROT,
    TARP_TRACK_MOTOR_TYPE_JOINT,
    TARP_TRACK_MOTOR_TYPE_CLOUD,
};

typedef struct {

    /* 親クラス */
    tarp_track_t base;

    /** type */
    int type;

    /* 対象motor */
    tarp_motor_t* motor;

} tarp_track_motor_t;

#endif /* TARP_TRACK_MOTOR_X_H_ */
