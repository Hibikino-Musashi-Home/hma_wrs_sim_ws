/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_agent.h
 *  @defgroup   agent agentモジュール
 *
 *  全身協調制御でrobotを操る上位クラス
 */

#ifndef __TARP_AGENT_H__
#define __TARP_AGENT_H__

#include "tarp3/tarp_robot.h"
#include "tarp3/tarp_iport.h"
#include "tarp3/tarp_oport.h"
#include "tarp3/tarp_strap.h"
#include "tarp3/tarp_rivet.h"
// #include "tarp_touch.h"
#include "tarp3/tarp_phase.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 *  @ingroup    agent
 *  @brief      タスクの構成、優先順位、入出力を管理するクラス
 */
typedef struct {

    /** agentが管理するrobot */
    tarp_robot_t* robot;

    /** iport hash */
    tarp_hash_t* iport_hash;

    /** iport list */
    tarp_list_t* iport_list;

    /** oport hash */
    tarp_hash_t* oport_hash;

    /** oport list */
    tarp_list_t* oport_list;

    /** motor hash */
    tarp_hash_t* motor_hash;

    /** motor list */
    tarp_list_t* motor_list;

    /** strap hash　*/
    tarp_hash_t* strap_hash;

    /** strap list */
    tarp_list_t* strap_list;

    /** rivet hash　*/
    tarp_hash_t* rivet_hash;

    /** touch hash　*/
    tarp_hash_t* touch_hash;

    /** phase traj */
    tarp_traj_t* phase_traj;

    /** 現在処理中のphase */
    tarp_phase_t* phase;

    /** 時刻[s] */
    double tick;

    /** ヤコビ行列 */
    tarp_matrix_t* jacob;

} tarp_agent_t;

/* tarp_agent.c */
tarp_agent_t *tarp_agent_create(void);
void tarp_agent_delete(tarp_agent_t *self);
void tarp_agent_set_robot(tarp_agent_t *self, tarp_robot_t *robot);
tarp_rivet_t *tarp_agent_lookup_rivet(tarp_agent_t *self, const char *name);
void tarp_agent_update_iport(tarp_agent_t *self, double tick);
void tarp_agent_update_oport(tarp_agent_t *self, double step, double tick);
void tarp_agent_update_motor(tarp_agent_t *self, double step, double tick);
int tarp_agent_update(tarp_agent_t *self, double step, double tick);
void tarp_agent_print(tarp_agent_t *self, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_AGENT_H__ */
