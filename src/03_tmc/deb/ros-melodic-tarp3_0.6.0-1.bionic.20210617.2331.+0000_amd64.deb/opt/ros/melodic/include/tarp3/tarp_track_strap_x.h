/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_strap_x.h
 *
 */
#ifndef __TARP_TRACK_STRAP_X_H__
#define __TARP_TRACK_STRAP_X_H__

#include "tarp3/tarp_track.h"
#include "tarp3/tarp_strap.h"

enum {
    TARP_TRACK_STRAP_TYPE_ROBOT_POS,
    TARP_TRACK_STRAP_TYPE_ROBOT_ROT,
    TARP_TRACK_STRAP_TYPE_JOINT,
};

typedef struct {

    /* 親クラス */
    tarp_track_t base;

    /** type */
    int type;

    /* 対象strap */
    tarp_strap_t* strap;

    int flag;

} tarp_track_strap_t;

#endif /* __TARP_TRACK_STRAP_X_H__ */
