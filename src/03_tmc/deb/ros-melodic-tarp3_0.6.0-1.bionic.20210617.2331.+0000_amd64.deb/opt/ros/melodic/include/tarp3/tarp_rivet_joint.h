/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  関節の速度に対する拘束条件
 *
 */

#ifndef TARP_RIVET_JOINT_H_
#define TARP_RIVET_JOINT_H_

#include "tarp3/tarp_rivet.h"

typedef struct {
    /** 親クラス */
    tarp_rivet_t base;

    /** joint */
    tarp_joint_t* joint;

    /** 目標変位 */
    double          ref_dis;

    /** 目標速度 */
    double          ref_vel;

    /** 目標加速度 */
    double ref_acc;

    /** 目標躍度 */
    double          ref_jrk;

    /** 目標変位 */
    double          act_dis;

    /** 目標速度 */
    double          act_vel;

    /** 目標加速度 */
    double          act_acc;

} tarp_rivet_joint_t;

/* tarp_rivet_joint.c */
tarp_rivet_joint_t *tarp_rivet_joint_create(void);
void tarp_rivet_joint_delete(tarp_rivet_joint_t *self);
void tarp_rivet_joint_update(tarp_rivet_joint_t *self, double step, double tick);
double tarp_rivet_joint_get_act_vel(tarp_rivet_joint_t *self);
double tarp_rivet_joint_get_act_acc(tarp_rivet_joint_t *self);
double tarp_rivet_joint_get_act_jrk(tarp_rivet_joint_t *self);
void tarp_rivet_joint_update_jacob(tarp_rivet_joint_t *self, int numb);
void tarp_rivet_joint_update_other(tarp_rivet_joint_t *self);
void tarp_rivet_joint_set_ref(tarp_rivet_joint_t *self, double dis, double vel, double acc);
void tarp_rivet_joint_print(tarp_rivet_joint_t *self, FILE *fptr);

#endif /* TARP_RIVET_JOINT_H_ */
