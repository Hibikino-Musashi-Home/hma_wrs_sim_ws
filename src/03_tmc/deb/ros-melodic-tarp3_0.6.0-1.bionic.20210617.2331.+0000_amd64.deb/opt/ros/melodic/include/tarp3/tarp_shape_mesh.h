/* Copyright (C) 2016 Toyota Motor Corporation */


#define STL_
