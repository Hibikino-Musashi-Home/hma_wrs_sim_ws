/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_trail_motor_robot_rot.h
 *
 */
#ifndef __TARP_TRAIL_MOTOR_ROBOT_ROT_H__
#define __TARP_TRAIL_MOTOR_ROBOT_ROT_H__

#include "tarp3/tarp_trail_motor.h"

typedef struct {

    tarp_trail_motor_t base;

    double ref_dis;
    double ref_vel;
    double ref_acc;

} tarp_trail_motor_robot_rot_t;

tarp_trail_motor_robot_rot_t* tarp_trail_motor_robot_rot_create (void);
void tarp_trail_motor_robot_rot_delete (tarp_trail_motor_robot_rot_t* self);
void tarp_trail_motor_robot_rot_print (tarp_trail_motor_robot_rot_t* self, FILE* fptr);

#endif /* __TARP_TRAIL_MOTOR_ROBOT_ROT_H__ */
