/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_psqp.h
 * @defgroup psqp
 */
#ifndef __TARP_PSQP_H__
#define __TARP_PSQP_H__

#include "tarp3/tarp_object.h"
#include "tarp3/tarp_matrix.h"
#include "tarp3/tarp_sqpn.h"

#ifndef INFINITY
#define INFINITY    (10e+24)
#endif

#ifndef EPSILON
#define EPSILON     (10e-24)
#endif

typedef struct {
    /** ユーザ変数の数 */
    int numb;

    /** 解の存在が確認済の条件行列 */
    tarp_matrix_t* A_now;
    /** 解の存在が確認済の条件ベクトル */
    tarp_matrix_t* b_now;
    /** 解の存在が確認済の下限ベクトル */
    tarp_matrix_t* x_now_min;
    /** 解の存在が確認済の上限ベクトル */
    tarp_matrix_t* x_now_max;

    /** 目的関数のための条件行列 */
    tarp_matrix_t* A_cnd;
    /** 目的関数のための条件ベクトル */
    tarp_matrix_t* b_cnd;

    /** 解の存在が未確認の条件行列 */
    tarp_matrix_t* A_chk;
    /** 解の存在が未確認の条件ベクトル */
    tarp_matrix_t* b_chk;
    /** 解の存在が未確認の下限ベクトル */
    tarp_matrix_t* x_chk_min;
    /** 解の存在が未確認の上限ベクトル */
    tarp_matrix_t* x_chk_max;

    /** 変数ベクトル */
    tarp_matrix_t* x;
} tarp_psqp_t;

/* tarp_psqp.c */
tarp_psqp_t *tarp_psqp_create(tarp_matrix_t *x_min, tarp_matrix_t *x_max);
void tarp_psqp_delete(tarp_psqp_t *self);
void tarp_psqp_clear(tarp_psqp_t *self);
int tarp_psqp_setup_eqn(tarp_psqp_t *self, tarp_matrix_t *A, tarp_matrix_t *b);
int tarp_psqp_setup_neq(tarp_psqp_t *self, tarp_matrix_t *A, tarp_matrix_t *b, tarp_matrix_t *b_min, tarp_matrix_t *b_max);
int tarp_psqp_check(tarp_psqp_t *self);
void tarp_psqp_apply(tarp_psqp_t *self);
void tarp_psqp_calc_time(int init, int no);
void tarp_scaling(tarp_matrix_t *A, tarp_matrix_t *b);
int tarp_psqp_solve(tarp_psqp_t *self, tarp_matrix_t *ref);
void tarp_psqp_get_answer(tarp_psqp_t *self, tarp_matrix_t *answer);
void tarp_psqp_print(tarp_psqp_t *self, FILE *file);
int tarp_psqp_setup_fin(tarp_psqp_t *self, tarp_matrix_t *A, tarp_matrix_t *b);

#endif /* __TARP_PSQP_H__ */
