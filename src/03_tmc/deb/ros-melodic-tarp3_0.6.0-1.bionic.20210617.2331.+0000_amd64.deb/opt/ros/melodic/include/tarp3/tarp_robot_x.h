/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   robot.h
 *
 */

#ifndef __TARP_ROBOT_X_H__
#define __TARP_ROBOT_X_H__

#include "tarp3/tarp_hash.h"
#include "tarp3/tarp_matrix3.h"
// #include "tarp_world.h"
#include "tarp3/tarp_frame.h"
#include "tarp3/tarp_joint.h"

/**
 * @ingroup robot
 * @brief   robot構造体
 */
typedef struct {

    /** 親クラス */
    tarp_gizmo_t gizmo;

    /** 指令速度退避用のスロット */
    tarp_vector3_t pos_vel_save;
    tarp_vector3_t rot_vel_save;

    tarp_vector3_t pos_acc_save;
    tarp_vector3_t rot_acc_save;

    /** robotのZMP(local) */
    tarp_vector3_t zmp_dis;

    /* ハッシュテーブル */
    tarp_hash_t* hash;

} tarp_robot_t;

#endif /* __TARP_ROBOT_H__ */
