/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_vector2.h
 *  @defgroup vector2 vector2モジュール
 *
 *  2次元のベクトルを扱うモジュールです。
 */
#ifndef __VECTOR2_H__
#define __VECTOR2_H__

#include <math.h>

typedef double tarp_vector2_t[2];

#ifdef __cplusplus
extern "C" {
#endif

extern tarp_vector2_t tarp_vector2_zero;

/* tarp_vector2.c */
int tarp_vector2_is_equal(tarp_vector2_t a, tarp_vector2_t b);
void tarp_vector2_set_zero(tarp_vector2_t a);
void tarp_vector2_set_string(tarp_vector2_t a, const char *s);
void tarp_vector2_get_string(tarp_vector2_t a, char *s);
void tarp_vector2_copy(tarp_vector2_t a, tarp_vector2_t b);
void tarp_vector2_set_vector2(tarp_vector2_t a, tarp_vector2_t b);
void tarp_vector2_swap(tarp_vector2_t a, tarp_vector2_t b);
void tarp_vector2_negate(tarp_vector2_t a, tarp_vector2_t b);
void tarp_vector2_add_vector2(tarp_vector2_t a, tarp_vector2_t b, tarp_vector2_t c);
void tarp_vector2_sub_vector2(tarp_vector2_t a, tarp_vector2_t b, tarp_vector2_t c);
void tarp_vector2_scale(tarp_vector2_t a, tarp_vector2_t b, double x);
double tarp_vector2_dot(tarp_vector2_t a, tarp_vector2_t b);
double tarp_vector2_norm(tarp_vector2_t a);
double tarp_vector2_get_sum_of_square(tarp_vector2_t a);
double tarp_vector2_cross(tarp_vector2_t a, tarp_vector2_t b);
double tarp_vector2_normalize(tarp_vector2_t a, tarp_vector2_t b);
void tarp_vector2_get_shift_vector(tarp_vector2_t v1, tarp_vector2_t d0, tarp_vector2_t v0, tarp_vector2_t d1);

#ifdef __cplusplus
}
#endif
#endif				/* __MATRIX2_H__ */
