/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_motor.h
 *
 */
#ifndef __TARP_TRAIL_MOTOR_H__
#define __TARP_TRAIL_MOTOR_H__

#include "tarp3/tarp_trail_motor_x.h"
#include "tarp3/tarp_trail_motor_robot_pos.h"
#include "tarp3/tarp_trail_motor_robot_rot.h"
#include "tarp3/tarp_trail_motor_joint.h"

/* tarp_trail_motor.c */
void tarp_trail_motor_init(tarp_trail_motor_t *self, int type);
void tarp_trail_motor_update(tarp_trail_motor_t *self, double step);
void tarp_trail_motor_print(tarp_trail_motor_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_MOTOR_H__ */
