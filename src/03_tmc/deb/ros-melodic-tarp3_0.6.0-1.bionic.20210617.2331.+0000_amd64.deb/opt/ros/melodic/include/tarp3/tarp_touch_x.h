/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_touch_x.h
 *
 */
#ifndef __TARP_TOUCH_X_H__
#define __TARP_TOUCH_X_H__

#include "tarp3/tarp_frame.h"

typedef struct {

    /** touchのタイプ */
    int type;

    /** 名前 */
    char name[256];

} tarp_touch_t;

#endif /* __TARP_TOUCH_X_H__ */
