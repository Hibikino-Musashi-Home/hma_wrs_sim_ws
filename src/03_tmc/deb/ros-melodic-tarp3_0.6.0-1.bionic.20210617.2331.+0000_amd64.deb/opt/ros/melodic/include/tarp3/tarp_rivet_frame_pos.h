/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_rivet_frame_pos.h
 *  @defgroup rivet_frame_pos rivet_frame_posモジュール
 *  @brief frame原点に対する世界座標系での位置(x,y,z)の拘束を定義するモジュール
 */
#ifndef __TARP_RIVET_FRAME_POS_H__
#define __TARP_RIVET_FRAME_POS_H__

#include "tarp3/tarp_rivet.h"

/**
 * @ingroup rivet_frame_pos
 * @brief frame原点に対する世界座標系での位置(x,y,z)の拘束を定義するクラス
 */
typedef struct {

    /** 親クラス　*/
    tarp_rivet_t    base;

    /** 対象frame */
    tarp_frame_t*   frame;

    int ref_dis_indx[3];
    /** 目標変位 */
    tarp_vector3_t  ref_dis;

    /** 目標速度 */
    tarp_vector3_t  ref_vel;

    /** 目標加速度 */
    tarp_vector3_t  ref_acc;

    /** 目標躍度 */
    tarp_vector3_t  ref_jrk;

    /** 現在の変位 */
    tarp_vector3_t  act_dis;

    /** 現在の速度 */
    tarp_vector3_t  act_vel;

    /** 現在の加速度 */
    tarp_vector3_t  act_acc;

} tarp_rivet_frame_pos_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_rivet_frame_pos.c */
tarp_rivet_frame_pos_t *tarp_rivet_frame_pos_create(void);
void tarp_rivet_frame_pos_delete(tarp_rivet_frame_pos_t *self);
void tarp_rivet_frame_pos_set_frame(tarp_rivet_frame_pos_t *self, tarp_frame_t *frame);
tarp_frame_t *tarp_rivet_frame_pos_get_frame(tarp_rivet_frame_pos_t *self);
void tarp_rivet_frame_pos_update(tarp_rivet_frame_pos_t *self, double step, double tick);
void tarp_rivet_frame_pos_update_jacob(tarp_rivet_frame_pos_t *self, int numb);
void tarp_rivet_frame_pos_update_other(tarp_rivet_frame_pos_t *self);
void tarp_rivet_frame_pos_print(tarp_rivet_frame_pos_t *self, FILE *fptr);
void tarp_rivet_frame_pos_set_ref(tarp_rivet_frame_pos_t *self, tarp_vector3_t ref_dis, tarp_vector3_t ref_vel, tarp_vector3_t ref_acc);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_RIVET_FRAME_POS_H__ */
