/* Copyright (C) 2016 Toyota Motor Corporation */
#ifndef __TARP_LINSEG_H__
#define __TARP_LINSEG_H__

#include "tarp3/tarp_object.h"
#include "tarp3/tarp_vector3.h"

typedef struct {
	/* 始点 */
	tarp_vector3_t p;

	/* 終点 */
	tarp_vector3_t q;

} tarp_linseg_t;

/* tarp_linseg.c */
tarp_linseg_t *tarp_linseg_create(void);
void tarp_linseg_delete(tarp_linseg_t *self);
void tarp_linseg_set_head(tarp_linseg_t *self, double x, double y, double z);
void tarp_linseg_set_tail(tarp_linseg_t *self, double x, double y, double z);
double clamp(double n, double min, double max);
double linseg_get_closest(tarp_vector3_t p1, tarp_vector3_t q1, tarp_vector3_t p2, tarp_vector3_t q2, double *s, double *t, tarp_vector3_t c1, tarp_vector3_t c2);
double tarp_linseg_get_closest (tarp_linseg_t* s1, tarp_linseg_t* s2, tarp_vector3_t c1, tarp_vector3_t c2);


#endif /* __TARP_LINSEG_H__ */
