/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_touch_frame_pos.h
 *
 */

#ifndef __TARP_TOUCH_FRAME_POS_H__
#define __TARP_TOUCH_FRAME_POS_H__

#include "tarp3/tarp_touch.h"

typedef struct {

    /** 親クラス　*/
    tarp_touch_t base;

    /** 対象frame */
    tarp_frame_t* frame;

    /** 軸方向 */
    tarp_vector3_t axis;

    /** 指令位置 */
    double ref_dis;
    double ref_vel;
    double ref_acc;

} tarp_touch_frame_pos_t;

tarp_touch_frame_pos_t* tarp_touch_frame_pos_create (void);
void tarp_touch_frame_pos_delete (tarp_touch_frame_pos_t* self);
void tarp_touch_frame_pos_print (tarp_touch_frame_pos_t* self, FILE* fptr);

#endif /* __TARP_TOUCH_FRAME_POS_H__ */
