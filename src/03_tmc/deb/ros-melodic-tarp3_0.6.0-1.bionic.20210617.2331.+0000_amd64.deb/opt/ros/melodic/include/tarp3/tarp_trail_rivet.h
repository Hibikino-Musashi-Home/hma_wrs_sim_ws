/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_H__
#define __TARP_TRAIL_RIVET_H__

#include "tarp3/tarp_trail_rivet_x.h"
#include "tarp3/tarp_trail_rivet_robot_cog.h"
#include "tarp3/tarp_trail_rivet_robot_moi.h"
#include "tarp3/tarp_trail_rivet_robot_zmp.h"
#include "tarp3/tarp_trail_rivet_frame_pos.h"
#include "tarp3/tarp_trail_rivet_frame_rot.h"
#include "tarp3/tarp_trail_rivet_frame_dir.h"
#include "tarp3/tarp_trail_rivet_frame_gap.h"
#include "tarp3/tarp_trail_rivet_shape_ssv.h"
#include "tarp3/tarp_trail_rivet_joint.h"

/* tarp_trail_rivet.c */
void tarp_trail_rivet_init(tarp_trail_rivet_t *self, int type);
void tarp_trail_rivet_update(tarp_trail_rivet_t *self, double step, double tick);
void tarp_trail_rivet_print(tarp_trail_rivet_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_H__ */
