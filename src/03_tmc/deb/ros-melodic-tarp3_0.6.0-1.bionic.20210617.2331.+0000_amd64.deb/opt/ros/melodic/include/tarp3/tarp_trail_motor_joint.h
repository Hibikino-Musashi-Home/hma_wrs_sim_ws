/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_motor_joint.h
 *
 */
#ifndef __TARP_TRAIL_MOTOR_JOINT_H__
#define __TARP_TRAIL_MOTOR_JOINT_H__

#include "tarp3/tarp_trail_motor.h"

/**
 *  @brief  motorに対する軌跡
 *
 */
typedef struct {
    /* 親クラス */
    tarp_trail_motor_t base;

    /* 変位 */
    double ref_dis;

    /* 速度 */
    double ref_vel;

    /* 加速 */
    double ref_acc;

} tarp_trail_motor_joint_t;

tarp_trail_motor_joint_t* tarp_trail_motor_joint_create (int type);
void tarp_trail_motor_joint_delete (tarp_trail_motor_joint_t* self);
void tarp_trail_motor_joint_print (tarp_trail_motor_joint_t* self, FILE* fptr);

#endif /* __TARP_TRAIL_MOTOR_JOINT_H__ */
