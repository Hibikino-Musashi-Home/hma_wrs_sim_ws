/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_rivet_x.h
 *
 */
#ifndef __TARP_TRACK_RIVET_X_H__
#define __TARP_TRACK_RIVET_X_H__

#include "tarp3/tarp_track.h"
#include "tarp3/tarp_rivet.h"

enum {
    TARP_TRACK_RIVET_TYPE_ROBOT_POS,
    TARP_TRACK_RIVET_TYPE_ROBOT_ROT,
    TARP_TRACK_RIVET_TYPE_ROBOT_COG,
    TARP_TRACK_RIVET_TYPE_ROBOT_MOI,
    TARP_TRACK_RIVET_TYPE_ROBOT_ZMP,
    TARP_TRACK_RIVET_TYPE_FRAME_POS,
    TARP_TRACK_RIVET_TYPE_FRAME_ROT,
    TARP_TRACK_RIVET_TYPE_FRAME_DIR,
    TARP_TRACK_RIVET_TYPE_JOINT,
    TARP_TRACK_RIVET_TYPE_NUMB,
};

typedef struct {

    /* 親クラス */
    tarp_track_t base;

    /* type */
    int type;

    /* 対象rivet */
    tarp_rivet_t* rivet;

} tarp_track_rivet_t;

#endif /* __TARP_TRACK_RIVET_X_H__ */
