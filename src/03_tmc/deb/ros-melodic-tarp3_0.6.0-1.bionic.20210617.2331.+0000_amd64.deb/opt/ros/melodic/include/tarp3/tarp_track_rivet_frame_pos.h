/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_rivet_frame_pos.h
 *
 */
#ifndef __TARP_TRACK_RIVET_FRAME_POS_H__
#define __TARP_TRACK_RIVET_FRAME_POS_H__

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_frame_pos.h"

typedef struct {

    tarp_track_rivet_t base;

    tarp_frame_t* frame;

    tarp_vector3_t ref_dis;
    int ref_dis_indx[3];

    tarp_vector3_t ref_vel;
    int ref_vel_indx[3];

    tarp_vector3_t ref_acc;
    int ref_acc_indx[3];

    int intp_flag;

} tarp_track_rivet_frame_pos_t;

/* tarp_track_rivet_frame_pos.c */
tarp_track_rivet_frame_pos_t *tarp_track_rivet_frame_pos_create(void);
void tarp_track_rivet_frame_pos_delete(tarp_track_rivet_frame_pos_t *self);
void tarp_track_rivet_frame_pos_update(tarp_track_rivet_frame_pos_t *self, double step, double tick);
void tarp_track_rivet_frame_pos_print(tarp_track_rivet_frame_pos_t *self, FILE *fptr);

#endif /* __TARP_TRACK_RIVET_FRAME_POS_H__ */
