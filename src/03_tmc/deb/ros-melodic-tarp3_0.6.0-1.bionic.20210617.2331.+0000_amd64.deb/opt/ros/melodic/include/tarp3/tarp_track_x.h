/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_x.h
 */
#ifndef __TARP_TRACK_X_H__
#define __TARP_TRACK_X_H__

#include "tarp3/tarp_iport.h"

enum {
    TARP_TRACK_TYPE_MOTOR,
    TARP_TRACK_TYPE_STRAP,
    TARP_TRACK_TYPE_RIVET,
    TARP_TRACK_TYPE_TOUCH,
};

/**
 *  @brief  軌道クラス
 *
 */
typedef struct {

    /* 種別 */
    int type;

    /* 名前 */
    char name[256];

    /* 時刻 */
    double tick;

    /* 入力ポート */
    tarp_iport_t* iport;

} tarp_track_t;

#endif /* TARP_TRACK_H_ */
