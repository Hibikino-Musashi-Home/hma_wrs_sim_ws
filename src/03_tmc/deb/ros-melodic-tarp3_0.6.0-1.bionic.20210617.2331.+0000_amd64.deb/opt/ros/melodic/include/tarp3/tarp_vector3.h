/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file     tarp_vector3.h
 *  @defgroup vector3 vector3モジュール
 */

#ifndef __VECTOR3_H__
#define __VECTOR3_H__

#include <stdio.h>
#include <math.h>
#include <float.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 *  @ingroup    vector3
 *  @brief      3次元列ベクトル
 */
typedef double tarp_vector3_t[3];

    extern const tarp_vector3_t tarp_vector3_zero;
    extern const tarp_vector3_t tarp_vector3_unit_x;
    extern const tarp_vector3_t tarp_vector3_unit_y;
    extern const tarp_vector3_t tarp_vector3_unit_z;

/* ../../src/tarp_vector3.c */
int tarp_vector3_is_equal(const tarp_vector3_t a, const tarp_vector3_t b);
int tarp_vector3_is_near(const tarp_vector3_t a, const tarp_vector3_t b, const double e);
double tarp_deg2rad(double d);
double tarp_rad2deg(double r);
void tarp_vector3_set_string(tarp_vector3_t a, const char *s);
void tarp_vector3_get_string(const tarp_vector3_t a, char *s);
const char *tarp_vector3_string(const tarp_vector3_t a);
void tarp_vector3_set_zero(tarp_vector3_t a);
void tarp_vector3_copy(tarp_vector3_t a, const tarp_vector3_t b);
void tarp_vector3_add_vector3(tarp_vector3_t a, const tarp_vector3_t b, const tarp_vector3_t c);
void tarp_vector3_sub_vector3(tarp_vector3_t a, const tarp_vector3_t b, const tarp_vector3_t c);
void tarp_vector3_scale(tarp_vector3_t a, const tarp_vector3_t b, double x);
double tarp_vector3_dot(const tarp_vector3_t a, const tarp_vector3_t b);
void tarp_vector3_cross(tarp_vector3_t a, const tarp_vector3_t b, const tarp_vector3_t c);
double tarp_vector3_norm(const tarp_vector3_t a);
double tarp_vector3_normalize(tarp_vector3_t a, const tarp_vector3_t b);
int tarp_vector3_print(tarp_vector3_t v, FILE *fp);

#ifdef __cplusplus
}
#endif

#endif /* __VECTOR3_H__ */
