/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_strap_joint.h
 * @defgroup strap_joint strap_joint モジュール
 *
 * jointを動作させるための仕組み(strap)を定義するモジュールです。
 */

#ifndef __TARP_STRAP_JOINT_H__
#define __TARP_STRAP_JOINT_H__

#include "tarp3/tarp_strap.h"
#include "tarp3/tarp_limit.h"

typedef struct {
    /** super class */
    tarp_strap_t base;
    /** joint to use */
    tarp_joint_t* joint;
    /** 関節の変位 */
    double dis;
    /** 関節の速度 */
    double vel;
    /** 関節の加速度 */
    double acc;
    /** 関節の躍度 */
    double jrk;
    /** 関節の制約 */
    tarp_limit_t* limit;

    /** 変位下限 */
    double min_dis;
    /** 変位上限 */
    double max_dis;
    /** 速度下限 */
    double min_vel;
    /** 速度上限 */
    double max_vel;
    /** 加速度下限 */
    double min_acc;
    /** 加速度上限 */
    double max_acc;
    /** 躍度下限 */
    double min_jrk;
    /** 躍度上限 */
    double max_jrk;

} tarp_strap_joint_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_strap_joint.c */
tarp_strap_joint_t *tarp_strap_joint_create(void);
void tarp_strap_joint_delete(tarp_strap_joint_t *self);
void tarp_strap_joint_set_joint(tarp_strap_joint_t *self, tarp_joint_t *joint);
tarp_joint_t *tarp_strap_joint_get_joint(tarp_strap_joint_t *self);
int tarp_strap_joint_update(tarp_strap_joint_t *self, double step, double tick);
void tarp_strap_joint_save(tarp_strap_joint_t *self);
void tarp_strap_joint_load(tarp_strap_joint_t *self);
double tarp_strap_joint_get_act_dis(tarp_strap_joint_t *self, int numb);
double tarp_strap_joint_get_act_vel(tarp_strap_joint_t *self, int numb);
double tarp_strap_joint_get_act_acc(tarp_strap_joint_t *self, int numb);
double tarp_strap_joint_get_act_jrk(tarp_strap_joint_t *self, int numb);
void tarp_strap_joint_set_ref_vel(tarp_strap_joint_t *self, int numb, double vel);
void tarp_strap_joint_set_ref_acc(tarp_strap_joint_t *self, int numb, double acc);
void tarp_strap_joint_set_ref_jrk(tarp_strap_joint_t *self, int numb, double jrk);
void tarp_strap_joint_apply_jrk(tarp_strap_joint_t *self, double step);
double tarp_strap_joint_get_min_jrk(tarp_strap_joint_t *self, double step);
double tarp_strap_joint_get_max_jrk(tarp_strap_joint_t *self, double step);
void tarp_strap_joint_print(tarp_strap_joint_t *self, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_STRAP_JOINT_H__ */
