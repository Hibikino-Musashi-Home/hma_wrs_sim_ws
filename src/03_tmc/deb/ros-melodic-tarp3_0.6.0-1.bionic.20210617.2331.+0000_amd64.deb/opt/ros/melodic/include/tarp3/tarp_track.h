/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file    tarp_track.h
 *
 */
#ifndef __TARP_TRACK_H__
#define __TARP_TRACK_H__

#include "tarp3/tarp_track_x.h"
#include "tarp3/tarp_track_strap.h"
#include "tarp3/tarp_track_motor.h"
#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_track_touch.h"

/* tarp_track.c */
void tarp_track_init(tarp_track_t *self, int type);
void tarp_track_update(tarp_track_t *self, double step, double tick);
void tarp_track_print(tarp_track_t *self, FILE *fptr);
void tarp_track_set_intp(tarp_track_t *self, int intp);
void tarp_track_setup(tarp_track_t *self, double tick);

#endif /* __TARP_TRACK_H__ */
