/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_gizmo_robot.h
 *
 *  Created on: 2010/07/30
 *      Author: tajima
 */

#ifndef TARP_TRACK_GIZMO_ROBOT_H_
#define TARP_TRACK_GIZMO_ROBOT_H_

#include "tarp3/tarp_track_gizmo.h"

typedef struct {

    /* 親クラス */
    tarp_track_gizmo_t super;

    /* 指令値 */
    tarp_vector3_t pos_dis;
    tarp_vector3_t pos_dis_head;
    tarp_vector3_t pos_dis_tail;

    tarp_matrix3_t rot_dis;
    tarp_matrix3_t rot_dis_head;
    tarp_matrix3_t rot_dis_tail;

    /* 姿勢補間の軸 */
    tarp_vector3_t axis;

    interp_poly3_t intp_pos[3];
    interp_poly3_t intp_rot;

} tarp_track_gizmo_robot_t;

tarp_track_gizmo_robot_t* tarp_track_gizmo_robot_create (void);
void tarp_track_gizmo_robot_delete (tarp_track_gizmo_robot_t* self);
void tarp_track_gizmo_robot_setup (tarp_track_gizmo_robot_t* self);
int tarp_track_gizmo_robot_load_fptr (tarp_track_gizmo_robot_t* self, FILE* fptr);
int tarp_track_gizmo_robot_update (tarp_track_gizmo_robot_t* self, double tick);


#endif /* TARP_TRACK_GIZMO_ROBOT_H_ */
