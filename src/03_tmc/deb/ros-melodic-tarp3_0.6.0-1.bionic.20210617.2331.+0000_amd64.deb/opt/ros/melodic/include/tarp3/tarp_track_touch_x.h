/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_track_touch_x.h
 *
 */
#ifndef __TARP_TRACK_TOUCH_X_H__
#define __TARP_TRACK_TOUCH_X_H__

#include "tarp3/tarp_track.h"
#include "tarp3/tarp_touch.h"

enum {
    TARP_TRACK_TOUCH_TYPE_FRAME_POS,
    TARP_TRACK_TOUCH_TYPE_FRAME_ROT,
};

typedef struct {

    /* 親クラス */
    tarp_track_t base;

    /* type */
    int type;

    /* 対象touch */
    tarp_touch_t* touch;

} tarp_track_touch_t;

#endif /* __TARP_TRACK_TOUCH_X_H__ */
