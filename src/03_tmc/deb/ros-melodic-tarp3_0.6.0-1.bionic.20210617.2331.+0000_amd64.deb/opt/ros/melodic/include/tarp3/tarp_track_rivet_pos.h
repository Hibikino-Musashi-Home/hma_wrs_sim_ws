/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_rivet_pos.h
 *
 *  Created on: 2010/07/30
 *      Author: tajima
 */

#ifndef TARP_TRACK_RIVET_POS_H_
#define TARP_TRACK_RIVET_POS_H_

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_pos.h"

typedef struct {
    tarp_track_rivet_t super;

    tarp_vector3_t pos_dis;
    tarp_vector3_t pos_dis_head;
    tarp_vector3_t pos_dis_tail;

    interp_poly3_t intp3_pos[3];
    interp_poly5_t intp5_pos[3];

} tarp_track_rivet_pos_t;

/* tarp_track_rivet_pos.c */
tarp_track_rivet_pos_t *tarp_track_rivet_pos_create(void);
void tarp_track_rivet_pos_delete(tarp_track_rivet_pos_t *self);
void tarp_track_rivet_pos_setup(tarp_track_rivet_pos_t *self);
int tarp_track_rivet_pos_load_fptr(tarp_track_rivet_pos_t *self, FILE *fptr);
int tarp_track_rivet_pos_update(tarp_track_rivet_pos_t *self, double step);

#endif /* TARP_TRACK_RIVET_POS_H_ */
