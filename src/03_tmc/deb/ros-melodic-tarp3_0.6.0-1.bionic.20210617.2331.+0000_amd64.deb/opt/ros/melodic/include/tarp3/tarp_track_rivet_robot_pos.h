/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_rivet_robot_pos.h
 *
 */

#ifndef __TARP_TRACK_RIVET_ROBOT_POS_H__
#define __TARP_TRACK_RIVET_ROBOT_POS_H__

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_robot_pos.h"

typedef struct {

    tarp_track_rivet_t base;

    tarp_robot_t* robot;

    int ref_dis_indx;
    int ref_vel_indx;
    int ref_acc_indx;

    double ref_dis;
    double ref_vel;
    double ref_acc;

    double ref_dis_head;
    double ref_vel_head;
    double ref_acc_head;

    double ref_dis_tail;
    double ref_vel_tail;
    double ref_acc_tail;

    tarp_vector3_t axis;

#if 0
    /* 3次多項式補間 */
    interp_poly3_t intp3;

    /* 5次多項式補間 */
    interp_poly5_t intp5;
#endif

} tarp_track_rivet_robot_pos_t;

/* tarp_track_rivet_robot_pos.c */
tarp_track_rivet_robot_pos_t *tarp_track_rivet_robot_pos_create(void);
void tarp_track_rivet_robot_pos_delete(tarp_track_rivet_robot_pos_t *self);
void tarp_track_rivet_robot_pos_setup_ref(tarp_track_rivet_robot_pos_t *self, double tick);
void tarp_track_rivet_robot_pos_setup(tarp_track_rivet_robot_pos_t *self, double tick);
int tarp_track_rivet_robot_pos_update(tarp_track_rivet_robot_pos_t *self, double tick, double step);
void tarp_track_rivet_robot_pos_print(tarp_track_rivet_robot_pos_t *self, FILE *fptr);

#endif /* __TARP_TRACK_RIVET_ROBOT_POS_H__ */
