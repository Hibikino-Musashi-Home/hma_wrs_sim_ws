/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_blp.h
 * @brief 線形計画法モジュール (BLP:Bounded Linear Programming)
 * @defgroup blp
 */
#ifndef __BLP_H__
#define __BLP_H__

#include "tarp3/tarp_object.h"
#include "tarp3/tarp_matrix.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @ingroup blp
 * @brief  線形計画法クラス
 */
typedef struct {

    /** 基底変数の数 */
    int m;

    /** 非基底変数の数 */
    int n;

    /** A行列 */
    tarp_matrix_t* A;

    /** b行列 */
    tarp_matrix_t* b;

    /** c行列 */
    tarp_matrix_t* c;

    /** 最適値 */
    double z;

    /** 最適値 */
    double delta;

    int up;

    /** 下限 */
    tarp_matrix_t* l;

    /** 上限 */
    tarp_matrix_t* u;

    /** 1:上限な非基底変数 */
    int* upbnd;

    /** 非基底変数を示す配列 */
    int* nbas;

    /** 基底変数を示す配列 */
    int* ibas;

    /** 基底から非基底になる変数 */
    int pivrow;

    /** 非基底から基底になる変数 */
    int pivcol;

} tarp_blp_t;

/* ../../src/tarp_blp.c */
tarp_blp_t *tarp_blp_create(int m, int n);
void tarp_blp_set_objective(tarp_blp_t *self, tarp_matrix_t *c);
void tarp_blp_set_eqn(tarp_blp_t *self, tarp_matrix_t *A, tarp_matrix_t *b);
void tarp_blp_set_neq(tarp_blp_t *self, tarp_matrix_t *l, tarp_matrix_t *u);
tarp_blp_t *tarp_blp_create2(tarp_matrix_t *A, tarp_matrix_t *b, tarp_matrix_t *c, tarp_matrix_t *min, tarp_matrix_t *max);
void tarp_blp_delete(tarp_blp_t *self);
void tarp_blp_rtest(tarp_blp_t *self);
void tarp_blp_pivot(tarp_blp_t *self);
void blp_drvout(tarp_blp_t *self);
void tarp_blp_update(tarp_blp_t *self);
int tarp_blp_chkopt(tarp_blp_t *self);
int blp_phase_1(tarp_blp_t *self, tarp_matrix_t *x);
int blp_phase_2(tarp_blp_t *self);
int tarp_blp_check(tarp_blp_t *self, tarp_matrix_t *x);
void tarp_blp_get_answer(tarp_blp_t *self, tarp_matrix_t *x);
void tarp_blp_print(tarp_blp_t *self, FILE *fp);
void blp_print_answer(tarp_blp_t *self, FILE *fp);

#ifdef __cplusplus
}
#endif

#endif /*__BLP_H__ */
