/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_robot_rot.h
 *
 *  Created on: 2009/11/10
 *      Author: tajima
 */

#ifndef __TARP_RIVET_ROBOT_ROT_H__
#define __TARP_RIVET_ROBOT_ROT_H__

#include "tarp3/tarp_rivet.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t base;

    /** 対象gizmo */
    tarp_robot_t* robot;

    /** 軸方向 */
    tarp_vector3_t axis;

    /** 指令位置 */
    tarp_vector3_t ref_dis;

    double ref_vel;
    double ref_acc;

} tarp_rivet_robot_rot_t;

/* tarp_rivet_robot_rot.c */
tarp_rivet_robot_rot_t *tarp_rivet_robot_rot_create(void);
void tarp_rivet_robot_rot_delete(tarp_rivet_robot_rot_t *self);
void tarp_rivet_robot_rot_update(tarp_rivet_robot_rot_t *self, double tick);
void tarp_rivet_robot_rot_print(tarp_rivet_robot_rot_t *self, FILE *fptr);

#endif /* __TARP_RIVET_ROBOT_ROT_H__ */
