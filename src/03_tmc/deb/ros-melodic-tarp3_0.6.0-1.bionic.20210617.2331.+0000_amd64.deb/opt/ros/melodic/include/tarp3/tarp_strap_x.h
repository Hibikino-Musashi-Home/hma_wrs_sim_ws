/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_strap.h
 *  @defgroup strap strap モジュール
 *
 *  strapは、ロボットとタスクを結びつけるデータ構造です。
 *
 */

#ifndef __TARP_STRAP_X_H__
#define __TARP_STRAP_X_H__

#include "tarp3/tarp_robot.h"
#include "tarp3/tarp_vect.h"
#include "tarp3/tarp_bqp2.h"

/**
 *  @ingroup strap
 *  @brief  ロボットとタスクと関節を関連づけるためのクラス。
 *
 *  運動量、角運動量、rivetクラスによるタスクを指定して、robotを動作させるためのクラスです。
 *  全身協調制御のための指令値情報をすべて含むものです。
 *  指令値を設定してtarp_strap_apply_timeを呼び出すと、robotの状態が更新されます。
 *
 */
typedef struct {
    /** 型 */
    int type;

    /** 名前 */
    char name[256];

    /** 要素数 */
    int size;

    FILE* fptr_min;
    FILE* fptr_max;

} tarp_strap_t;

#endif /* __TARP_STRAP_H__ */
