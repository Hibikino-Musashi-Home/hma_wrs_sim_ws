/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_strap.h
 *  @defgroup strap strap モジュール
 *
 */

#ifndef __TARP_STRAP_H__
#define __TARP_STRAP_H__

#include "tarp3/tarp_strap_x.h"
#include "tarp3/tarp_strap_robot_pos.h"
#include "tarp3/tarp_strap_robot_rot.h"
#include "tarp3/tarp_strap_joint.h"

enum {
    TARP_STRAP_TYPE_ROBOT_POS,
    TARP_STRAP_TYPE_ROBOT_ROT,
    TARP_STRAP_TYPE_JOINT,
};

/* tarp_strap.c */
void tarp_strap_init(tarp_strap_t *self, int type, int size);
int tarp_strap_get_size(tarp_strap_t *self);
double tarp_strap_get_act_vel(tarp_strap_t *self, int numb);
double tarp_strap_get_act_acc(tarp_strap_t *self, int numb);
void tarp_strap_set_ref_vel(tarp_strap_t *self, int numb, double ref_vel);
void tarp_strap_set_ref_acc(tarp_strap_t *self, int numb, double ref_acc);
void tarp_strap_set_ref_jrk(tarp_strap_t *self, int numb, double ref_jrk);
void tarp_strap_save(tarp_strap_t *self);
void tarp_strap_load(tarp_strap_t *self);
double tarp_strap_get_min_jrk(tarp_strap_t *self);
double tarp_strap_get_max_jrk(tarp_strap_t *self);
void tarp_strap_update(tarp_strap_t *self, double step, double tick);
tarp_gizmo_t *tarp_strap_get_gizmo(tarp_strap_t *self);
void tarp_strap_print(tarp_strap_t *self, FILE *fptr);

#endif /* __TARP_STRAP_H__ */
