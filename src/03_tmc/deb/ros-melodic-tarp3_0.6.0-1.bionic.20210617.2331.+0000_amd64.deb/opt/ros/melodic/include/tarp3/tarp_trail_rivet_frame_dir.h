/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_frame_dir.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_FRAME_DIR_H__
#define __TARP_TRAIL_RIVET_FRAME_DIR_H__

#include "tarp3/tarp_trail_rivet.h"
#include "tarp3/tarp_rivet_frame_dir.h"

typedef struct {

    tarp_trail_rivet_t base;

} tarp_trail_rivet_frame_dir_t;

/* tarp_trail_rivet_frame_dir.c */
tarp_trail_rivet_frame_dir_t *tarp_trail_rivet_frame_dir_create(void);
void tarp_trail_rivet_frame_dir_delete(tarp_trail_rivet_frame_dir_t *self);
void tarp_trail_rivet_frame_dir_update(tarp_trail_rivet_frame_dir_t *self, double step);
void tarp_trail_rivet_frame_dir_print(tarp_trail_rivet_frame_dir_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_FRAME_DIR_H__ */
