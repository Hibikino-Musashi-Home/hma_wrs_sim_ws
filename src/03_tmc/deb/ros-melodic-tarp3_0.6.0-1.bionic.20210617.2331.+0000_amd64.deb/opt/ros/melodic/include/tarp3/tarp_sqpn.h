/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  tarp_sqpn.h
 *
 *  Sequential Quadrple Programming with Newton's method
 */

#ifndef __TARP_SQPN_H__
#define __TARP_SQPN_H__

#include <stdlib.h>
#include <string.h>
#include "tarp3/tarp_object.h"
#include "tarp3/tarp_matrix.h"
#include "tarp3/tarp_blp2.h"

typedef struct {
    /** 変数の数 */
    int n;
    /** 条件の数 */
    int m;
    /** A 行列 */
    tarp_matrix_t* A;
    /** b ベクトル */
    tarp_matrix_t* b;
    /** c ベクトル */
    tarp_matrix_t* c;
    /** D 行列 */
    tarp_matrix_t* D;
    /** ニュートン方向ベクトル */
    tarp_matrix_t* e;
    /** 勾配ベクトル */
    tarp_matrix_t* g;
    /** ヘッセ行列 */
    tarp_matrix_t* H;
    /** 上限制約 */
    tarp_matrix_t* u;
    /** 下限制約 */
    tarp_matrix_t* l;
    /** 変数ベクトル */
    tarp_matrix_t* x;
} tarp_sqpn_t;

/* ../../src/tarp_sqpn.c */
tarp_sqpn_t *tarp_sqpn_create(int m, int n);
void tarp_sqpn_delete(tarp_sqpn_t *self);
int tarp_sqpn_set_A(tarp_sqpn_t *self, tarp_matrix_t *A);
int tarp_sqpn_set_b(tarp_sqpn_t *self, tarp_matrix_t *b);
int tarp_sqpn_set_c(tarp_sqpn_t *self, tarp_matrix_t *c);
int tarp_sqpn_set_D(tarp_sqpn_t *self, tarp_matrix_t *D);
int tarp_sqpn_set_l(tarp_sqpn_t *self, tarp_matrix_t *l);
int tarp_sqpn_set_u(tarp_sqpn_t *self, tarp_matrix_t *u);
int tarp_sqpn_init(tarp_sqpn_t *self);
double tarp_sqpn_update(tarp_sqpn_t *self, double rho);

#endif /* __TARP_SQPN_H__ */
