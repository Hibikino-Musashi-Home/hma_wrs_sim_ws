/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_motor.h
 *
 *  Created on: 2010/07/16
 *      Author: tajima
 */

#ifndef TARP_TRACK_MOTOR_H_
#define TARP_TRACK_MOTOR_H_

#include "tarp3/tarp_track_motor_x.h"
#include "tarp3/tarp_track_motor_robot_pos.h"
#include "tarp3/tarp_track_motor_robot_rot.h"
#include "tarp3/tarp_track_motor_joint.h"
#include "tarp3/tarp_track_motor_cloud.h"

/* tarp_track_motor.c */
void tarp_track_motor_init(tarp_track_motor_t *self, int type);
void tarp_track_motor_update(tarp_track_motor_t *self, double tick, double step);
void tarp_track_motor_print(tarp_track_motor_t *self, FILE *fptr);

#endif /* TARP_TRACK_MOTOR_H_ */
