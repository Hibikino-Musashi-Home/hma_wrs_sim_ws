/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_shape.h
 *
 */

#ifndef __TARP_SHAPE_H__
#define __TARP_SHAPE_H__

#include "tarp3/tarp_shape_x.h"
#include "tarp3/tarp_gizmo.h"

#ifdef __cplusplus
extern "C" {
#endif

/* tarp_shape.c */
tarp_shape_t *tarp_shape_create(void);
void tarp_shape_delete(tarp_shape_t *self);
int tarp_shape_set_name(tarp_shape_t *self, const char *name);
void tarp_shape_mesh_load_file_stl(tarp_shape_t *self, FILE *file);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_SHAPE_H__ */
