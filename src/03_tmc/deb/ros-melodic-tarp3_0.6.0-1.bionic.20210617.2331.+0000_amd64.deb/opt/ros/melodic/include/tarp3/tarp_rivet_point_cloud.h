/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_rivet_shape_ssp.h
 *
 */

#ifndef __TARP_RIVET_SHAPE_SSP_H__
#define __TARP_RIVET_SHAPE_SSP_H__

#include "tarp3/tarp_rivet.h"
#include "tarp3/tarp_limit.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t  base;

    /** 対象shape */
    tarp_shape_t* shape;
    
    /** 対象点のリスト */
    tarp_shape_t* point[10];

    /** 対象点の数 */
    int numb;

    /** 変位の目標値下限 */
    double* ref_dis_min;

    /** 変位の目標値上限 */
    double          ref_dis_max;

    /** 目標変位 */
    double          ref_dis;

    /** 目標速度 */
    double          ref_vel;

    /** 目標加速度 */
    double          ref_acc;

    /** 目標躍度 */
    double          ref_jrk;

    /** 現在変位 */
    double          act_dis;

    /** 現在速度 */
    double          act_vel;

    /** 現在加速度 */
    double          act_acc;

    /** 現在躍度 */
    double          act_jrk;

    /** 躍度の下限 */
    double          act_jrk_min;

    /** 躍度の上限 */
    double          act_jrk_max;

    /** 上下限の計算 */
    tarp_limit_t*   limit;

} tarp_rivet_shape_ssp_t;

/* tarp_rivet_shape_ssp.c */
tarp_rivet_shape_ssp_t *tarp_rivet_shape_ssp_create(void);
void tarp_rivet_shape_ssp_delete(tarp_rivet_shape_ssp_t *self);
void tarp_rivet_shape_ssp_setup (tarp_rivet_shape_ssp_t* self);
double tarp_rivet_shape_ssp_get_act_vel(tarp_rivet_shape_ssp_t *self);
double tarp_rivet_shape_ssp_get_act_acc(tarp_rivet_shape_ssp_t *self);
double tarp_rivet_shape_ssp_get_act_jrk(tarp_rivet_shape_ssp_t *self);
void tarp_rivet_shape_ssp_update(tarp_rivet_shape_ssp_t *self, double step, double tick);
void tarp_rivet_shape_ssp_update_jacob(tarp_rivet_shape_ssp_t *self, int numb);
void tarp_rivet_shape_ssp_update_other (tarp_rivet_shape_ssp_t* self);
void tarp_rivet_shape_ssp_print(tarp_rivet_shape_ssp_t *self, FILE *fptr);

#endif /* __TARP_RIVET_SHAPE_SSP_H__ */
