/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_rivet_rot.h
 *
 *  Created on: 2010/07/30
 *      Author: tajima
 */

#ifndef TARP_TRACK_RIVET_ROT_H_
#define TARP_TRACK_RIVET_ROT_H_

#include "tarp3/tarp_track_rivet.h"

typedef struct {
    tarp_track_rivet_t super;

    tarp_matrix3_t rot_dis;
    tarp_matrix3_t rot_dis_head;
    tarp_matrix3_t rot_dis_tail;

    /* 姿勢補間の軸 */
    tarp_vector3_t axis;
    interp_poly3_t intp_rot;

} tarp_track_rivet_rot_t;

tarp_track_rivet_rot_t* tarp_track_rivet_rot_create (void);
void tarp_track_rivet_rot_delete (tarp_track_rivet_rot_t* self);
void tarp_track_rivet_rot_setup (tarp_track_rivet_rot_t* self);
int tarp_track_rivet_rot_load_fptr (tarp_track_rivet_rot_t* self, FILE* fptr);
int tarp_track_rivet_rot_update (tarp_track_rivet_rot_t* self, double step);

#endif /* TARP_TRACK_RIVET_ROT_H_ */
