/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_cloud_x.h
 *
 */

#ifndef __TARP_MOTOR_CLOUD_X_H__
#define __TARP_MOTOR_CLOUD_X_H__

#include "tarp3/tarp_motor.h"
#include "tarp3/tarp_cloud.h"

typedef struct {
    tarp_motor_t    base;

    int             type;

    tarp_cloud_t*   cloud;

    /** 点の数 */
    int numb;

    /** 点の位置 */
    tarp_vector3_t  pos_dis[TARP_CLOUD_MAX_NUMB];

} tarp_motor_cloud_t;

#endif /* __TARP_MOTOR_CLOUD_X_H__ */
