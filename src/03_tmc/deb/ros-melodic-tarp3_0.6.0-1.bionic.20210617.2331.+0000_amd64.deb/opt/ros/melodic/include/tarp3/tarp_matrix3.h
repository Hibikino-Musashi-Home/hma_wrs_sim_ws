/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_matrix3.h
 *  @defgroup matrix3 matrix3モジュール
 *
 *  3行3列の行列を扱うモジュールです。
 */
#ifndef __MATRIX3_H__
#define __MATRIX3_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include "tarp3/tarp_vector3.h"
#include "tarp3/tarp_object.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 *  @ingroup    matrix3
 *  @brief      3x3次元行列
 */
typedef tarp_vector3_t tarp_matrix3_t[3];

extern const tarp_matrix3_t tarp_matrix3_zero;
extern const tarp_matrix3_t tarp_matrix3_unit;

/* ../../src/tarp_matrix3.c */
int tarp_matrix3_is_equal(const tarp_matrix3_t a, const tarp_matrix3_t b);
int tarp_matrix3_is_near(const tarp_matrix3_t a, const tarp_matrix3_t b, const double e);
void tarp_matrix3_set_string(tarp_matrix3_t a, const char *s);
void tarp_matrix3_get_string(tarp_matrix3_t a, char *s);
void tarp_matrix3_scale(tarp_matrix3_t a, tarp_matrix3_t b, double x);
void tarp_matrix3_copy(tarp_matrix3_t a, const tarp_matrix3_t b);
void tarp_matrix3_set_unit(tarp_matrix3_t a);
void tarp_matrix3_set_zero(tarp_matrix3_t a);
void tarp_matrix3_add_matrix3(tarp_matrix3_t a, tarp_matrix3_t b, tarp_matrix3_t c);
void tarp_matrix3_sub_matrix3(tarp_matrix3_t a, tarp_matrix3_t b, tarp_matrix3_t c);
void tarp_matrix3_mul_matrix3(tarp_matrix3_t a, tarp_matrix3_t b, tarp_matrix3_t c);
void tarp_matrix3_mul_vector3(tarp_vector3_t a, tarp_matrix3_t b, tarp_vector3_t c);
void tarp_matrix3_transpose(tarp_matrix3_t a, tarp_matrix3_t b);
void tarp_matrix3_transpose_mul_matrix3(tarp_matrix3_t a, tarp_matrix3_t b, tarp_matrix3_t c);
void tarp_matrix3_transpose_mul_vector3(tarp_vector3_t a, tarp_matrix3_t b, tarp_vector3_t c);
void tarp_matrix3_mul_matrix3_transpose(tarp_matrix3_t a, tarp_matrix3_t b, tarp_matrix3_t c);
void tarp_matrix3_set_rotation(tarp_matrix3_t m, tarp_vector3_t k, double a);
void tarp_matrix3_get_rotation(tarp_matrix3_t m, tarp_vector3_t k);
void tarp_matrix3_set_rotation_x(tarp_matrix3_t m, double a);
void tarp_matrix3_set_rotation_y(tarp_matrix3_t m, double a);
void tarp_matrix3_set_rotation_z(tarp_matrix3_t m, double a);
void tarp_matrix3_set_rotation_rpy(tarp_matrix3_t m, double rpy[3]);
void tarp_matrix3_solve_rpy(tarp_matrix3_t m, double rpy[3]);
void tarp_matrix3_solve_spin(tarp_matrix3_t m, tarp_vector3_t axis);
double tarp_matrix3_determinant(tarp_matrix3_t m);
int tarp_matrix3_invert(tarp_matrix3_t m1, tarp_matrix3_t m2);
void tarp_matrix3_print(tarp_matrix3_t m, FILE *fp);

#ifdef __cplusplus
}
#endif

#endif /* __MATRIX3_H__ */

