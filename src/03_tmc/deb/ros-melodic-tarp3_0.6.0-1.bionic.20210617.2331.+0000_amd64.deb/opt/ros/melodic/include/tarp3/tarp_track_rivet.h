/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_track_rivet.h
 *
 */
#ifndef __TARP_TRACK_RIVET_H__
#define __TARP_TRACK_RIVET_H__

#include "tarp3/tarp_track_rivet_x.h"
#include "tarp3/tarp_track_rivet_robot_pos.h"
#include "tarp3/tarp_track_rivet_robot_rot.h"
#include "tarp3/tarp_track_rivet_robot_cog.h"
#include "tarp3/tarp_track_rivet_robot_moi.h"
#include "tarp3/tarp_track_rivet_robot_zmp.h"
#include "tarp3/tarp_track_rivet_frame_pos.h"
#include "tarp3/tarp_track_rivet_frame_rot.h"
#include "tarp3/tarp_track_rivet_frame_dir.h"
#include "tarp3/tarp_track_rivet_joint.h"

/* tarp_track_rivet.c */
void tarp_track_rivet_init(tarp_track_rivet_t *self, int type);
double tarp_track_rivet_get_vel(tarp_track_rivet_t *self);
void tarp_track_rivet_update(tarp_track_rivet_t *self, double step, double tick);
void tarp_track_rivet_print(tarp_track_rivet_t *self, FILE *fptr);

#endif /* __TARP_TRACK_RIVET_H__ */
