/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_rivet_robot_moi.h
 */

#ifndef __TARP_RIVET_ROBOT_MOI_H__
#define __TARP_RIVET_ROBOT_MOI_H__

#include "tarp3/tarp_rivet.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t base;

    /** 対象gizmo */
    tarp_robot_t* robot;

    /** 軸方向 */
    tarp_vector3_t axis;

    /** 目標変位 */
    double ref_dis;

    /** 目標速度 */
    double          ref_vel;

    /** 目標加速度 */
    double          ref_acc;

    /** 目標躍度 */
    double          ref_jrk;

    /** 目標変位 */
    double          act_dis;

    /** 目標速度 */
    double          act_vel;

    /** 目標加速度 */
    double          act_acc;

} tarp_rivet_robot_moi_t;

/* tarp_rivet_robot_moi.c */
tarp_rivet_robot_moi_t *tarp_rivet_robot_moi_create(void);
void tarp_rivet_robot_moi_delete(tarp_rivet_robot_moi_t *self);
void tarp_rivet_robot_moi_print(tarp_rivet_robot_moi_t *self, FILE *fptr);
void tarp_rivet_robot_moi_update(tarp_rivet_robot_moi_t *self, double step, double tick);
void tarp_rivet_robot_moi_update_jacob(tarp_rivet_robot_moi_t *self, int numb);
void tarp_rivet_robot_moi_print(tarp_rivet_robot_moi_t *self, FILE *fptr);

#endif /* __TARP_RIVET_ROBOT_MOI_H__ */
