/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_cloud.h
 *  @defgroup   cloud cloudモジュール
 *
 */

#ifndef __TARP_CLOUD_X_H__
#define __TARP_CLOUD_X_H__

#include "tarp3/tarp_gizmo_x.h"

#define TARP_CLOUD_MAX_NUMB (100)

/**
 *  @ingroup    cloud
 *  @brief      障害物回避用の点群を表現するクラス
 */
typedef struct {

    /** 親クラス: ロボット要素クラス gizmo */
    tarp_gizmo_t gizmo;

    /** 点の数 */
    int numb;

    /** 粒子の位置 */
    tarp_vector3_t pos_dis_root[TARP_CLOUD_MAX_NUMB];

    /** 粒子の位置 */
    tarp_vector3_t pos_dis_prev[TARP_CLOUD_MAX_NUMB];

    /** 半径 */
    double radius;

} tarp_cloud_t;

#endif /* __TARP_CLOUD_X_H__ */
