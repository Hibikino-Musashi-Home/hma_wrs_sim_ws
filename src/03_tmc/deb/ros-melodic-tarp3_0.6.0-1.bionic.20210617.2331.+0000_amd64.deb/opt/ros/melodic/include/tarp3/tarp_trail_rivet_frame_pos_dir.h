/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_frame_pos.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_FRAME_POS_H__
#define __TARP_TRAIL_RIVET_FRAME_POS_H__

#include "tarp3/tarp_trail_rivet.h"

typedef struct {

    tarp_trail_rivet_t base;

    /** 方向ベクトル */
    tarp_vector3_t  axis;

    double ref_dis;
    int ref_dis_indx;

    double ref_vel;
    int ref_vel_indx;

    double ref_acc;
    int ref_acc_indx;

    double act_dis;
    int act_dis_indx;

    double act_vel;
    int act_vel_indx;

    double act_acc;
    int act_acc_indx;

} tarp_trail_rivet_frame_pos_t;

/* tarp_trail_rivet_frame_pos.c */
tarp_trail_rivet_frame_pos_t *tarp_trail_rivet_frame_pos_create(void);
void tarp_trail_rivet_frame_pos_delete(tarp_trail_rivet_frame_pos_t *self);
void tarp_trail_rivet_frame_pos_update (tarp_trail_rivet_frame_pos_t* self, double step, double tick);
void tarp_trail_rivet_frame_pos_print(tarp_trail_rivet_frame_pos_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_FRAME_POS_H__ */
