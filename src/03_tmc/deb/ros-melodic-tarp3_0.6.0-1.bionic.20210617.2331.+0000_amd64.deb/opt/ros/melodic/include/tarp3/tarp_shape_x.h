/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file        tarp_shape.h
 * @defgroup    shape   shapeモジュール
 *
 */

#ifndef __TARP_SHAPE_X_H__
#define __TARP_SHAPE_X_H__

#include "tarp3/tarp_gizmo_x.h"
#include "tarp3/tarp_frame.h"

#define PRIMITIVE_NUMB_MAX  (10)

/**
 *  @ingroup shape
 *  @brief  形状オブジェクト
 *
 */
typedef struct {

    /** 親クラス */
    tarp_gizmo_t gizmo;

    /* collision = 0 or visual = 1
     * やっぱりこれは必要ないのでは。
     */
    int type;

    int visible;

    /* #ff00ffなど */
    char color[256];

    /* box*/
    int box_numb;
    double box_size[PRIMITIVE_NUMB_MAX][3];

    /* cylinder */
    int cylinder_numb;
    double cylinder_radius[PRIMITIVE_NUMB_MAX];
    double cylinder_length[PRIMITIVE_NUMB_MAX];

    /* sphere */
    int sphere_numb;
    double sphere_radius[PRIMITIVE_NUMB_MAX];

    /* capsule */
    int capsule_numb;
    double capsule_head[PRIMITIVE_NUMB_MAX][3];
    double capsule_tail[PRIMITIVE_NUMB_MAX][3];
    double capsule_radius[PRIMITIVE_NUMB_MAX];
    double capsule_length[PRIMITIVE_NUMB_MAX];

    /* capsule両端のフレーム */
    tarp_frame_t* frame_head;
    tarp_frame_t* frame_tail;

    /* Trimeshオブジェクト */
    /* char stl_file[256]; */
    double *vertex;
    int *index;
    int vertex_numb;
    int index_numb;

} tarp_shape_t;

#endif /* __TARP_SHAPE_X_H__ */
