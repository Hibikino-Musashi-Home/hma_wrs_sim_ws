/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_track_motor_cloud.h
 *
 */
#ifndef __TARP_TRACK_MOTOR_CLOUD_H__
#define __TARP_TRACK_MOTOR_CLOUD_H__

#include "tarp3/tarp_track_motor.h"
#include "tarp3/tarp_motor_cloud.h"

typedef struct {

    tarp_track_motor_t base;

    int numb;

    tarp_vector3_t pos_dis[TARP_CLOUD_MAX_NUMB];

} tarp_track_motor_cloud_t;

/* tarp_track_motor_cloud.c */
tarp_track_motor_cloud_t *tarp_track_motor_cloud_create(void);
void tarp_track_motor_cloud_delete(tarp_track_motor_cloud_t *self);
void tarp_track_motor_cloud_update(tarp_track_motor_cloud_t *self, double step, double tick);
void tarp_track_motor_cloud_print(tarp_track_motor_cloud_t *self, FILE *fptr);

#endif /* __TARP_TRACK_MOTOR_CLOUD_H__ */
