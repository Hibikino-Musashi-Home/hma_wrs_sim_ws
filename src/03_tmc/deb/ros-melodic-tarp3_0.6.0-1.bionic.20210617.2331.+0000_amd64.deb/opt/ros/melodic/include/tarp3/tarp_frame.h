/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file       tarp_frame.h
 *
 *  座標系(frame)データ構造と操作のための関数群です。
 */

#ifndef __TARP_FRAME_H__
#define __TARP_FRAME_H__

#include <stdio.h>
#include "tarp3/tarp_object.h"
// #include "tarp_htrans3.h"
// #include "tarp_world_x.h"
#include "tarp3/tarp_solid_x.h"
#include "tarp3/tarp_frame_x.h"
#include "tarp3/tarp_gizmo.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_frame.c */
tarp_frame_t *tarp_frame_create(void);
void tarp_frame_delete(tarp_frame_t *self);
const char *tarp_frame_get_name(tarp_frame_t *self);
void tarp_frame_set_name(tarp_frame_t *self, const char *name);
void tarp_frame_get_act_pos_dis(tarp_frame_t *self, tarp_vector3_t pos_dis, int wrt);
void tarp_frame_get_ref_pos_dis(tarp_frame_t *self, tarp_vector3_t pos_dis, int wrt);
void tarp_frame_set_ref_pos_dis(tarp_frame_t *self, tarp_vector3_t pos_dis, int wrt);
void tarp_frame_attach_frame(tarp_frame_t *self, tarp_frame_t *frame);
void tarp_frame_set_pos_dis(tarp_frame_t *self, const tarp_vector3_t pos_dis, const int wrt);
void tarp_frame_get_pos_dis(tarp_frame_t *self, const tarp_vector3_t pos_dis, const int wrt);
void tarp_frame_set_pos_vel(tarp_frame_t *self, const tarp_vector3_t pos_vel, const int wrt);
void tarp_frame_get_pos_vel(tarp_frame_t *self, const tarp_vector3_t pos_vel, const int wrt);
void tarp_frame_set_pos_acc(tarp_frame_t *self, const tarp_vector3_t pos_acc, const int wrt);
void tarp_frame_get_pos_acc(tarp_frame_t *self, tarp_vector3_t pos_acc, const int wrt);
void tarp_frame_get_rot_acc(tarp_frame_t *self, tarp_vector3_t rot_acc, const int wrt);
void tarp_frame_get_pos_jrk(tarp_frame_t *self, tarp_vector3_t pos_jrk, const int wrt);
void tarp_frame_print_data(tarp_frame_t *self, double time, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_FRAME_H__ */
