/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_rivet.h
 *  @defgroup rivet rivet モジュール
 *  @brief  関節とロボット上の座標系を関連付けるrivetクラスと関数
 *
 *  jointの配列とrobot上の要素(gizmo)を保持する。
 *  その間のヤコビ行列を計算して保持する。
 */
#ifndef __TARP_RIVET_H__
#define __TARP_RIVET_H__

#include "tarp3/tarp_rivet_x.h"
#include "tarp3/tarp_rivet_robot_pos.h"
#include "tarp3/tarp_rivet_robot_rot.h"
#include "tarp3/tarp_rivet_robot_cog.h"
#include "tarp3/tarp_rivet_robot_moi.h"
#include "tarp3/tarp_rivet_robot_zmp.h"
#include "tarp3/tarp_rivet_frame_pos_rot.h"
#include "tarp3/tarp_rivet_frame_pos.h"
#include "tarp3/tarp_rivet_frame_pos_dir.h"
#include "tarp3/tarp_rivet_frame_rot.h"
#include "tarp3/tarp_rivet_frame_dir.h"
#include "tarp3/tarp_rivet_frame_gap.h"
#include "tarp3/tarp_rivet_joint.h"
#include "tarp3/tarp_rivet_shape_ssv.h"
#include "tarp3/tarp_rivet_shape_cloud.h"
#include "tarp3/tarp_rivet_plane2.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_rivet.c */
void tarp_rivet_init(tarp_rivet_t *self, int type, int size);
void tarp_rivet_exit(tarp_rivet_t *self);
void tarp_rivet_get_jacob(tarp_rivet_t *self, tarp_matrix_t *jacob);
void tarp_rivet_update(tarp_rivet_t *self, double step, double tick);
void tarp_rivet_resize_jacob(tarp_rivet_t *self, int size);
void tarp_rivet_resize_jacob2(tarp_rivet_t *self, int row);
void tarp_rivet_update_jacob(tarp_rivet_t *self, int numb);
void tarp_rivet_update_other(tarp_rivet_t *self);
void tarp_rivet_update_track_list(tarp_rivet_t *self, double step, double tick);
void tarp_rivet_update_trail_list(tarp_rivet_t *self, double step, double tick);
void tarp_rivet_print(tarp_rivet_t *self, FILE *fptr);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_RIVET_H__ */
