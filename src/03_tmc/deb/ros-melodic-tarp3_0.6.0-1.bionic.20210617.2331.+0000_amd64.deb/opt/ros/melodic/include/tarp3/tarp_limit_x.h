/* Copyright (C) 2016 Toyota Motor Corporation */
#ifndef __TARP_LIMIT_X_H__
#define __TARP_LIMIT_X_H__

typedef struct  {
    /** 変位の下限の設定値 */
    double ref_dis_min;
  
    /** 変位の上限の設定値 */
    double ref_dis_max;

    /** 速度の下限の設定値 */
    double ref_vel_min;
  
    /** 速度の上限の設定値 */
    double ref_vel_max;

    /** 加速度の下限の設定値 */
    double ref_acc_min;
  
    /** 加速度の上限の設定値 */
    double ref_acc_max;
  
    /** 躍度の下限の設定値 */
    double ref_jrk_min;

    /** 躍度の上限の設定値 */
    double ref_jrk_max;

    /** 変位の下限の実効値 */
    double act_dis_min;
  
    /** 変位の上限の実効値 */
    double act_dis_max;

    /** 速度の下限の実効値 */
    double act_vel_min;
  
    /** 速度の上限の実効値 */
    double act_vel_max;

    /** 加速度の下限の実効値 */
    double act_acc_min;
  
    /** 加速度の上限の実効値 */
    double act_acc_max;

    /** 躍度の下限の実効値 */
    double act_jrk_min;
  
    /** 躍度の下限の実効値 */
    double act_jrk_max;

    /** 離散化による誤差を許容するためのマージン係数 */
    double dis_coef;
    double vel_coef;
    double acc_coef;
    double jrk_coef;

    /** 躍度の下限の解 */
    double ans_jrk_min;

    /** 躍度の上限の解 */
    double ans_jrk_max;

    /** 下限の停止モード */
    int mode_min;

    /** 上限の停止モード */
    int mode_max;

    /** 上限までの到達時間 */
    double time_max;

    /** 下限までの到達時間 */
    double time_min;

    /** ステップ時間幅(not in use) */
    double step;

} tarp_limit_t;

#endif /* __TARP_LIMIT_H__ */
