/* Copyright (C) 2016 Toyota Motor Corporation */
#ifndef __TARP_LIMIT_MIN_H__
#define __TARP_LIMIT_MIN_H__

#include "tarp3/tarp_limit_x.h"

/* tarp_limit_min.c */
void tarp_limit_min_set_debug(int on);
int tarp_limit_update_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_check_A0_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0, double xj0, double xj1, double xj2);
int tarp_limit_update_A0_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_A1_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_A2_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_B0_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_B1_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_C0_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_C1_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_D0_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_D1_min(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);

#endif /* __TARP_LIMIT_MIN_H__ */
