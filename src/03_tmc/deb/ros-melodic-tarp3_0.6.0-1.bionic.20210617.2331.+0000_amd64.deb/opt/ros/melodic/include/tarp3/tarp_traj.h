/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_traj.h
 *  @brief  時系列軌道データ
 *
 */
#ifndef __TARP_TRAJ_H__
#define __TARP_TRAJ_H__

#include <stdio.h>
#include "tarp3/tarp_object.h"

/**
 *  @brief  tarp_traj_nodeオブジェクト
 */
typedef struct tarp_traj_node tarp_traj_node_t;

struct tarp_traj_node {

    /** 時間[s] */
    double              span;

    /** データ */
    void*               data;

    /** prev参照 */
    tarp_traj_node_t*   prev;

    /** next参照 */
    tarp_traj_node_t*   next;
};

/**
 *  @brief  trajオブジェクト
 */
typedef struct {

    /** 先頭時刻 */
    double              tick;

    /** doneノード */
    tarp_traj_node_t*   done;

} tarp_traj_t;

/* tarp_traj.c */
tarp_traj_node_t *tarp_traj_head(tarp_traj_t *self);
tarp_traj_node_t *tarp_traj_tail(tarp_traj_t *self);
tarp_traj_node_t *tarp_traj_done(tarp_traj_t *self);
tarp_traj_node_t *tarp_traj_node_create(double span, void *data);
void *tarp_traj_node_delete(tarp_traj_node_t *self);
tarp_traj_t *tarp_traj_create(void);
void tarp_traj_delete(tarp_traj_t *self);
int tarp_traj_is_empty(tarp_traj_t *self);
tarp_traj_node_t *tarp_traj_clean(tarp_traj_t *self, double tick);
double tarp_traj_get_time(tarp_traj_t *self);
tarp_traj_node_t *tarp_traj_get_prev_node(tarp_traj_t *self, double tick);
tarp_traj_node_t *tarp_traj_get_next_node(tarp_traj_t *self, double tick);
void *tarp_traj_get_prev_data(tarp_traj_t *self, double tick);
double tarp_traj_get_prev_tick(tarp_traj_t *self, double tick);
void *tarp_traj_get_next_data(tarp_traj_t *self, double tick);
tarp_traj_node_t *tarp_traj_push_head_data(tarp_traj_t *self, double time, void *data);
tarp_traj_node_t *tarp_traj_push_tail_data(tarp_traj_t *self, double time, void *data);
void tarp_traj_print(tarp_traj_t *self, FILE *fptr);

#endif /* __TARP_TRAJ_H__ */
