/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_robot_rot.h
 *
 */

#ifndef __TARP_MOTOR_ROBOT_ROT_H__
#define __TARP_MOTOR_ROBOT_ROT_H__

#include "tarp3/tarp_motor.h"
#include "tarp3/tarp_robot.h"

typedef struct {

    /* 親クラス */
    tarp_motor_t        base;
    /* 対象robot */
    tarp_robot_t*       robot;
    /* 自由度ベクトル */
    tarp_vector3_t      axis;
    /* 指令軸ベクトル */
    tarp_vector3_t      ref_dis;
    /* 指令速度 */
    double              ref_vel;
    /* 指令加速度 */
    double              ref_acc;
    /* 現在軸ベクトル */
    tarp_vector3_t      act_dis;
    /* 現在速度 */
    double              act_vel;
    /* 現在加速度 */
    double              act_acc;
    /* 変位フラグ */
    int                 ref_dis_flag;
    /* 速度フラグ */
    int                 ref_vel_flag;
    /* 加速度フラグ */
    int                 ref_acc_flag;

} tarp_motor_robot_rot_t;

/* tarp_motor_robot_rot.c */
tarp_motor_robot_rot_t *tarp_motor_robot_rot_create(void);
void tarp_motor_robot_rot_delete(tarp_motor_robot_rot_t *self);
void tarp_motor_robot_rot_update(tarp_motor_robot_rot_t *self, double step, double tick);
void tarp_motor_robot_rot_print(tarp_motor_robot_rot_t *self, FILE *fptr);

#endif /* __TARP_MOTOR_ROBOT_ROT_H__ */
