/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_gizmo_joint.h
 *
 *  Created on: 2010/07/30
 *      Author: tajima
 */

#ifndef TARP_TRACK_GIZMO_JOINT_H_
#define TARP_TRACK_GIZMO_JOINT_H_

#include "tarp3/tarp_track_gizmo.h"

typedef struct {

    /* 親クラス */
    tarp_track_gizmo_t super;

    /* 指令値 */
    double dis;
    double vel;
    double acc;

    /* 境界値 */
    double dis_head;
    double dis_tail;
    double vel_tail;
    double acc_tail;

    interp_poly3_t intp_pos;

} tarp_track_gizmo_joint_t;

tarp_track_gizmo_joint_t* tarp_track_gizmo_joint_create (void);
void tarp_track_gizmo_joint_delete (tarp_track_gizmo_joint_t* self);
void tarp_track_gizmo_joint_setup (tarp_track_gizmo_joint_t* self);
int tarp_track_gizmo_joint_load_fptr (tarp_track_gizmo_joint_t* self, FILE* fptr);
int tarp_track_gizmo_joint_update (tarp_track_gizmo_joint_t* self, double step);


#endif /* TARP_TRACK_GIZMO_JOINT_H_ */
