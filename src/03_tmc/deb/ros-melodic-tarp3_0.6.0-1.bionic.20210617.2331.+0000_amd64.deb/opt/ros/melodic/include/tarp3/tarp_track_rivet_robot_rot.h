/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_rivet_robot_rot.h
 *
 */

#ifndef __TARP_TRACK_RIVET_ROBOT_ROT_H__
#define __TARP_TRACK_RIVET_ROBOT_ROT_H__

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_robot_rot.h"

typedef struct {

    tarp_track_rivet_t base;

    double ref_dis;
    double ref_dis_head;
    double ref_dis_tail;

    double ref_vel;
    double ref_vel_head;
    double ref_vel_tail;

    double ref_acc;
    double ref_acc_head;
    double ref_acc_tail;

#if 0
    /* 3次多項式補間 */
    interp_poly3_t intp3;

    /* 5次多項式補間 */
    interp_poly5_t intp5;
#endif

} tarp_track_rivet_robot_rot_t;

tarp_track_rivet_robot_rot_t* tarp_track_rivet_robot_rot_create (void);
void tarp_track_rivet_robot_rot_delete (tarp_track_rivet_robot_rot_t* self);
void tarp_track_rivet_robot_rot_setup (tarp_track_rivet_robot_rot_t* self);
int tarp_track_rivet_robot_rot_load_fptr (tarp_track_rivet_robot_rot_t* self, FILE* fptr);
int tarp_track_rivet_robot_rot_update (tarp_track_rivet_robot_rot_t* self, double step);
void tarp_track_rivet_robot_rot_print (tarp_track_rivet_robot_rot_t* self, FILE* fptr);

#endif /* __TARP_TRACK_RIVET_ROBOT_ROT_H__ */
