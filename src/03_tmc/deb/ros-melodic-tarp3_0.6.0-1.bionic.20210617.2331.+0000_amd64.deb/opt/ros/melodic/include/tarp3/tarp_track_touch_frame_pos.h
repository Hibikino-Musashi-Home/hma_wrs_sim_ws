/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_touch_frame_pos.h
 *
 */

#ifndef __TARP_TRACK_TOUCH_FRAME_POS_H__
#define __TARP_TRACK_TOUCH_FRAME_POS_H__

#include "tarp3/tarp_track_touch.h"
#include "tarp3/tarp_touch_frame_pos.h"

typedef struct {

    tarp_track_touch_t base;

    tarp_frame_t* frame;

} tarp_track_touch_frame_pos_t;

tarp_track_touch_frame_pos_t* tarp_track_touch_frame_pos_create (void);
void tarp_track_touch_frame_pos_delete (tarp_track_touch_frame_pos_t* self);
void tarp_track_touch_frame_pos_print (tarp_track_touch_frame_pos_t* self, FILE* fptr);

#endif /* __TARP_TRACK_TOUCH_FRAME_POS_H__ */
