/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  線形計画法モジュール
 */
#ifndef __BLP2_H__
#define __BLP2_H__

#include "tarp3/tarp_object.h"
#include "tarp3/tarp_matrix.h"

/**
 *  @brief  線形計画法クラス
 */
typedef struct {

    /** 基底変数の数 */
    int m;

    /** 非基底変数の数 */
    int n;

    /** c行列 */
    tarp_matrix_t* c0;

    /** A行列 */
    tarp_matrix_t* A;

    /** b行列 */
    tarp_matrix_t* b;

    /** c行列 */
    tarp_matrix_t* c;

    /** 最適値 */
    double z;

    /** 最適値 */
    double delta;

    int up;

    /** 下限 */
    tarp_matrix_t* l;

    /** 上限 */
    tarp_matrix_t* u;

    /** 1:上限な非基底変数 */
    int* upbnd;

    /** 非基底変数を示す配列 */
    int* nbas;

    /** 基底変数を示す配列 */
    int* ibas;

    /** 基底から非基底になる変数 */
    int pivrow;

    /** 非基底から基底になる変数 */
    int pivcol;

} tarp_blp2_t;

tarp_blp2_t* tarp_blp2_create (tarp_matrix_t* A, tarp_matrix_t* b, tarp_matrix_t* c, tarp_matrix_t* min, tarp_matrix_t* max);
void tarp_blp2_delete (tarp_blp2_t* self);
int tarp_blp2_solve (tarp_blp2_t* self);
int tarp_blp2_check (tarp_blp2_t* self, tarp_matrix_t* x);
int tarp_blp2_solve_min (tarp_blp2_t* self);
int tarp_blp2_solve_max (tarp_blp2_t* self);
void tarp_blp2_get_answer (tarp_blp2_t* self, tarp_matrix_t* x);
void tarp_blp2_print (tarp_blp2_t* self, FILE* fp);

/* 内部関数 */
void tarp_blp2_pivot (tarp_blp2_t* self);
int tarp_blp2_chkopt (tarp_blp2_t* self);
void tarp_blp2_rtest (tarp_blp2_t* self);
void tarp_blp2_update (tarp_blp2_t* self);

#endif /*__BLP2_H__ */
