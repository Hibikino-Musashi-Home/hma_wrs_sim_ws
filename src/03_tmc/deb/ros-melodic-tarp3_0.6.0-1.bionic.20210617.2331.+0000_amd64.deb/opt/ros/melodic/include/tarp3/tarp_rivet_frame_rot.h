/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_frame_rot.h
 *
 *  Created on: 2009/11/10
 *      Author: tajima
 */

#ifndef __TARP_RIVET_FRAME_ROT_H__
#define __TARP_RIVET_FRAME_ROT_H__

#include "tarp3/tarp_rivet.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t    base;

    /** 対象frame */
    tarp_frame_t*   frame;

    /** 基準軸 */
    tarp_vector3_t  axis;

    /** 偏差軸 */
    // tarp_vector3_t  err_axis;

    /** 姿勢行列の指令値 */
    tarp_matrix3_t  ref_dis;

    /** 指令速度 */
    tarp_vector3_t  ref_vel;

    /** 指令加速度 */
    tarp_vector3_t  ref_acc;

    /** 実際の姿勢 */
    tarp_matrix3_t  act_dis;

    /** 実際の角速度 */
    tarp_vector3_t  act_vel;

    /** 実際の角加速度 */
    tarp_vector3_t  act_acc;

} tarp_rivet_frame_rot_t;

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_rivet_frame_rot.c */
tarp_rivet_frame_rot_t *tarp_rivet_frame_rot_create(void);
void tarp_rivet_frame_rot_delete(tarp_rivet_frame_rot_t *self);
void tarp_rivet_frame_rot_set_frame(tarp_rivet_frame_rot_t *self, tarp_frame_t *frame);
void tarp_rivet_frame_rot_update(tarp_rivet_frame_rot_t *self, double step, double tick);
void tarp_rivet_frame_rot_update_jacob(tarp_rivet_frame_rot_t *self, int numb);
void tarp_rivet_frame_rot_update_other(tarp_rivet_frame_rot_t *self);
void tarp_rivet_frame_rot_print(tarp_rivet_frame_rot_t *self, FILE *fptr);
void tarp_rivet_frame_rot_set_ref(tarp_rivet_frame_rot_t *self, const tarp_matrix3_t dis, const tarp_vector3_t vel, const tarp_vector3_t acc);
void tarp_rivet_frame_rot_set_ref_rpy(tarp_rivet_frame_rot_t *self, double rpy[3]);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_RIVET_FRAME_ROT_H__ */
