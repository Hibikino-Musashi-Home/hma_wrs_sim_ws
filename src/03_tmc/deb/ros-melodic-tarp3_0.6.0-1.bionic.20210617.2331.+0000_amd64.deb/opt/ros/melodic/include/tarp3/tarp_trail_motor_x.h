/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_motor_x.h
 *
 */
#ifndef __TARP_TRAIL_MOTOR_X_H__
#define __TARP_TRAIL_MOTOR_X_H__

#include "tarp3/tarp_trail.h"
#include "tarp3/tarp_motor.h"

enum {
    TARP_TRAIL_MOTOR_TYPE_ROBOT_POS,
    TARP_TRAIL_MOTOR_TYPE_ROBOT_ROT,
    TARP_TRAIL_MOTOR_TYPE_JOINT,
};

typedef struct {

    /* 親クラス */
    tarp_trail_t base;

    /** type */
    int type;

    /* 対象motor */
    tarp_motor_t* motor;

} tarp_trail_motor_t;

#endif /* TARP_TRAIL_MOTOR_X_H_ */
