/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_rivet_x.h
 *
 */
#ifndef __TARP_RIVET_X_H__
#define __TARP_RIVET_X_H__

#include "tarp3/tarp_frame.h"
#include "tarp3/tarp_matrix.h"
#include "tarp3/tarp_strap_x.h"

enum {
    TARP_RIVET_TYPE_ROBOT_POS,
    TARP_RIVET_TYPE_ROBOT_ROT,
    TARP_RIVET_TYPE_ROBOT_COG,
    TARP_RIVET_TYPE_ROBOT_MOI,
    TARP_RIVET_TYPE_ROBOT_ZMP,
    TARP_RIVET_TYPE_FRAME_POS,
    TARP_RIVET_TYPE_FRAME_ROT,
    TARP_RIVET_TYPE_FRAME_DIR,
    TARP_RIVET_TYPE_FRAME_GAP,
    TARP_RIVET_TYPE_JOINT,
    TARP_RIVET_TYPE_SHAPE_SSV,
    TARP_RIVET_TYPE_SHAPE_CLOUD,
    TARP_RIVET_TYPE_PLANE2,
    TARP_RIVET_TYPE_FRAME_POS_ROT,
    TARP_RIVET_TYPE_FRAME_POS_DIR,
    TARP_RIVET_TYPE_NUMB,
};

/**
 *  @ingroup rivet
 *  @brief  拘束（タスク）を表現するrivetクラス
 *
 *  gizmoに対する位置や速度のタスクを設定するためのクラスです。
 *  複数のrivetを優先度をつけてstrapに設定し、最適化問題を解くことで最適速度を求めます。
 *
 */
typedef struct tarp_rivet {

    /** rivetのタイプ */
    int type;

    /** 名前 */
    char name[256];

    /** 優先度 */
    int             prio;

    /** 不等式制約フラグ */
    int             neq;

    /** ヤコビ行列 */
    tarp_matrix_t*  jacob_1;

    /** その他の項 */
    tarp_matrix_t*  other;

    /** 目標躍度ベクトル (n x 1) */
    tarp_matrix_t*  focus_ref;

    /** 速度を0にする第二目標の目標躍度ベクトル (n x 1) */
    tarp_matrix_t*  focus_ref_2;

    /** 目標の下限 (n x 1) */
    tarp_matrix_t*  focus_min;

    /** 目標の上限 (n x 1) */
    tarp_matrix_t*  focus_max;

    /** track-list */
    tarp_list_t*    track_list;

    /** trail-list */
    tarp_list_t*    trail_list;

    /** 自由度の数 */
    int size;

} tarp_rivet_t;

#endif /* __TARP_RIVET_X_H__ */
