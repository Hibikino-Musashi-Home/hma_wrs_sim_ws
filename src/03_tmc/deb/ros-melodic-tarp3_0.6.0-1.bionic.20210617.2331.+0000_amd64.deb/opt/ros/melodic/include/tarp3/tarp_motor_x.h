/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_x.h
 *  @defgroup motor motor モジュール
 *
 */

#ifndef __TARP_MOTOR_X_H__
#define __TARP_MOTOR_X_H__

#include "tarp3/tarp_list.h"

enum {
    TARP_MOTOR_TYPE_ROBOT_POS,
    TARP_MOTOR_TYPE_ROBOT_ROT,
    TARP_MOTOR_TYPE_JOINT,
    TARP_MOTOR_TYPE_CLOUD,
    TARP_MOTOR_TYPE_NUMB,
};

typedef struct {

    int type;

    char name[256];

    tarp_list_t* track_list;

    tarp_list_t* trail_list;

} tarp_motor_t;

#endif /* __TARP_MOTOR_X_H__ */
