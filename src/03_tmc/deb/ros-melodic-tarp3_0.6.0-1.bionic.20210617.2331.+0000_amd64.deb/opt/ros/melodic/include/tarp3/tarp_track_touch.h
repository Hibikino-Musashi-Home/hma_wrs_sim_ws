/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_track_touch.h
 *
 */
#ifndef __TARP_TRACK_TOUCH_H__
#define __TARP_TRACK_TOUCH_H__

#include "tarp3/tarp_track_touch_x.h"
#include "tarp3/tarp_track_touch_frame_pos.h"
#include "tarp3/tarp_track_touch_frame_rot.h"

void tarp_track_touch_init (tarp_track_touch_t* self, int type);
void tarp_track_touch_print (tarp_track_touch_t* self, FILE* fptr);

#endif /* __TARP_TRACK_TOUCH_H__ */
