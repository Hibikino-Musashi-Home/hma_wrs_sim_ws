/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_gizmo_x.h
 *  @defgroup gizmo gizmoモジュール
 *
 *  木構造を構成する座標系を表現するクラスです。座標変換により動かされ、親子関係を持ちます。
 *  frame, solid, joint_all, robot, worldの親クラスとなります。
 */

#ifndef __TARP_GIZMO_X_H__
#define __TARP_GIZMO_X_H__

#include "tarp3/tarp_vector3.h"
#include "tarp3/tarp_matrix3.h"

#ifdef __cplusplus
extern "C" {
#endif

/** 名前の最大長さ */
#define GIZMO_NAME_SIZE (128)

    /**
     *  @ingroup gizmo
     *  @brief gizmoから派生するクラスのID
     *  gizmo_tは木構造となった座標系を表現している。
     *  これを継承する形で剛体やジョイントとなる。どの種類のオブジェクトかを判定するためのIDである。
     */
    typedef enum {
	/** gizmo: gizmo */
	GIZMO_TYPE_GIZMO,
	/** robot: ロボット */
	GIZMO_TYPE_ROBOT,
	/** frame: 座標系 */
	GIZMO_TYPE_FRAME,
	/** solid: 剛体 */
	GIZMO_TYPE_SOLID,
	/** joint: 関節 */
	GIZMO_TYPE_JOINT,
	/** shape: 形状 */
	GIZMO_TYPE_SHAPE,
	/** cloud: 点群 */
	GIZMO_TYPE_CLOUD,
	/** 型の数 */
	GIZMO_TYPE_NUMB,
    } gizmo_type_t;

    /**
     *  @ingroup gizmo
     *  @brief 座標系の指定
     */
    typedef enum {
	TARP_WRT_ROOT, TARP_WRT_SELF, TARP_WRT_PREV,
    } tarp_wrt_t;

    /**
     *  @ingroup    gizmo
     *  @brief      ロボット構成要素の基底クラス
     *
     *  位置と姿勢をもち、移動する物体を表現するクラスです。
     *  ツリー構造のノードとなっており、子ノードを引き連れて動きます。
     *  変位、速度、加速度を子ノードに伝播させて動きを記述します。
     *  自分より下位のノードをまとめたものを剛体として考えたときの重心位置と慣性モーメントを計算して保持します。
     *  これは、ヤコビ行列計算の高速化のためです。
     *
     *  @image html tarp_gizmo.gif "gizmoクラス(左)と、構成されるツリー構造(右)"
     */
    typedef struct tarp_gizmo tarp_gizmo_t;

    /**
     *  @ingroup gizmo @brief ロボット構成要素の基底クラスの構造体宣言
     */
    struct tarp_gizmo {

	/** サブクラスの型 */
	int type;

	/** オブジェクトの名前 */
	char name[GIZMO_NAME_SIZE];

	/** 木構造のprevポインタ */
	tarp_gizmo_t *prev;

	/** 木構造のnextポインタ */
	tarp_gizmo_t *next;

	/** 木構造のsideポインタ */
	tarp_gizmo_t *side;

	/** 自gizmoの指令値(prev基準) */
	tarp_vector3_t pos_dis_prev;
	tarp_matrix3_t rot_dis_prev;

	tarp_vector3_t pos_vel_prev;
	tarp_vector3_t rot_vel_prev;

	tarp_vector3_t pos_acc_prev;
	tarp_vector3_t rot_acc_prev;

	tarp_vector3_t pos_jrk_prev;
	tarp_vector3_t rot_jrk_prev;

	/** 自gizmoの変位（root座標系）*/
	tarp_vector3_t pos_dis_root;
	tarp_matrix3_t rot_dis_root;

	/** 自gizmoの速度（root座標系）*/
	tarp_vector3_t pos_vel_root;
	tarp_vector3_t rot_vel_root;

	/** 自gizmoの加速度（root座標系）*/
	tarp_vector3_t pos_acc_root;
	tarp_vector3_t rot_acc_root;

	/** 自gizmoの躍度（root座標系）*/
	tarp_vector3_t pos_jrk_root;
	tarp_vector3_t rot_jrk_root;

	/** 自gizmo以下の重心位置（root座標系） */
	tarp_vector3_t cog_dis_root;

#if 0
	/** 自gizmo以下の重心速度（root座標系） */
	tarp_vector3_t cog_vel_root;

	/** 自gizmo以下の重心加速度（root座標系） */
	tarp_vector3_t cog_acc_root;

	/** 自gizmo以下の重心躍度（root座標系） */
	tarp_vector3_t cog_jrk_root;
#endif

	/** 質量（自分以下の合計）*/
	double weight;

	/** 自gizmo重心まわりの慣性行列（root座標系） */
	tarp_matrix3_t inertia;

	/** 自gizmoの運動量（root座標系） */
	tarp_vector3_t pos_mom_root;

	/** 自gizmoの角運動量（root座標系） */
	tarp_vector3_t rot_mom_root;

	/** gizmoへの力の設定値 (self座標系) */
	tarp_vector3_t ref_pos_frc_self;

	/** gizmoへのトルクの設定値 (self座標系) */
	tarp_vector3_t ref_rot_frc_self;

	/** 自gizmoの力（root座標系） */
	tarp_vector3_t pos_frc_root;

	/** 自gizmoのトルク（root座標系） */
	tarp_vector3_t rot_frc_root;
    };

#ifdef __cplusplus
}
#endif

#endif /* __TARP_GIZMO_X_H__ */
