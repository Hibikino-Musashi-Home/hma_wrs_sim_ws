/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_list.h
 * @defgroup tarp_list
 *
 * 双方向リストクラス
 */
#ifndef __TARP_LIST_H__
#define __TARP_LIST_H__

#include "tarp3/tarp_object.h"

/**
 *  @brief      リストクラスの型定義
 *  @ingroup    tarp_list
 */
typedef struct tarp_list tarp_list_t;

/**
 *  @brief  リストのノードクラスの型定義。
 *  @ingroup    tarp_list
 *
 *  リスト内での位置を指定するときに用いる。
 *
 */
typedef struct tarp_list_node tarp_list_node_t;

/**
 *  @brief  リストクラスの構造体定義
 *  @ingroup    tarp_list
 *
 */
struct tarp_list {

    /** doneノード */
    tarp_list_node_t*   done;

    /** 要素の数 */
    int                 numb;
};

/**
 *  @brief  リストのノードクラスの実体。
 *  @ingroup    tarp_list
 *
 */
struct tarp_list_node {

    /** データへのポインタ */
    void*               data;

    /** 前ノードへのポインタ */
    tarp_list_node_t*   prev;

    /** 次ノードへのポインタ */
    tarp_list_node_t*   next;
};

/**
 * @brief  リストの先頭ノードへのポインタを返す
 */
#define tarp_list_head(self) self->done->next
#define tarp_list_get_head(self) self->done->next

/**
 *  @brief  リストの末尾ノードへのポインタを返す
 */
#define tarp_list_tail(self) self->done->prev

/**
 *  @brief  リストの終了ノードを返す
 */
#define tarp_list_done(self) self->done

/**
 *  @brief  ノードのデータを取得する
 */
#define tarp_list_node_get_data(self) self->data

/**
 *  @brief  ノードのデータを設定する
 */
#define tarp_list_node_set_data(self, data) (self->data = data)

/* ../../src/tarp_list.c */
tarp_list_node_t *tarp_list_node_create(void *data);
void *tarp_list_node_delete(tarp_list_node_t *self);
tarp_list_t *tarp_list_create(void);
void tarp_list_delete(tarp_list_t *self);
tarp_list_node_t *tarp_list_push_head_data(tarp_list_t *self, void *data);
tarp_list_node_t *tarp_list_push_tail_data(tarp_list_t *self, void *data);
void *tarp_list_get_head_data(tarp_list_t *self);
void *tarp_list_get_tail_data(tarp_list_t *self);
void *tarp_list_set_head_data(tarp_list_t *self, void *data);
void *tarp_list_set_data_tail(tarp_list_t *self, void *data);
tarp_list_node_t *tarp_list_search_node(tarp_list_t *self, void *data);
void tarp_list_apply(tarp_list_t *self, void (*func)(void *));
void tarp_list_reverse(tarp_list_t *self);
int tarp_list_is_empty(tarp_list_t *self);
void *tarp_list_pull_head_data(tarp_list_t *self);
void *tarp_list_pull_tail_data(tarp_list_t *self);
int tarp_list_get_numb(tarp_list_t *self);
tarp_list_node_t *tarp_list_get_node_by_index(tarp_list_t *self, int no);
void tarp_list_rotate_next(tarp_list_t *self);
void tarp_list_rotate_prev(tarp_list_t *self);

#endif /* __TARP_LIST_H__ */
