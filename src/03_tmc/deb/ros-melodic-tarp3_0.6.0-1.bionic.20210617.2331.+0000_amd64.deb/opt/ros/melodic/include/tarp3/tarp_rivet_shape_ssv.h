/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_rivet_shape_ssv.h
 *
 */

#ifndef __TARP_RIVET_SHAPE_SSV_H__
#define __TARP_RIVET_SHAPE_SSV_H__

#include "tarp3/tarp_rivet.h"
#include "tarp3/tarp_limit.h"
#include "tarp3/tarp_linseg.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t  base;

    /** 対象shape 1 */
    tarp_shape_t* shape_1;

    /** 対象frame 1 */
    tarp_frame_t* frame_1;

    /** 対象shape 2 */
    tarp_shape_t* shape_2;

    /** 対象点 */
	tarp_frame_t* frame_2;

    /** 変位の目標値下限 */
    double          ref_dis_min;

    /** 変位の目標値上限 */
    double          ref_dis_max;

    /** 目標変位 */
    double          ref_dis;

    /** 目標速度 */
    double          ref_vel;

    /** 目標加速度 */
    double          ref_acc;

    /** 目標躍度 */
    double          ref_jrk;

    /** 現在変位 */
    double          act_dis;

    /** 現在速度 */
    double          act_vel;

    /** 現在加速度 */
    double          act_acc;

    /** 現在躍度 */
    double          act_jrk;

	/** 躍度の下限 */
    double          act_jrk_min;

	/** 躍度の上限 */
    double          act_jrk_max;

    /** 上下限の計算 */
    tarp_limit_t*   limit;

} tarp_rivet_shape_ssv_t;

/* tarp_rivet_shape_ssv.c */
tarp_rivet_shape_ssv_t *tarp_rivet_shape_ssv_create(void);
void tarp_rivet_shape_ssv_delete(tarp_rivet_shape_ssv_t *self);
void tarp_rivet_shape_ssv_setup (tarp_rivet_shape_ssv_t* self);
double tarp_rivet_shape_ssv_get_act_vel(tarp_rivet_shape_ssv_t *self);
double tarp_rivet_shape_ssv_get_act_acc(tarp_rivet_shape_ssv_t *self);
double tarp_rivet_shape_ssv_get_act_jrk(tarp_rivet_shape_ssv_t *self);
void tarp_rivet_shape_ssv_update(tarp_rivet_shape_ssv_t *self, double step, double tick);
void tarp_rivet_shape_ssv_update_jacob(tarp_rivet_shape_ssv_t *self, int numb);
void tarp_rivet_shape_ssv_update_other (tarp_rivet_shape_ssv_t* self);
void tarp_rivet_shape_ssv_print(tarp_rivet_shape_ssv_t *self, FILE *fptr);

#endif /* __TARP_RIVET_SHAPE_SSV_H__ */
