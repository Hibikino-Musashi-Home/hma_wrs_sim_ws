/* Copyright (C) 2016 Toyota Motor Corporation */
#ifndef __TARP_LIMIT_MAX_H__
#define __TARP_LIMIT_MAX_H__

#include "tarp3/tarp_limit_x.h"

#ifdef __cplusplus
extern "C" {
#endif

/* tarp_limit_max.c */
int tarp_limit_update_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_A0_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_A1_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_A2_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_Bz_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_B0_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_B1_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_C0_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_C1_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_D0_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);
int tarp_limit_update_D1_max(tarp_limit_t *self, double dt, double xd0, double xv0, double xa0);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_LIMIT_MAX_H__ */
