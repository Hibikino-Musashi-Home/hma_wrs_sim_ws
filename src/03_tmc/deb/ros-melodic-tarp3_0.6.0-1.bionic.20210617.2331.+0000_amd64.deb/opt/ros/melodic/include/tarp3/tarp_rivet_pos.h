/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_pos.h
 *
 *  Created on: 2009/11/10
 *      Author: tajima
 */

#ifndef TARP_RIVET_POS_H_
#define TARP_RIVET_POS_H_

#include "tarp3/tarp_rivet.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t rivet;

    /** 対象gizmo */
    tarp_gizmo_t* target;

    /** 指令位置 */
    tarp_vector3_t pos_dis;

} tarp_rivet_pos_t;

tarp_rivet_pos_t* tarp_rivet_pos_create (void);
void tarp_rivet_pos_delete (tarp_rivet_pos_t* self);
void tarp_rivet_pos_set_target_numb (tarp_rivet_pos_t* self, int numb);
void tarp_rivet_pos_set_target (tarp_rivet_pos_t* self, tarp_gizmo_t* target);
void tarp_rivet_pos_xyz_update_jacobian (tarp_rivet_pos_t* self, int value_numb);
void tarp_rivet_pos_xyz_set_ref_vel (tarp_rivet_pos_t* self, tarp_vector3_t pos_vel, int wrt);
void tarp_rivet_pos_xyz_set_ref_vel_min_max (tarp_rivet_pos_t* self, tarp_vector3_t pos_vel_min, tarp_vector3_t pos_vel_max);
int tarp_rivet_pos_xyz_set_ref_dis (tarp_rivet_pos_t* self, double step, tarp_vector3_t pos_dis);
int tarp_rivet_pos_xyz_set_ref_dis_min_max (tarp_rivet_pos_t* self, double step, tarp_vector3_t pos_dis_min, tarp_vector3_t pos_dis_max);
void tarp_rivet_pos_print (tarp_rivet_pos_t* self, FILE* fp);

#endif /* TARP_RIVET_POS_H_ */
