/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_strap_robot.h
 *  @defgroup strap_robot strap_robot モジュール
 *
 */

#ifndef __TARP_STRAP_ROBOT_H__
#define __TARP_STRAP_ROBOT_H__

#include "tarp3/tarp_strap.h"

typedef struct {
    tarp_strap_t base;

    tarp_robot_t* robot;

}tarp_strap_robot_t;

/* tarp_strap_robot.c */
tarp_strap_robot_t *tarp_strap_robot_create(void);
void tarp_strap_robot_delete(tarp_strap_robot_t *self);
double tarp_strap_robot_get_vel(tarp_strap_robot_t *self);
void tarp_strap_robot_set_vel(tarp_strap_robot_t *self, double vel);
double tarp_strap_robot_get_acc(tarp_strap_robot_t *self);
void tarp_strap_robot_set_acc(tarp_strap_robot_t *self, double vel);
double tarp_strap_robot_get_jrk(tarp_strap_robot_t *self);
void tarp_strap_robot_set_jrk(tarp_strap_robot_t *self, double vel);
void tarp_strap_robot_save(tarp_strap_robot_t *self);
void tarp_strap_robot_load(tarp_strap_robot_t *self);
void tarp_strap_robot_update(tarp_strap_robot_t *self, double step);
void tarp_strap_robot_apply_jrk(tarp_strap_robot_t *self, double step);
void tarp_strap_robot_print(tarp_strap_robot_t *self, FILE *fptr);

#endif /* __TARP_STRAP_ROBOT_H__ */
