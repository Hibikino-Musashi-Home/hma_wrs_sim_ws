/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_gizmo.h
 *
 *  frame, joint_all, solid, robotの親クラスです。
 */
#ifndef __TARP_GIZMO_H__
#define __TARP_GIZMO_H__

#include <stdio.h>
#include "tarp3/tarp_vector3.h"
#include "tarp3/tarp_matrix3.h"
#include "tarp3/tarp_gizmo_x.h"
#include "tarp3/tarp_solid_x.h"
#include "tarp3/tarp_robot_x.h"
#include "tarp3/tarp_frame_x.h"
#include "tarp3/tarp_shape_x.h"
#include "tarp3/tarp_cloud_x.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ../../src/tarp_gizmo.c */
tarp_gizmo_t *tarp_gizmo_create(void);
void _____gizmo_init(tarp_gizmo_t *self, int type, const char *name);
const char *tarp_gizmo_get_type_name(tarp_gizmo_t *self);
const char *tarp_gizmo_get_name(tarp_gizmo_t *self);
void tarp_gizmo_set_name(tarp_gizmo_t *self, const char *name);
double tarp_gizmo_get_weight(tarp_gizmo_t *self);
void tarp_gizmo_get_act_pos_dis(tarp_gizmo_t *self, tarp_vector3_t pos_dis, int wrt);
void tarp_gizmo_get_ref_pos_dis(tarp_gizmo_t *self, tarp_vector3_t pos_dis, int wrt);
void tarp_gizmo_set_ref_pos_dis(tarp_gizmo_t *self, const tarp_vector3_t pos_dis, int wrt);
void tarp_gizmo_get_act_rot_dis(tarp_gizmo_t *self, tarp_matrix3_t rot_dis, int wrt);
void tarp_gizmo_set_ref_rot_dis(tarp_gizmo_t *self, const tarp_matrix3_t rot_dis, int wrt);
void tarp_gizmo_get_act_rot_rpy(tarp_gizmo_t *self, tarp_vector3_t rot_rpy, int wrt);
void tarp_gizmo_set_ref_rot_rpy(tarp_gizmo_t *self, const tarp_vector3_t rot_rpy, int wrt);
void tarp_gizmo_get_act_pos_vel(tarp_gizmo_t *self, tarp_vector3_t pos_vel, int wrt);
void tarp_gizmo_get_ref_pos_vel(tarp_gizmo_t *self, tarp_vector3_t pos_vel, int wrt);
void tarp_gizmo_set_ref_pos_vel(tarp_gizmo_t *self, const tarp_vector3_t pos_vel, int wrt);
void tarp_gizmo_get_act_rot_vel(tarp_gizmo_t *self, tarp_vector3_t rot_vel, int wrt);
void tarp_gizmo_get_ref_rot_vel(tarp_gizmo_t *self, tarp_vector3_t rot_vel, int wrt);
void tarp_gizmo_set_ref_rot_vel(tarp_gizmo_t *self, const tarp_vector3_t rot_vel, int wrt);
void tarp_gizmo_get_act_pos_acc(tarp_gizmo_t *self, tarp_vector3_t pos_acc, int wrt);
void tarp_gizmo_get_ref_pos_acc(tarp_gizmo_t *self, tarp_vector3_t pos_acc, int wrt);
void tarp_gizmo_set_ref_pos_acc(tarp_gizmo_t *self, const tarp_vector3_t pos_acc, int wrt);
void tarp_gizmo_get_act_rot_acc(tarp_gizmo_t *self, tarp_vector3_t rot_acc, int wrt);
void tarp_gizmo_get_ref_rot_acc(tarp_gizmo_t *self, tarp_vector3_t rot_acc, int wrt);
void tarp_gizmo_set_ref_rot_acc(tarp_gizmo_t *self, const tarp_vector3_t rot_acc, int wrt);
void tarp_gizmo_get_act_pos_jrk(tarp_gizmo_t *self, tarp_vector3_t pos_jrk, int wrt);
void tarp_gizmo_get_ref_pos_jrk(tarp_gizmo_t *self, tarp_vector3_t pos_jrk, int wrt);
void tarp_gizmo_set_ref_pos_jrk(tarp_gizmo_t *self, const tarp_vector3_t pos_jrk, int wrt);
void tarp_gizmo_get_act_rot_jrk(tarp_gizmo_t *self, tarp_vector3_t rot_jrk, int wrt);
void tarp_gizmo_get_ref_rot_jrk(tarp_gizmo_t *self, tarp_vector3_t rot_jrk, int wrt);
void tarp_gizmo_set_ref_rot_jrk(tarp_gizmo_t *self, const tarp_vector3_t rot_jrk, int wrt);
void tarp_gizmo_get_act_pos_mom(tarp_gizmo_t *self, tarp_vector3_t pos_mom, int wrt);
void tarp_gizmo_get_act_rot_mom(tarp_gizmo_t *self, tarp_vector3_t rot_mom, int wrt);
void tarp_gizmo_get_act_pos_frc(tarp_gizmo_t *self, tarp_vector3_t pos_frc, int wrt);
void tarp_gizmo_set_ref_pos_frc(tarp_gizmo_t *self, const tarp_vector3_t pos_frc, int wrt);
void tarp_gizmo_get_act_rot_frc(tarp_gizmo_t *self, tarp_vector3_t rot_frc, int wrt);
void tarp_gizmo_set_ref_rot_frc(tarp_gizmo_t *self, const tarp_vector3_t rot_frc, int wrt);
void tarp_gizmo_get_act_cog_dis(tarp_gizmo_t *self, tarp_vector3_t cog_dis, int wrt);
void tarp_gizmo_get_act_cog_vel(tarp_gizmo_t *self, tarp_vector3_t cog_vel, int wrt);
void tarp_gizmo_get_act_cog_acc(tarp_gizmo_t *self, tarp_vector3_t cog_acc, int wrt);
void tarp_gizmo_get_zmp_dis(tarp_gizmo_t *self, tarp_vector3_t zmp_dis, double z);
void tarp_gizmo_attach(tarp_gizmo_t *self, tarp_gizmo_t *gizmo);
void _____gizmo_travel_dis(tarp_gizmo_t *self, double step);
void tarp_gizmo_travel_dis(tarp_gizmo_t *self, double step);
void _____gizmo_travel_vel(tarp_gizmo_t *self, double step);
void tarp_gizmo_travel_vel(tarp_gizmo_t *self, double step);
void _____gizmo_travel_acc(tarp_gizmo_t *self, double step);
void tarp_gizmo_travel_acc(tarp_gizmo_t *self, double step);
void tarp_gizmo_update_dis(tarp_gizmo_t *self, double step);
void tarp_gizmo_update_vel(tarp_gizmo_t *self, double step);
void tarp_gizmo_update_acc(tarp_gizmo_t *self, double step);
void tarp_gizmo_update_jrk(tarp_gizmo_t *self, double step);
void tarp_gizmo_update_frc(tarp_gizmo_t *self, double step);
void tarp_gizmo_spread_dis(tarp_gizmo_t *self);
void _____gizmo_spread_dis(tarp_gizmo_t *self);
void tarp_gizmo_spread_vel(tarp_gizmo_t *self);
void _____gizmo_spread_vel(tarp_gizmo_t *self);
void tarp_gizmo_spread_acc(tarp_gizmo_t *self);
void _____gizmo_spread_acc(tarp_gizmo_t *self);
void tarp_gizmo_spread_jrk(tarp_gizmo_t *self);
void _____gizmo_spread_jrk(tarp_gizmo_t *self);
void tarp_gizmo_clear_vel(tarp_gizmo_t *self);
void tarp_gizmo_clear_acc(tarp_gizmo_t *self);
void tarp_gizmo_clear_jrk(tarp_gizmo_t *self);
void tarp_gizmo_clear_mom(tarp_gizmo_t *self);
void tarp_gizmo_clear_frc(tarp_gizmo_t *self);
void tarp_gizmo_gather_weight(tarp_gizmo_t *self);
void _____gizmo_gather_weight(tarp_gizmo_t *self);
void tarp_gizmo_gather_cog(tarp_gizmo_t *self);
void _____gizmo_gather_cog(tarp_gizmo_t *self);
void _____gizmo_gather_moment(tarp_gizmo_t *self);
void tarp_gizmo_gather_moment(tarp_gizmo_t *self);
void tarp_gizmo_gather_inertia(tarp_gizmo_t *self);
void _____gizmo_gather_inertia(tarp_gizmo_t *self);
void tarp_gizmo_gather_frc(tarp_gizmo_t *self);
void _____gizmo_gather_frc(tarp_gizmo_t *self);
int tarp_gizmo_gather_type_numb(tarp_gizmo_t *self, int type);
int tarp_gizmo_get_array_by_type(tarp_gizmo_t *self, int type, tarp_gizmo_t **array, int n, int c);
void tarp_gizmo_debug(tarp_gizmo_t *self, FILE *file);
void _____gizmo_debug(tarp_gizmo_t *self, FILE *file);
void tarp_gizmo_print_level(tarp_gizmo_t *self, FILE *file, int level);
int tarp_gizmo_get_string(tarp_gizmo_t *self, char *buff, int size);
void tarp_gizmo_print(tarp_gizmo_t *self, FILE *file);

#ifdef __cplusplus
}
#endif

#endif /* __TARP_GIZMO_H__ */
