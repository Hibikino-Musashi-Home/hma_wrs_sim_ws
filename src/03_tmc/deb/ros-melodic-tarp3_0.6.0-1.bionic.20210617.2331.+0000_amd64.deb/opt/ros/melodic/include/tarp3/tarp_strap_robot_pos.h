/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_strap_robot_pos.h
 *  @defgroup strap_robot_pos strap_robot_pos モジュール
 *
 */

#ifndef __TARP_STRAP_ROBOT_POS_H__
#define __TARP_STRAP_ROBOT_POS_H__

#include "tarp3/tarp_strap.h"

typedef struct {
    tarp_strap_t base;

    tarp_robot_t* robot;

    tarp_vector3_t axis;

    tarp_vector3_t pos_vel;
    tarp_vector3_t pos_acc;
    tarp_vector3_t pos_jrk;

}tarp_strap_robot_pos_t;

/* tarp_strap_robot_pos.c */
tarp_strap_robot_pos_t *tarp_strap_robot_pos_create(void);
void tarp_strap_robot_pos_delete(tarp_strap_robot_pos_t *self);
void tarp_strap_robot_pos_save(tarp_strap_robot_pos_t *self);
void tarp_strap_robot_pos_load(tarp_strap_robot_pos_t *self);
double tarp_strap_robot_pos_get_act_vel(tarp_strap_robot_pos_t *self, int numb);
void tarp_strap_robot_pos_set_ref_vel(tarp_strap_robot_pos_t *self, int numb, double vel);
double tarp_strap_robot_pos_get_act_acc(tarp_strap_robot_pos_t *self, int numb);
void tarp_strap_robot_pos_set_ref_acc(tarp_strap_robot_pos_t *self, int numb, double acc);
double tarp_strap_robot_pos_get_act_jrk(tarp_strap_robot_pos_t *self, int numb);
void tarp_strap_robot_pos_set_ref_jrk(tarp_strap_robot_pos_t *self, int numb, double jrk);
double tarp_strap_robot_pos_get_min_jrk(tarp_strap_robot_pos_t *self);
double tarp_strap_robot_pos_get_max_jrk(tarp_strap_robot_pos_t *self);
void tarp_strap_robot_pos_print(tarp_strap_robot_pos_t *self, FILE *fptr);

#endif /* __TARP_STRAP_ROBOT_POS_H__ */
