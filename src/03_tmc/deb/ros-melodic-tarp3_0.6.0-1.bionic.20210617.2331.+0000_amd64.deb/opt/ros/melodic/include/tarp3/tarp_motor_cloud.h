/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_motor_cloud.h
 *
 */

#ifndef __TARP_MOTOR_CLOUD_H__
#define __TARP_MOTOR_CLOUD_H__

#include "tarp3/tarp_motor_cloud_x.h"

/* tarp_motor_cloud.c */
tarp_motor_cloud_t *tarp_motor_cloud_create(void);
void tarp_motor_cloud_delete(tarp_motor_cloud_t *self);
void tarp_motor_cloud_update(tarp_motor_cloud_t *self, double step, double tick);
void tarp_motor_cloud_print(tarp_motor_cloud_t *self, FILE *fptr);

#endif /* __TARP_MOTOR_CLOUD_H__ */
