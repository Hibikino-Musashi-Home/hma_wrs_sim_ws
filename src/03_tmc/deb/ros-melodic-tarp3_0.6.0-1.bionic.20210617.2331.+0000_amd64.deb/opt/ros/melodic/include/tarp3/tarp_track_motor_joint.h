/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_track_motor_joint.h
 *
 */

#ifndef __TARP_TRACK_MOTOR_JOINT_H__
#define __TARP_TRACK_MOTOR_JOINT_H__

#include "tarp3/tarp_track_motor.h"

typedef struct {

    tarp_track_motor_t  base;

    double              ref_dis;
    int                 ref_dis_indx;

    double              ref_vel;
    int                 ref_vel_indx;

    double              ref_acc;
    int                 ref_acc_indx;

} tarp_track_motor_joint_t;

/* tarp_track_motor_joint.c */
tarp_track_motor_joint_t *tarp_track_motor_joint_create(void);
void tarp_track_motor_joint_delete(tarp_track_motor_joint_t *self);
void tarp_track_motor_joint_update(tarp_track_motor_joint_t *self, double tick);
void tarp_track_motor_joint_print(tarp_track_motor_joint_t *self, FILE *fptr);

#endif /* __TARP_TRACK_MOTOR_JOINT_H__ */
