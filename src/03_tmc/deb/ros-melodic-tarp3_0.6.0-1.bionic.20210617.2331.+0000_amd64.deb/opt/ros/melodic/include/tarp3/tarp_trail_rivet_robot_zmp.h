/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_robot_zmp.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_ROBOT_ZMP_H__
#define __TARP_TRAIL_RIVET_ROBOT_ZMP_H__

#include "tarp3/tarp_trail_rivet.h"

typedef struct {

    tarp_trail_rivet_t base;

    /** 方向ベクトル */
    tarp_vector3_t  axis;

    double ref_zmp_dis;
    int ref_zmp_dis_indx;

    double ref_cog_dis;
    int ref_cog_dis_indx;

    double ref_cog_vel;
    int ref_cog_vel_indx;

    double ref_cog_acc;
    int ref_cog_acc_indx;

    double act_zmp_dis;
    int act_zmp_dis_indx;

    double act_cog_dis;
    int act_cog_dis_indx;

    double act_cog_vel;
    int act_cog_vel_indx;

    double act_cog_acc;
    int act_cog_acc_indx;

} tarp_trail_rivet_robot_zmp_t;

/* tarp_trail_rivet_robot_zmp.c */
tarp_trail_rivet_robot_zmp_t *tarp_trail_rivet_robot_zmp_create(void);
void tarp_trail_rivet_robot_zmp_delete(tarp_trail_rivet_robot_zmp_t *self);
void tarp_trail_rivet_robot_zmp_update(tarp_trail_rivet_robot_zmp_t *self, double step, double tick);
void tarp_trail_rivet_robot_zmp_print(tarp_trail_rivet_robot_zmp_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_ROBOT_ZMP_H__ */
