/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_frame_dir.h
 *
 */

#ifndef __TARP_RIVET_FRAME_DIR_H__
#define __TARP_RIVET_FRAME_DIR_H__

#include "tarp3/tarp_rivet.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t    base;

    /** 対象frame */
    tarp_frame_t*   frame;

    /** 軸方向 */
    tarp_vector3_t  axis;

    /** 指令方向 */
    tarp_vector3_t  ref_dis;

    /** 方向 */
    tarp_vector3_t  err_axis;

    double          ref_vel;
    double          ref_acc;

} tarp_rivet_frame_dir_t;

/* tarp_rivet_frame_dir.c */
tarp_rivet_frame_dir_t *tarp_rivet_frame_dir_create(void);
void tarp_rivet_frame_dir_delete(tarp_rivet_frame_dir_t *self);
void tarp_rivet_frame_dir_update(tarp_rivet_frame_dir_t *self, double step, double tick);
void tarp_rivet_frame_dir_update_jacob(tarp_rivet_frame_dir_t *self, int numb);
void tarp_rivet_frame_dir_update_other(tarp_rivet_frame_dir_t *self);
void tarp_rivet_frame_dir_set_ref (tarp_rivet_frame_dir_t* self, tarp_vector3_t ref_dir, double ref_vel, double ref_acc);
void tarp_rivet_frame_dir_print(tarp_rivet_frame_dir_t *self, FILE *fptr);

#ifdef __cplusplus
}
#endif


#endif /* __TARP_RIVET_FRAME_DIR_H__ */
