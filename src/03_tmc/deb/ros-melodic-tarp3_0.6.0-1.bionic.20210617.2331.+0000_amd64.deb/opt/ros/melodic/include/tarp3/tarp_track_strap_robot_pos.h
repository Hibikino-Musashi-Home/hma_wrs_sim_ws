/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_track_strap_robot_pos.h
 *
 */

#ifndef __TARP_TRACK_STRAP_ROBOT_POS_H__
#define __TARP_TRACK_STRAP_ROBOT_POS_H__

#include "tarp3/tarp_track_strap.h"

typedef struct {    tarp_track_strap_t base;

    tarp_strap_robot_pos_t* strap;

    double ref_dis;
    double ref_vel;
    double ref_acc;

} tarp_track_strap_robot_pos_t;

/* tarp_track_strap_robot_pos.c */
tarp_track_strap_robot_pos_t *tarp_track_strap_robot_pos_create(void);
void tarp_track_strap_robot_pos_delete(tarp_track_strap_robot_pos_t *self);
void tarp_track_strap_robot_pos_update(tarp_track_strap_robot_pos_t *self, double step, double tick);
void tarp_track_strap_robot_pos_print(tarp_track_strap_robot_pos_t *self, FILE *fptr);

#endif /* __TARP_TRACK_STRAP_ROBOT_POS_H__ */
