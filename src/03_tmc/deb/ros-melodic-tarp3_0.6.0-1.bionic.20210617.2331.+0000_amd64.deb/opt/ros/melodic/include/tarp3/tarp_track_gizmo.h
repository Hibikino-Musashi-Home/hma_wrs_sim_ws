/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_track_gizmo.h
 *
 *  Created on: 2010/07/30
 *      Author: tajima
 */

#ifndef TARP_TRACK_GIZMO_H_
#define TARP_TRACK_GIZMO_H_

#include "tarp3/tarp_track.h"

typedef struct {

    /* 親クラス */
    tarp_track_t super;

    /* 対象joint */
    tarp_gizmo_t* gizmo;

} tarp_track_gizmo_t;

tarp_track_gizmo_t* tarp_track_gizmo_create (int type);
void tarp_track_gizmo_delete (tarp_track_gizmo_t* self);
void tarp_track_gizmo_init (tarp_track_gizmo_t* self);
void tarp_track_gizmo_set_gizmo (tarp_track_gizmo_t* self, tarp_gizmo_t* gizmo);
 void tarp_track_gizmo_setup (tarp_track_gizmo_t* self);
 int tarp_track_gizmo_load_fptr (tarp_track_gizmo_t* self, FILE* fptr);
int tarp_track_gizmo_update (tarp_track_gizmo_t* self, double step);

#endif /* TARP_TRACK_GIZMO_H_ */
