/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_rivet_zmp.h
 *
 *  Created on: 2009/11/09
 *      Author: tajima
 */

#ifndef __TARP_RIVET_ZMP_H__
#define __TARP_RIVET_ZMP_H__

#include "tarp3/tarp_rivet.h"

typedef struct {

    /** 親クラス　*/
    tarp_rivet_t rivet;

    /** 対象gizmo */
    tarp_gizmo_t* target;

    /** 指令ZMP位置 */
    tarp_vector3_t zmp_dis;

} tarp_rivet_zmp_t;

tarp_rivet_zmp_t* tarp_rivet_zmp_create (void);
void tarp_rivet_zmp_delete (tarp_rivet_zmp_t* self);
void tarp_rivet_zmp_set_target_numb (tarp_rivet_zmp_t* self, int numb);
void tarp_rivet_zmp_set_target (tarp_rivet_zmp_t* self, int no, tarp_gizmo_t* gizmo);
void tarp_rivet_zmp_update_jacobian (tarp_rivet_zmp_t* self, int value_numb);
int tarp_rivet_zmp_set_ref_dis (tarp_rivet_zmp_t* self, double step, tarp_vector3_t ref_dis);
int tarp_rivet_zmp_set_ref_dis_min_max (tarp_rivet_zmp_t* self, double step, tarp_vector3_t zmp_min, tarp_vector3_t zmp_max);

#endif /* __TARP_RIVET_ZMP_H__ */
