/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_strap_robot_rot.h
 *  @defgroup strap_robot_rot strap_robot_rot モジュール
 *
 */

#ifndef __TARP_STRAP_ROBOT_ROT_H__
#define __TARP_STRAP_ROBOT_ROT_H__

#include "tarp3/tarp_strap.h"

typedef struct {
    tarp_strap_t base;

    tarp_robot_t* robot;

    tarp_vector3_t axis;

    /* 退避用 */
    tarp_vector3_t rot_vel;
    tarp_vector3_t rot_acc;
    tarp_vector3_t rot_jrk;

}tarp_strap_robot_rot_t;

/* tarp_strap_robot_rot.c */
tarp_strap_robot_rot_t *tarp_strap_robot_rot_create(void);
void tarp_strap_robot_rot_delete(tarp_strap_robot_rot_t *self);
void tarp_strap_robot_rot_save(tarp_strap_robot_rot_t *self);
void tarp_strap_robot_rot_load(tarp_strap_robot_rot_t *self);
double tarp_strap_robot_rot_get_act_vel(tarp_strap_robot_rot_t *self, int numb);
double tarp_strap_robot_rot_get_act_acc(tarp_strap_robot_rot_t *self, int numb);
double tarp_strap_robot_rot_get_act_jrk(tarp_strap_robot_rot_t *self, int numb);
void tarp_strap_robot_rot_set_ref_vel(tarp_strap_robot_rot_t *self, int numb, double vel);
void tarp_strap_robot_rot_set_ref_acc(tarp_strap_robot_rot_t *self, int numb, double acc);
void tarp_strap_robot_rot_set_ref_jrk(tarp_strap_robot_rot_t *self, int numb, double jrk);
double tarp_strap_robot_rot_get_min_jrk(tarp_strap_robot_rot_t *self);
double tarp_strap_robot_rot_get_max_jrk(tarp_strap_robot_rot_t *self);
void tarp_strap_robot_rot_print(tarp_strap_robot_rot_t *self, FILE *fptr);

#endif /* __TARP_STRAP_ROBOT_ROT_H__ */
