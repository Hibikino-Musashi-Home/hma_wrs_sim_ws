/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_frame_rot.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_FRAME_ROT_H__
#define __TARP_TRAIL_RIVET_FRAME_ROT_H__

#include "tarp3/tarp_trail_rivet.h"
#include "tarp3/tarp_rivet_frame_rot.h"

typedef struct {

    tarp_trail_rivet_t base;

    tarp_matrix3_t      ref_dis;
    int                 ref_dis_indx[9];
    int                 ref_dis_flag;

    tarp_vector3_t      ref_vel;
    int                 ref_vel_indx[3];
    int                 ref_vel_flag;

    tarp_vector3_t      ref_acc;
    int                 ref_acc_indx[3];
    int                 ref_acc_flag;

    tarp_vector3_t      ref_rpy;
    int                 ref_rpy_indx[3];
    int                 ref_rpy_flag;

    tarp_matrix3_t      act_dis;
    int                 act_dis_indx[9];
    int                 act_dis_flag;

    tarp_vector3_t      act_vel;
    int                 act_vel_indx[3];
    int                 act_vel_flag;

    tarp_vector3_t      act_acc;
    int                 act_acc_indx[3];
    int                 act_acc_flag;

    tarp_vector3_t      act_rpy;
    int                 act_rpy_indx[3];
    int                 act_rpy_flag;

} tarp_trail_rivet_frame_rot_t;

/* tarp_trail_rivet_frame_rot.c */
tarp_trail_rivet_frame_rot_t *tarp_trail_rivet_frame_rot_create(void);
void tarp_trail_rivet_frame_rot_delete(tarp_trail_rivet_frame_rot_t *self);
void tarp_trail_rivet_frame_rot_update(tarp_trail_rivet_frame_rot_t *self, double step);
void tarp_trail_rivet_frame_rot_print(tarp_trail_rivet_frame_rot_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_FRAME_ROT_H__ */
