/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * tarp_track_rivet_frame_dir.h
 *
 */

#ifndef __TARP_TRACK_RIVET_FRAME_DIR_H__
#define __TARP_TRACK_RIVET_FRAME_DIR_H__

#include "tarp3/tarp_track_rivet.h"
#include "tarp3/tarp_rivet_frame_dir.h"

typedef struct {

    tarp_track_rivet_t  base;

    tarp_vector3_t      ref_dis;
    int                 ref_dis_indx[3];
    int                 ref_dis_flag;

    double              ref_vel;
    int                 ref_vel_indx;
    int                 ref_vel_flag;

    double              ref_acc;
    int                 ref_acc_indx;
    int                 ref_acc_flag;

} tarp_track_rivet_frame_dir_t;

/* tarp_track_rivet_frame_dir.c */
tarp_track_rivet_frame_dir_t *tarp_track_rivet_frame_dir_create(void);
void tarp_track_rivet_frame_dir_delete(tarp_track_rivet_frame_dir_t *self);
void tarp_track_rivet_frame_dir_update(tarp_track_rivet_frame_dir_t *self, double step, double tick);
void tarp_track_rivet_frame_dir_print(tarp_track_rivet_frame_dir_t *self, FILE *fptr);

#endif /* __TARP_TRACK_RIVET_FRAME_DIR_H__ */
