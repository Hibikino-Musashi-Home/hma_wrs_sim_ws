/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_track_strap_robot_rot.h
 *
 */

#ifndef __TARP_TRACK_STRAP_ROBOT_ROT_H__
#define __TARP_TRACK_STRAP_ROBOT_ROT_H__

#include "tarp3/tarp_track_strap.h"

typedef struct {

    tarp_track_strap_t base;

    tarp_strap_robot_rot_t* strap;

    double ref_dis;
    double ref_vel;
    double ref_acc;

} tarp_track_strap_robot_rot_t;

/* tarp_track_strap_robot_rot.c */
tarp_track_strap_robot_rot_t *tarp_track_strap_robot_rot_create(void);
void tarp_track_strap_robot_rot_delete(tarp_track_strap_robot_rot_t *self);
void tarp_track_strap_robot_rot_update(tarp_track_strap_robot_rot_t *self, double step, double tick);
void tarp_track_strap_robot_rot_print(tarp_track_strap_robot_rot_t *self, FILE *fptr);

#endif /* __TARP_TRACK_STRAP_ROBOT_ROT_H__ */
