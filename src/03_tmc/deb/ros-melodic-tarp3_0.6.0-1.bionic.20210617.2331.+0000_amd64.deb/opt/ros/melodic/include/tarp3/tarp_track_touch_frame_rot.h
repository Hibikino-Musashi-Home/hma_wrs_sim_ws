/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_track_touch_frame_rot.h
 *
 */

#ifndef __TARP_TRACK_TOUCH_FRAME_ROT_H__
#define __TARP_TRACK_TOUCH_FRAME_ROT_H__

#include "tarp3/tarp_track_touch.h"
#include "tarp3/tarp_touch_frame_rot.h"

typedef struct {

    tarp_track_touch_t base;

    tarp_frame_t* frame;

} tarp_track_touch_frame_rot_t;

tarp_track_touch_frame_rot_t* tarp_track_touch_frame_rot_create (void);
void tarp_track_touch_frame_rot_delete (tarp_track_touch_frame_rot_t* self);
void tarp_track_touch_frame_rot_print (tarp_track_touch_frame_rot_t* self, FILE* fptr);

#endif /* __TARP_TRACK_TOUCH_FRAME_ROT_H__ */
