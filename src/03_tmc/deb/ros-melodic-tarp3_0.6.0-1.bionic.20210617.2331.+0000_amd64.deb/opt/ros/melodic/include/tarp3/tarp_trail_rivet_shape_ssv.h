/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_shape_ssv.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_SHAPE_SSV_H__
#define __TARP_TRAIL_RIVET_SHAPE_SSV_H__

#include "tarp3/tarp_trail_rivet.h"
#include "tarp3/tarp_rivet_shape_ssv.h"

typedef struct {
	
    tarp_trail_rivet_t base;

    double ref_jrk_min;
    int ref_jrk_min_indx;

    double ref_jrk_max;
    int ref_jrk_max_indx;

    double act_dis;
    int act_dis_indx;

    double act_vel;
    int act_vel_indx;

    double act_acc;
    int act_acc_indx;

    double act_jrk;
    int act_jrk_indx;

    double act_jrk_min;
    int act_jrk_min_indx;

    double act_jrk_max;
    int act_jrk_max_indx;

} tarp_trail_rivet_shape_ssv_t;

/* tarp_trail_rivet_shape_ssv.c */
tarp_trail_rivet_shape_ssv_t *tarp_trail_rivet_shape_ssv_create(void);
void tarp_trail_rivet_shape_ssv_delete(tarp_trail_rivet_shape_ssv_t *self);
void tarp_trail_rivet_shape_ssv_update(tarp_trail_rivet_shape_ssv_t *self, double step, double tick);
void tarp_trail_rivet_shape_ssv_print(tarp_trail_rivet_shape_ssv_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_RIVET_SHAPE_SSV_H__ */
