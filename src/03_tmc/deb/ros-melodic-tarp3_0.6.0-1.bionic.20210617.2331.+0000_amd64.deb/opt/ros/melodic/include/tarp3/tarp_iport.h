/* Copyright (C) 2016 Toyota Motor Corporation */
/*
 * tarp_iport.h
 *
 *  Created on: 2010/07/16
 *      Author: tajima
 */

#ifndef TARP_IPORT_H_
#define TARP_IPORT_H_

#include <stdio.h>
#include "tarp3/tarp_matrix.h"
#include "tarp3/tarp_traj.h"

/**
 *  @brief  入力を定義するクラス
 *
 *  tickを指定してデータをもらえるAPI
 */
typedef struct {

    /** name */
    char name[256];

    /** ファイル名 */
    char file[256];

    /** ファイルポインタ */
    FILE* fptr;

    /** サイズ */
    int size;

	/** 倍率 */
	double scale;

    /** 時刻 */
    double tick;

    /** 時間 */
    double time;

    /** 軌道データ */
    tarp_traj_t* traj;

} tarp_iport_t;

/* tarp_iport.c */
tarp_iport_t *tarp_iport_create(void);
void tarp_iport_delete(tarp_iport_t *self);
double tarp_iport_get_data(tarp_iport_t *self, double tick, int numb);
double tarp_iport_get_prev_data(tarp_iport_t *self, double tick, int numb);
double tarp_iport_get_prev_tick(tarp_iport_t *self, double tick);
void tarp_iport_update(tarp_iport_t *self, double tick);
void tarp_iport_print(tarp_iport_t *self, FILE *fptr);

#endif /* TARP_IPORT_H_ */
