/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file tarp_trail_motor_robot_pos.h
 *
 */
#ifndef __TARP_TRAIL_MOTOR_ROBOT_POS_H__
#define __TARP_TRAIL_MOTOR_ROBOT_POS_H__

#include "tarp3/tarp_trail_motor.h"

typedef struct {

    tarp_trail_motor_t base;

    /** 方向ベクトル */
    tarp_vector3_t  axis;

    double ref_dis;
    int ref_dis_indx;

    double ref_vel;
    int ref_vel_indx;

    double ref_acc;
    int ref_acc_indx;

    double act_dis;
    int act_dis_indx;

    double act_vel;
    int act_vel_indx;

    double act_acc;
    int act_acc_indx;

} tarp_trail_motor_robot_pos_t;

/* tarp_trail_motor_robot_pos.c */
tarp_trail_motor_robot_pos_t *tarp_trail_motor_robot_pos_create(void);
void tarp_trail_motor_robot_pos_delete(tarp_trail_motor_robot_pos_t *self);
void tarp_trail_motor_robot_pos_update(tarp_trail_motor_robot_pos_t *self, double step);
void tarp_trail_motor_robot_pos_print(tarp_trail_motor_robot_pos_t *self, FILE *fptr);

#endif /* __TARP_TRAIL_MOTOR_ROBOT_POS_H__ */
