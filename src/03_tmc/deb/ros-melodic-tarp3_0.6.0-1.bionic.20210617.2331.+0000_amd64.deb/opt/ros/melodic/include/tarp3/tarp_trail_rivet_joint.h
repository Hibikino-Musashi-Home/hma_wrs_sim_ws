/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 *  @file   tarp_trail_rivet_joint.h
 *
 */
#ifndef __TARP_TRAIL_RIVET_JOINT_H__
#define __TARP_TRAIL_RIVET_JOINT_H__

#include "tarp3/tarp_trail_rivet.h"

/**
 *  @brief  rivetに対する軌跡
 *
 */
typedef struct {

    /* 親クラス */
    tarp_trail_rivet_t base;

	int ref_dis_indx;
	int ref_vel_indx;
	int ref_acc_indx;

    int act_dis_indx;

    int min_dis_indx;

    int max_dis_indx;

    int act_vel_indx;

    int act_acc_indx;

    int act_jrk_indx;

} tarp_trail_rivet_joint_t;

tarp_trail_rivet_joint_t* tarp_trail_rivet_joint_create (void);
void tarp_trail_rivet_joint_delete (tarp_trail_rivet_joint_t* self);
void tarp_trail_rivet_joint_update (tarp_trail_rivet_joint_t* self, double step, double tick);
void tarp_trail_rivet_joint_print (tarp_trail_rivet_joint_t* self, FILE* fptr);

#endif /* __TARP_TRAIL_RIVET_JOINT_H__ */
