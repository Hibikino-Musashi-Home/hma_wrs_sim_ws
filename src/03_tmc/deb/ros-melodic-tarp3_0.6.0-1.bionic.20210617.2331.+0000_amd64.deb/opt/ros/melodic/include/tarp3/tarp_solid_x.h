/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file   tarp_solid.h
 * @defgroup   solid solidモジュール
 *
 */
#ifndef __TARP_SOLID_X_H__
#define __TARP_SOLID_X_H__

#include "tarp3/tarp_gizmo_x.h"

/**
 *  @ingroup solid
 *  @brief  solid - 剛体オブジェクト
 *
 *  重心はgizmo座標系の原点、慣性モーメントもgizmoの座標系での値になります。
 *
 */
typedef struct {

    /** 親クラス */
    tarp_gizmo_t gizmo;

    /** 質量 [kg] */
    double weight;

    /** 重心まわりの慣性行列(self座標系) */
    tarp_matrix3_t inertia_self;

#if 0
    /** 重心位置(self座標系) */
    tarp_vector3_t cog_dis_self;

    /** 重心位置(root座標系) */
    tarp_vector3_t cog_dis_root;

    /** 重心速度(root座標系) */
    tarp_vector3_t cog_pos_vel_root;

    /** 重心加速度(root座標系) */
    tarp_vector3_t cog_pos_acc_root;

    /** 重心まわりの角速度(root座標系) */
    tarp_vector3_t cog_rot_vel_root;

    /** 重心まわりの角加速度(root座標系) */
    tarp_vector3_t cog_rot_acc_root;

    tarp_vector3_t pos_mom_root;
    tarp_vector3_t rot_mom_root;

    /** 外力(root座標系) */
    tarp_vector3_t pos_frc_root;
    tarp_vector3_t rot_frc_root;

#endif

} tarp_solid_t;

#endif /* __TARP_SOLID_X_H__ */
