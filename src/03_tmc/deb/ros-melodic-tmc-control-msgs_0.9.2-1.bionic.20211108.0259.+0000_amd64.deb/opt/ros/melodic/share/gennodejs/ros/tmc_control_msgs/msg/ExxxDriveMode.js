// Auto-generated. Do not edit!

// (in-package tmc_control_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ExxxDriveMode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.joint = null;
      this.value = null;
    }
    else {
      if (initObj.hasOwnProperty('joint')) {
        this.joint = initObj.joint
      }
      else {
        this.joint = '';
      }
      if (initObj.hasOwnProperty('value')) {
        this.value = initObj.value
      }
      else {
        this.value = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExxxDriveMode
    // Serialize message field [joint]
    bufferOffset = _serializer.string(obj.joint, buffer, bufferOffset);
    // Serialize message field [value]
    bufferOffset = _serializer.uint8(obj.value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExxxDriveMode
    let len;
    let data = new ExxxDriveMode(null);
    // Deserialize message field [joint]
    data.joint = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [value]
    data.value = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.joint.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_control_msgs/ExxxDriveMode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4c4eca1a897c9c985c13ebed2af6041a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string joint
    uint8 value
    
    uint8 kNoControl=0
    uint8 kVoltage=1
    uint8 kCurrent=2
    uint8 kVelocity=3
    uint8 kPosition=4
    uint8 kActPositionAndActVelocity=5
    uint8 kJntVelocity=6
    uint8 kJntPositionAndJntVelocity=7
    uint8 kJntPositionAndActVelocity=8
    uint8 kImpedance=9
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExxxDriveMode(null);
    if (msg.joint !== undefined) {
      resolved.joint = msg.joint;
    }
    else {
      resolved.joint = ''
    }

    if (msg.value !== undefined) {
      resolved.value = msg.value;
    }
    else {
      resolved.value = 0
    }

    return resolved;
    }
};

// Constants for message
ExxxDriveMode.Constants = {
  KNOCONTROL: 0,
  KVOLTAGE: 1,
  KCURRENT: 2,
  KVELOCITY: 3,
  KPOSITION: 4,
  KACTPOSITIONANDACTVELOCITY: 5,
  KJNTVELOCITY: 6,
  KJNTPOSITIONANDJNTVELOCITY: 7,
  KJNTPOSITIONANDACTVELOCITY: 8,
  KIMPEDANCE: 9,
}

module.exports = ExxxDriveMode;
