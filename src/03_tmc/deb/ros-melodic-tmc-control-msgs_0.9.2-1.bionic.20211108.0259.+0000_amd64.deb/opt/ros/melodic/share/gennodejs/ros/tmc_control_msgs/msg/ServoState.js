// Auto-generated. Do not edit!

// (in-package tmc_control_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ServoState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.name = null;
      this.command_position = null;
      this.command_velocity = null;
      this.command_current = null;
      this.present_position = null;
      this.present_velocity = null;
      this.present_effort = null;
      this.present_temperature = null;
      this.present_current = null;
      this.present_motor_shaft_position = null;
      this.present_driven_shaft_position = null;
      this.error_status = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = [];
      }
      if (initObj.hasOwnProperty('command_position')) {
        this.command_position = initObj.command_position
      }
      else {
        this.command_position = [];
      }
      if (initObj.hasOwnProperty('command_velocity')) {
        this.command_velocity = initObj.command_velocity
      }
      else {
        this.command_velocity = [];
      }
      if (initObj.hasOwnProperty('command_current')) {
        this.command_current = initObj.command_current
      }
      else {
        this.command_current = [];
      }
      if (initObj.hasOwnProperty('present_position')) {
        this.present_position = initObj.present_position
      }
      else {
        this.present_position = [];
      }
      if (initObj.hasOwnProperty('present_velocity')) {
        this.present_velocity = initObj.present_velocity
      }
      else {
        this.present_velocity = [];
      }
      if (initObj.hasOwnProperty('present_effort')) {
        this.present_effort = initObj.present_effort
      }
      else {
        this.present_effort = [];
      }
      if (initObj.hasOwnProperty('present_temperature')) {
        this.present_temperature = initObj.present_temperature
      }
      else {
        this.present_temperature = [];
      }
      if (initObj.hasOwnProperty('present_current')) {
        this.present_current = initObj.present_current
      }
      else {
        this.present_current = [];
      }
      if (initObj.hasOwnProperty('present_motor_shaft_position')) {
        this.present_motor_shaft_position = initObj.present_motor_shaft_position
      }
      else {
        this.present_motor_shaft_position = [];
      }
      if (initObj.hasOwnProperty('present_driven_shaft_position')) {
        this.present_driven_shaft_position = initObj.present_driven_shaft_position
      }
      else {
        this.present_driven_shaft_position = [];
      }
      if (initObj.hasOwnProperty('error_status')) {
        this.error_status = initObj.error_status
      }
      else {
        this.error_status = [];
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ServoState
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _arraySerializer.string(obj.name, buffer, bufferOffset, null);
    // Serialize message field [command_position]
    bufferOffset = _arraySerializer.float64(obj.command_position, buffer, bufferOffset, null);
    // Serialize message field [command_velocity]
    bufferOffset = _arraySerializer.float64(obj.command_velocity, buffer, bufferOffset, null);
    // Serialize message field [command_current]
    bufferOffset = _arraySerializer.float64(obj.command_current, buffer, bufferOffset, null);
    // Serialize message field [present_position]
    bufferOffset = _arraySerializer.float64(obj.present_position, buffer, bufferOffset, null);
    // Serialize message field [present_velocity]
    bufferOffset = _arraySerializer.float64(obj.present_velocity, buffer, bufferOffset, null);
    // Serialize message field [present_effort]
    bufferOffset = _arraySerializer.float64(obj.present_effort, buffer, bufferOffset, null);
    // Serialize message field [present_temperature]
    bufferOffset = _arraySerializer.float64(obj.present_temperature, buffer, bufferOffset, null);
    // Serialize message field [present_current]
    bufferOffset = _arraySerializer.float64(obj.present_current, buffer, bufferOffset, null);
    // Serialize message field [present_motor_shaft_position]
    bufferOffset = _arraySerializer.float64(obj.present_motor_shaft_position, buffer, bufferOffset, null);
    // Serialize message field [present_driven_shaft_position]
    bufferOffset = _arraySerializer.float64(obj.present_driven_shaft_position, buffer, bufferOffset, null);
    // Serialize message field [error_status]
    bufferOffset = _arraySerializer.uint16(obj.error_status, buffer, bufferOffset, null);
    // Serialize message field [message]
    bufferOffset = _arraySerializer.string(obj.message, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ServoState
    let len;
    let data = new ServoState(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [command_position]
    data.command_position = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [command_velocity]
    data.command_velocity = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [command_current]
    data.command_current = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_position]
    data.present_position = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_velocity]
    data.present_velocity = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_effort]
    data.present_effort = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_temperature]
    data.present_temperature = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_current]
    data.present_current = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_motor_shaft_position]
    data.present_motor_shaft_position = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [present_driven_shaft_position]
    data.present_driven_shaft_position = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [error_status]
    data.error_status = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [message]
    data.message = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.name.forEach((val) => {
      length += 4 + val.length;
    });
    length += 8 * object.command_position.length;
    length += 8 * object.command_velocity.length;
    length += 8 * object.command_current.length;
    length += 8 * object.present_position.length;
    length += 8 * object.present_velocity.length;
    length += 8 * object.present_effort.length;
    length += 8 * object.present_temperature.length;
    length += 8 * object.present_current.length;
    length += 8 * object.present_motor_shaft_position.length;
    length += 8 * object.present_driven_shaft_position.length;
    length += 2 * object.error_status.length;
    object.message.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 52;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_control_msgs/ServoState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ac7c9d4660856cf04c2207c4392d080a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    string[] name
    float64[] command_position
    float64[] command_velocity
    float64[] command_current
    float64[] present_position
    float64[] present_velocity
    float64[] present_effort
    float64[] present_temperature
    float64[] present_current
    float64[] present_motor_shaft_position
    float64[] present_driven_shaft_position
    
    uint16[] error_status
    string[] message
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ServoState(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = []
    }

    if (msg.command_position !== undefined) {
      resolved.command_position = msg.command_position;
    }
    else {
      resolved.command_position = []
    }

    if (msg.command_velocity !== undefined) {
      resolved.command_velocity = msg.command_velocity;
    }
    else {
      resolved.command_velocity = []
    }

    if (msg.command_current !== undefined) {
      resolved.command_current = msg.command_current;
    }
    else {
      resolved.command_current = []
    }

    if (msg.present_position !== undefined) {
      resolved.present_position = msg.present_position;
    }
    else {
      resolved.present_position = []
    }

    if (msg.present_velocity !== undefined) {
      resolved.present_velocity = msg.present_velocity;
    }
    else {
      resolved.present_velocity = []
    }

    if (msg.present_effort !== undefined) {
      resolved.present_effort = msg.present_effort;
    }
    else {
      resolved.present_effort = []
    }

    if (msg.present_temperature !== undefined) {
      resolved.present_temperature = msg.present_temperature;
    }
    else {
      resolved.present_temperature = []
    }

    if (msg.present_current !== undefined) {
      resolved.present_current = msg.present_current;
    }
    else {
      resolved.present_current = []
    }

    if (msg.present_motor_shaft_position !== undefined) {
      resolved.present_motor_shaft_position = msg.present_motor_shaft_position;
    }
    else {
      resolved.present_motor_shaft_position = []
    }

    if (msg.present_driven_shaft_position !== undefined) {
      resolved.present_driven_shaft_position = msg.present_driven_shaft_position;
    }
    else {
      resolved.present_driven_shaft_position = []
    }

    if (msg.error_status !== undefined) {
      resolved.error_status = msg.error_status;
    }
    else {
      resolved.error_status = []
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = []
    }

    return resolved;
    }
};

module.exports = ServoState;
