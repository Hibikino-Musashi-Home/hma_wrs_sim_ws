// Auto-generated. Do not edit!

// (in-package tmc_control_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ExxxDriveMode = require('./ExxxDriveMode.js');

//-----------------------------------------------------------

class JointExxxDriveMode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.drive_modes = null;
    }
    else {
      if (initObj.hasOwnProperty('drive_modes')) {
        this.drive_modes = initObj.drive_modes
      }
      else {
        this.drive_modes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type JointExxxDriveMode
    // Serialize message field [drive_modes]
    // Serialize the length for message field [drive_modes]
    bufferOffset = _serializer.uint32(obj.drive_modes.length, buffer, bufferOffset);
    obj.drive_modes.forEach((val) => {
      bufferOffset = ExxxDriveMode.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type JointExxxDriveMode
    let len;
    let data = new JointExxxDriveMode(null);
    // Deserialize message field [drive_modes]
    // Deserialize array length for message field [drive_modes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.drive_modes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.drive_modes[i] = ExxxDriveMode.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.drive_modes.forEach((val) => {
      length += ExxxDriveMode.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_control_msgs/JointExxxDriveMode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1e57351fa56cf026bb6d84abd367d0cb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    tmc_control_msgs/ExxxDriveMode[] drive_modes
    
    ================================================================================
    MSG: tmc_control_msgs/ExxxDriveMode
    string joint
    uint8 value
    
    uint8 kNoControl=0
    uint8 kVoltage=1
    uint8 kCurrent=2
    uint8 kVelocity=3
    uint8 kPosition=4
    uint8 kActPositionAndActVelocity=5
    uint8 kJntVelocity=6
    uint8 kJntPositionAndJntVelocity=7
    uint8 kJntPositionAndActVelocity=8
    uint8 kImpedance=9
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new JointExxxDriveMode(null);
    if (msg.drive_modes !== undefined) {
      resolved.drive_modes = new Array(msg.drive_modes.length);
      for (let i = 0; i < resolved.drive_modes.length; ++i) {
        resolved.drive_modes[i] = ExxxDriveMode.Resolve(msg.drive_modes[i]);
      }
    }
    else {
      resolved.drive_modes = []
    }

    return resolved;
    }
};

module.exports = JointExxxDriveMode;
