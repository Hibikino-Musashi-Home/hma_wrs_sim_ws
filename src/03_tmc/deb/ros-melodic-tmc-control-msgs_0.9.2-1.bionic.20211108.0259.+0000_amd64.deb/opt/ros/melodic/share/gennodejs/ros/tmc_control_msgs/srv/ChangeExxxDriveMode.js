// Auto-generated. Do not edit!

// (in-package tmc_control_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let JointExxxDriveMode = require('../msg/JointExxxDriveMode.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ChangeExxxDriveModeRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.drive_mode_request = null;
    }
    else {
      if (initObj.hasOwnProperty('drive_mode_request')) {
        this.drive_mode_request = initObj.drive_mode_request
      }
      else {
        this.drive_mode_request = new JointExxxDriveMode();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChangeExxxDriveModeRequest
    // Serialize message field [drive_mode_request]
    bufferOffset = JointExxxDriveMode.serialize(obj.drive_mode_request, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChangeExxxDriveModeRequest
    let len;
    let data = new ChangeExxxDriveModeRequest(null);
    // Deserialize message field [drive_mode_request]
    data.drive_mode_request = JointExxxDriveMode.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += JointExxxDriveMode.getMessageSize(object.drive_mode_request);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_control_msgs/ChangeExxxDriveModeRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '44b7df22b01a717864a4bd3fc5ebdd6f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    tmc_control_msgs/JointExxxDriveMode drive_mode_request
    
    ================================================================================
    MSG: tmc_control_msgs/JointExxxDriveMode
    tmc_control_msgs/ExxxDriveMode[] drive_modes
    
    ================================================================================
    MSG: tmc_control_msgs/ExxxDriveMode
    string joint
    uint8 value
    
    uint8 kNoControl=0
    uint8 kVoltage=1
    uint8 kCurrent=2
    uint8 kVelocity=3
    uint8 kPosition=4
    uint8 kActPositionAndActVelocity=5
    uint8 kJntVelocity=6
    uint8 kJntPositionAndJntVelocity=7
    uint8 kJntPositionAndActVelocity=8
    uint8 kImpedance=9
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChangeExxxDriveModeRequest(null);
    if (msg.drive_mode_request !== undefined) {
      resolved.drive_mode_request = JointExxxDriveMode.Resolve(msg.drive_mode_request)
    }
    else {
      resolved.drive_mode_request = new JointExxxDriveMode()
    }

    return resolved;
    }
};

class ChangeExxxDriveModeResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChangeExxxDriveModeResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChangeExxxDriveModeResponse
    let len;
    let data = new ChangeExxxDriveModeResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_control_msgs/ChangeExxxDriveModeResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '358e233cde0c8a8bcfea4ce193f8fc15';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChangeExxxDriveModeResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: ChangeExxxDriveModeRequest,
  Response: ChangeExxxDriveModeResponse,
  md5sum() { return '2579c8f6176292d23b75b51071fe93ab'; },
  datatype() { return 'tmc_control_msgs/ChangeExxxDriveMode'; }
};
