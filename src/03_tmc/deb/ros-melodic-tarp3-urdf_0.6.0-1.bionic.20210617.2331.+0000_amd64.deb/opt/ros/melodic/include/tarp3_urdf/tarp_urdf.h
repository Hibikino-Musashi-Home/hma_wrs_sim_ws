/* Copyright (C) 2016 Toyota Motor Corporation */
/**
 * @file tarp_urdf
 *
 * TARP��¤�ν�����Ѥ�URDF�ѡ���
 */
#ifndef __TARP_URDF_H__
#define __TARP_URDF_H__

#include "tarp3/tarp_gizmo.h"

tarp_robot_t *tarp_robot_load_urdf(const char *file);
tarp_robot_t *tarp_robot_load_urdf_string(const char* urdf);

#endif /* __TARP_URDF_H__ */
