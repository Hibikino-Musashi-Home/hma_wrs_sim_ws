/// @file     utils.hpp
/// @brief    tmc_manipulationでやりとりされる構造体を処理する関数群
/// @Copyright (C) 2020 Toyota Motor Corporation
#ifndef TMC_MANIPULATION_TYPES_UTILS_HPP_
#define TMC_MANIPULATION_TYPES_UTILS_HPP_

#include <tmc_manipulation_types/manipulation_types.hpp>

namespace tmc_manipulation_types {

/// @brief joint_stateから部分的なjoint_stateを引き出す
/// @param whole_joint_state ロボット全体のjoint_state
/// @param joint_names 抽出するジョイント名
/// @return 抽出された部分的なjoint_state
JointState ExtractPartialJointState(
    const JointState& whole_joint_state,
    const NameSeq& joint_names);

/// @brief joint_trajectoryから部分的なjoint_trajectoryを引き出す
/// @param whole_joint_state ロボット全体のjoint_state
/// @param joint_names 抽出するジョイント名
/// @return 抽出された部分的なjoint_trajectory
TimedJointTrajectory ExtractPartialJointTrajectory(
    const TimedJointTrajectory& whole_trajectory,
    const NameSeq& joint_names);

}  // namespace tmc_manipulation_types
#endif  // TMC_MANIPULATION_TYPES_UTILS_HPP_
