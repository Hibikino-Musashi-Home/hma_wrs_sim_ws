/// @file     manipulation_types.hpp
/// @brief    メッセージの共通型
/// @Copyright (C) 2011, 2012 Toyota Motor Corporation

#ifndef TMC_MANIPULATION_TYPES_MANIPULATION_TYPES_HPP_
#define TMC_MANIPULATION_TYPES_MANIPULATION_TYPES_HPP_

#include <stdint.h>

#include <deque>
#include <ostream>
#include <string>
#include <vector>

#include <boost/lexical_cast.hpp>
#include <boost/serialization/nvp.hpp>

#include <Eigen/Core>
#include <Eigen/Geometry>
#include <Eigen/StdVector>

namespace tmc_manipulation_types {

typedef Eigen::Affine3d Transform;
typedef Eigen::Affine3d Pose;
typedef std::vector<std::string> NameSeq;



// tmc_robot_kinematics_model
struct JointState {
  /// 関節名
  NameSeq name;
  /// 関節角
  Eigen::VectorXd position;
  Eigen::VectorXd velocity;
  Eigen::VectorXd effort;

  bool Validate() const { return !name.empty() && position.size() == name.size(); }

 private:
  friend class boost::serialization::access;
  template <class Archive> void save(Archive& archive,
                                     const unsigned int version) const {
    uint32_t size = name.size();
    archive & boost::serialization::make_nvp("Size", size);
    for (uint32_t i = 0; i < name.size(); i++) {
      std::string name_tag("Name" + boost::lexical_cast<std::string>(i));
      std::string value_tag("Value" + boost::lexical_cast<std::string>(i));
      archive & boost::serialization::make_nvp(name_tag.c_str(), name.at(i));
      archive & boost::serialization::make_nvp(value_tag.c_str(), position(i));
    }
  }
  template <class Archive> void load(Archive& archive,
                                     const unsigned int version) {
    uint32_t size;
    archive & boost::serialization::make_nvp("Size", size);
    name.resize(size);
    position.resize(size);
    for (uint32_t i = 0; i < name.size(); i++) {
      std::string name_tag("Name" + boost::lexical_cast<std::string>(i));
      std::string value_tag("Value" + boost::lexical_cast<std::string>(i));
      archive & boost::serialization::make_nvp(name_tag.c_str(), name.at(i));
      archive & boost::serialization::make_nvp(value_tag.c_str(), position(i));
    }
  }
  BOOST_SERIALIZATION_SPLIT_MEMBER();
};  // struct JointState


// tmc_collision_detector
/// プリミティブの種類
enum CollisionObjectType {
  /// 球
  kSphere = 0,
  /// 箱
  kBox,
  /// シリンダ
  kCylinder,
  /// カプセル
  kCapsule,
  /// メッシュ
  kMesh,
};  // enum CollisionObjectType

/// プリミティブの形状情報
struct Shape {
  /// プリミティブの種類
  CollisionObjectType type;
  /// プリミティブのパラメータ
  std::vector<double> dimensions;
  /// メッシュの場合のstlファイルへのパス
  std::string filename;
};  // struct Shape

typedef Eigen::Matrix<double, 6, 1> Twist;
typedef Eigen::Matrix<double, 6, 1> Wrench;
typedef Eigen::Matrix<double, 6, 1> RegionValues;


struct TaskSpaceRegion {
  Pose origin_to_tsr;
  Pose tsr_to_end;
  RegionValues min_bounds;
  RegionValues max_bounds;
  std::string origin_frame_id;
  std::string end_frame_id;

 public:
  TaskSpaceRegion(const Pose& origin_to_tsr,
                  const Pose& tsr_to_end,
                  const RegionValues& min_bounds,
                  const RegionValues& max_bounds,
                  const std::string& origin_frame_id,
                  const std::string& end_frame_id) :
      origin_to_tsr(origin_to_tsr), tsr_to_end(tsr_to_end),
      min_bounds(min_bounds), max_bounds(max_bounds),
      origin_frame_id(origin_frame_id), end_frame_id(end_frame_id) {}
  TaskSpaceRegion() :
      origin_to_tsr(Pose::Identity()), tsr_to_end(Pose::Identity()),
      origin_frame_id(), end_frame_id() {}
};  // struct TaskSpaceRegion

typedef std::vector<TaskSpaceRegion, Eigen::aligned_allocator<TaskSpaceRegion> >
  TaskSpaceRegionSeq;

struct AttachedObject {
  /// object_id 物体id
  std::string object_id;
  /// frame_name 物体が取り付けらたリンク名
  std::string frame_name;
  /// リンクから物体への同時変換
  Pose frame_to_object;
  /// attach後のgoupid
  std::string group_id;
  /// 除外物体
  std::vector<std::string> expected_objects;
};  // struct AttachedObject

typedef std::vector<AttachedObject,
                    Eigen::aligned_allocator<AttachedObject> > AttachedObjectSeq;

/// コンフィギュレーションデータ
typedef Eigen::VectorXd Config;
/// コンフィギュレーション空間中のパス
typedef std::deque<Config> Path;

/// MultiDOFのパス
typedef std::vector<Pose,
                    Eigen::aligned_allocator<Pose> > PoseSeq;
typedef std::vector<Eigen::Vector3d,
                    Eigen::aligned_allocator<Eigen::Vector3d> > Pose2dSeq;
typedef std::deque<PoseSeq> MultiDOFPath;

/// 並進速度と回転速度を並べたベクトル
typedef std::vector<Twist,
                    Eigen::aligned_allocator<Twist> > TwistSeq;
/// [force x, force y, force z, torque x, torque y, torque z]なるベクトル
typedef std::vector<Wrench,
                    Eigen::aligned_allocator<Wrench> > WrenchSeq;

/// 関節のパス
struct JointTrajectory {
  /// 関節名
  NameSeq names;
  /// 関節の値
  Path path;

  bool Validate() const {
    if (names.empty()) {
      return false;
    }

    if (path.empty()) {
      return false;
    }

    for (const Config& p : path) {
      if (p.size() != names.size()) {
        return false;
      }
    }
    return true;
  }
};

/// 複合関節のパス
struct MultiDOFJointTrajectory {
  /// 関節名
  NameSeq names;
  /// 関節の値
  MultiDOFPath path;

  bool Validate() const {
    if (names.empty()) {
      return false;
    }

    if (path.empty()) {
      return false;
    }

    for (const PoseSeq& p : path) {
      if (p.size() != names.size()) {
        return false;
      }
    }
    return true;
  }

  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/// 複合関節の状態
struct MultiDOFJointState {
  /// 関節名
  NameSeq names;
  /// 関節の値
  PoseSeq poses;
  TwistSeq twist;
  WrenchSeq wrench;

  bool Validate() const {
    return !names.empty() && poses.size() == names.size();
  }

  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/// ロボットの状態
struct RobotState {
  JointState joint_state;
  MultiDOFJointState multi_dof_joint_state;
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/// ロボットの幾何軌道
struct RobotTrajectory {
  JointTrajectory joint_trajectory;
  MultiDOFJointTrajectory multi_dof_joint_trajectory;

  bool Validate() const {
    return joint_trajectory.Validate() && multi_dof_joint_trajectory.Validate() &&
           joint_trajectory.path.size() == multi_dof_joint_trajectory.path.size();
  }

  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/// 関節の時間軌道の経由点
struct TimedJointTrajectoryPoint {
  Eigen::VectorXd positions;
  Eigen::VectorXd velocities;
  Eigen::VectorXd accelerations;
  Eigen::VectorXd effort;
  double time_from_start;
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

typedef std::deque<TimedJointTrajectoryPoint> TimedJointTrajectoryPointSeq;


/// 関節の時間軌道(ROSに対応するのはこっち)
struct TimedJointTrajectory {
  NameSeq joint_names;
  TimedJointTrajectoryPointSeq points;

  bool Validate() const {
    if (joint_names.empty()) {
      return false;
    }

    if (points.empty()) {
      return false;
    }

    for (const TimedJointTrajectoryPoint& point : points) {
      if (point.positions.size() != joint_names.size()) {
        return false;
      }
    }
    return true;
  }

  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/// 関節の時間軌道の経由点
struct TimedMultiDOFJointTrajectoryPoint {
  PoseSeq transforms;
  TwistSeq velocities;
  TwistSeq accelerations;
  double time_from_start;
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

typedef std::deque<TimedMultiDOFJointTrajectoryPoint> TimedMultiDOFJointTrajectoryPointSeq;

/// 複合関節の時間軌道(ROSに対応するのはこっち)
struct TimedMultiDOFJointTrajectory {
  NameSeq joint_names;
  TimedMultiDOFJointTrajectoryPointSeq points;

  bool Validate() const {
    if (joint_names.empty()) {
      return false;
    }

    if (points.empty()) {
      return false;
    }

    for (const TimedMultiDOFJointTrajectoryPoint& point : points) {
      if (point.transforms.size() != joint_names.size()) {
        return false;
      }
    }
    return true;
  }

  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/// ロボットの時間軌道(ROSに対応するのはこっち)
struct TimedRobotTrajectory {
  TimedJointTrajectory joint_trajectory;
  TimedMultiDOFJointTrajectory multi_dof_joint_trajectory;

  bool Validate() const {
    return joint_trajectory.Validate() && multi_dof_joint_trajectory.Validate() &&
           joint_trajectory.points.size() == multi_dof_joint_trajectory.points.size();
  }

  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

// tmc_feasibility_checker
/// 2次元干渉チェック用マップメタデータ
struct MapMetaData {
  double resolution;
  uint32_t width;
  uint32_t height;
  Pose origin;
};

/// 2次元干渉チェック用グリッドデータ
struct OccupancyGrid {
  MapMetaData info;
  std::vector<int8_t> data;
};

// tmc_robot_collision_detector
/// 干渉チェック用オブジェクトのパラメータ
struct ObjectParameter {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW;

  ObjectParameter() {
    name = "";
    shape.type = kSphere;
    margin = 0.0;
    transform.setIdentity();
    group = 0x0001;
    filter = 0xFFFF;
  }
  std::string name;  /// オブジェクト名
  Shape shape;  /// 形状
  double margin;  /// マージン
  Eigen::Affine3d transform;  /// 姿勢
  uint16_t group;  /// グループbit
  uint16_t filter;  /// フィルタbit
};  // struct ObjectParameter

typedef Eigen::Matrix<double, 3, 2> AABB;  /// [xmin xmax; ymin ymax; zmin zmax]

/// CollisionMap用のCuboid
struct Cuboid {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
  Cuboid() : margin(0.0), enable(false) {}

  Eigen::Affine3d box_transform;
  Eigen::Vector3d box_extents;
  AABB box_aabb;
  double margin;  /// 単位[m]
  std::string box_name;
  mutable bool enable;

  bool operator< (const Cuboid& other) const {
    return box_aabb(0, 1) < other.box_aabb(0, 1);
  }
};  // struct Cuboid


struct OuterObjectParameters;
typedef std::vector<ObjectParameter,
                    Eigen::aligned_allocator<ObjectParameter> >
            ObjectParameterSeq;
typedef std::vector<OuterObjectParameters,
                    Eigen::aligned_allocator<OuterObjectParameters> >
            OuterObjectParametersSeq;
typedef std::vector<Cuboid, Eigen::aligned_allocator<Cuboid> >
            CuboidSeq;

/// @brief 作成する外部物体のパラメータ
/// @attention
/// - オブジェクトを作成する際には
///   name, base, base_to_child, shapeに適切な値が入っていなければならない．
/// - baseは常に更新されるので，GetObjectParameter()で取得すれば
///   オブジェクトの位置姿勢も取得できる．
struct OuterObjectParameters {
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  OuterObjectParameters() : margin(0.0) {}
  /// オブジェクト名
  std::string name;
  /// オブジェクトの基準姿勢
  Eigen::Affine3d origin_to_base;
  /// 基準姿勢に対する子オブジェクトの姿勢
  std::vector<Eigen::Affine3d,
              Eigen::aligned_allocator<Eigen::Affine3d> > base_to_child;
  /// 子オブジェクトの形状
  std::vector<Shape> shape;
  /// オブジェクトのマージン
  double margin;
  /// 把持されているオブジェクト名
  std::string parent_name;
  /// 親からの相対姿勢
  Eigen::Affine3d parent_to_base;
  /// 把持されているグループ名
  std::string parent_group;
  /// Cuboidであるか
  bool cuboid;
};

/// @brief joint limitを定義
struct JointLimits {
  // joint name
  std::string joint_name;

  // true if the joint has position limits
  bool has_position_limits;

  // min position limits
  double min_position;
  // max position limits
  double max_position;

  // true if joint has velocity limits
  bool has_velocity_limits;

  // max velocity limit
  double max_velocity;
  // min_velocity is assumed to be -max_velocity

  // true if joint has acceleration limits
  bool has_acceleration_limits;
  // max acceleration limit
  double max_acceleration;
  // min_acceleration is assumed to be -max_acceleration

  // true if joint has effort limits
  bool has_effort_limits;
  // max effort limit
  double max_effort;
};

/// @brief ロボットの基準点に対する自由度の定義
/// Baseの動作に対するenum
enum BaseMovementType {
  kFloat,  /// 6自由度自由な浮遊リンク
  kPlanar,  /// 基準座標系のx-y-theataが自由な台車モデル
  kRailX,  /// 基準座標系のx軸に固定されたレール
  kRailY,  /// 基準座標系のy軸に固定されたレール
  kRailZ,  /// 基準座標系のz軸に固定されたレール
  kRotationX,  /// 基準座標系のx軸回転
  kRotationY,  /// 基準座標系のy軸回転
  kRotationZ,  /// 基準座標系のz軸回転
  kNone,
};

/// base_typeの自由度を取得
/// @param[in] base_type baseの自由度
/// @return baseの自由度
inline uint32_t GetBaseDof(tmc_manipulation_types::BaseMovementType base_type) {
  uint32_t base_dof = 0;
  switch (base_type) {
    case tmc_manipulation_types::kFloat:
      base_dof = 6;
      break;
    case tmc_manipulation_types::kPlanar:
      base_dof = 3;
      break;
    case tmc_manipulation_types::kRailX:
      base_dof = 1;
      break;
    case tmc_manipulation_types::kRailY:
      base_dof = 1;
      break;
    case tmc_manipulation_types::kRailZ:
      base_dof = 1;
      break;
    case tmc_manipulation_types::kRotationX:
      base_dof = 1;
      break;
    case tmc_manipulation_types::kRotationY:
      base_dof = 1;
      break;
    case tmc_manipulation_types::kRotationZ:
      base_dof = 1;
      break;
    case tmc_manipulation_types::kNone:
      base_dof = 0;
      break;
    default:
      base_dof = 0;
      break;
  }
  return base_dof;
}

inline uint32_t GetJointIndex(const tmc_manipulation_types::NameSeq& names,
                             const std::string& name) {
  tmc_manipulation_types::NameSeq::const_iterator it = std::find(names.begin(), names.end(), name);
  if (it != names.end()) {
    return std::distance(names.begin(), it);
  } else {
    return -1;
  }
}

inline void ExtractJointPos(
    const tmc_manipulation_types::JointState& joint_state,
    const tmc_manipulation_types::NameSeq& joint_names,
    Eigen::VectorXd& joint_pos_out) {
  joint_pos_out.resize(joint_names.size());
  for (tmc_manipulation_types::NameSeq::const_iterator joint_name = joint_names.begin();
       joint_name != joint_names.end();
       ++joint_name) {
    uint32_t in_index = GetJointIndex(joint_state.name, *joint_name);
    if (in_index == -1) {
      throw std::invalid_argument("Joint " + *joint_name + " is not found");
    }
    if (in_index >= joint_state.position.size()) {
      throw std::invalid_argument("invalid size pos");
    }
    uint32_t out_index = std::distance(joint_names.begin(), joint_name);
    joint_pos_out[out_index] = joint_state.position[in_index];
  }
}

inline void ExtractMultiJointPos(
    const tmc_manipulation_types::MultiDOFJointState& multi_dof_joint_state,
    const NameSeq& joint_names,
    PoseSeq& multi_dof_joint_pos_out) {
  multi_dof_joint_pos_out.resize(joint_names.size());
  for (tmc_manipulation_types::NameSeq::const_iterator joint_name = joint_names.begin();
       joint_name != joint_names.end();
       ++joint_name) {
    uint32_t in_index = GetJointIndex(multi_dof_joint_state.names, *joint_name);
    if (in_index == -1) {
      throw std::invalid_argument("Joint " + *joint_name + " is not found");
    }
    if (in_index >= multi_dof_joint_state.poses.size()) {
      throw std::invalid_argument("invalid size pos");
    }
    uint32_t out_index = std::distance(joint_names.begin(), joint_name);
    multi_dof_joint_pos_out[out_index] = multi_dof_joint_state.poses[in_index];
  }
}

}  // namespace tmc_manipulation_types


template <typename T> std::ostream& SeqOut(std::ostream& os, const T& seq) {
  for (typename T::const_iterator it = seq.begin();
       it != seq.end();
       ++it) {
    os << *it << " ";
  }
  return os;
}

template <typename T> std::ostream& SeqOutMatrix(std::ostream& os, const T& seq) {
  for (typename T::const_iterator it = seq.begin();
       it != seq.end();
       ++it) {
    os << '\n' << it->matrix() << '\n';
  }
  return os;
}

template <typename T> std::ostream& SeqOutTrans(std::ostream& os, const T& seq) {
  for (typename T::const_iterator it = seq.begin();
       it != seq.end();
       ++it) {
    os << it->transpose() << '\n';
  }
  return os;
}


inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::JointState& state) {
  os << "name: ";
  SeqOut(os, state.name);
  os << '\n';
  os << "poistion: " << state.position.transpose() << '\n';
  os << "velocity: " << state.velocity.transpose() << '\n';
  os << "effort: " << state.effort.transpose() << '\n';
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::TaskSpaceRegion& tsr) {
  os << "origin_to_tsr: \n" << tsr.origin_to_tsr.matrix() << '\n';
  os << "tsr_to_end: \n" << tsr.tsr_to_end.matrix() << '\n';
  os << "min_bounds: " << tsr.min_bounds.transpose() << '\n';
  os << "max_bounds: " << tsr.max_bounds.transpose() << '\n';
  os << "origin_frame_id: " << tsr.origin_frame_id << '\n';
  os << "end_frame_id: " << tsr.end_frame_id << '\n';
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::MultiDOFJointState& state) {
  os << "name: \n";
  SeqOut(os, state.names);
  os << '\n';
  os << "poses: \n";
  SeqOutMatrix(os, state.poses);
  os << "twist: \n";
  SeqOutTrans(os, state.twist);
  os << "wrench: \n";
  SeqOutTrans(os, state.wrench);
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::RobotState& state) {
  os << "joint_state: \n" << state.joint_state << '\n';
  os << "multi_dof_joint_state: \n" << state.multi_dof_joint_state << '\n';
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::TimedJointTrajectoryPoint& point) {
  os << "positions: " << point.positions.transpose() << '\n';
  os << "velocities: " << point.velocities.transpose() << '\n';
  os << "accelerations: " << point.accelerations.transpose() << '\n';
  os << "effort: " << point.effort.transpose() << '\n';
  os << "time_from_start: " << point.time_from_start << '\n';
  os << '\n';
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::TimedJointTrajectory& traj) {
  os << "joint_names: ";
  SeqOut(os, traj.joint_names);
  os << '\n';
  SeqOut(os, traj.points);
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::TimedMultiDOFJointTrajectoryPoint& point) {
  os << "transforms: ";
  SeqOutMatrix(os, point.transforms);
  os << "velocities: ";
  SeqOutTrans(os, point.velocities);
  os << "accelerations: ";
  SeqOutTrans(os, point.accelerations);
  os << "time_from_start: " << point.time_from_start << '\n';
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::TimedMultiDOFJointTrajectory& traj) {
  os << "joint_names: ";
  SeqOut(os, traj.joint_names);
  os << '\n';
  SeqOut(os, traj.points);
  return os;
}

inline std::ostream& operator<<(
    std::ostream& os,
    const tmc_manipulation_types::TimedRobotTrajectory& traj) {
  os << "joint_trajectory: " << traj.joint_trajectory;
  os << "multi_dof_joint_trajectory: " << traj.multi_dof_joint_trajectory;
  return os;
}

#endif  // TMC_MANIPULATION_TYPES_MANIPULATION_TYPES_HPP_
