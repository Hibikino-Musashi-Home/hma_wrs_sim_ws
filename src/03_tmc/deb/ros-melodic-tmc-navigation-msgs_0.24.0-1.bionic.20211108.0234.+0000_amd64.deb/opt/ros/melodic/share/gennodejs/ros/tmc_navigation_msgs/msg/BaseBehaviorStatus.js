// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BaseBehaviorStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_key = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('node_key')) {
        this.node_key = initObj.node_key
      }
      else {
        this.node_key = '';
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BaseBehaviorStatus
    // Serialize message field [node_key]
    bufferOffset = _serializer.string(obj.node_key, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BaseBehaviorStatus
    let len;
    let data = new BaseBehaviorStatus(null);
    // Deserialize message field [node_key]
    data.node_key = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.node_key.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_navigation_msgs/BaseBehaviorStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b26f7eedbe86dd0a27ae586bd59be0a5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    string node_key # the setting key of the node which subscribed "run"'s service
    
    uint32 status # the result param of the node which subscribed "run"'s service
    
    uint32 kNone                = 0 # enum for state. kNone is used as a default value.
    uint32 kNotReady            = 1 # enum for state
    uint32 kReached             = 2 # enum for state
    uint32 kGlobalPlanFail      = 3 # enum for state
    uint32 kLocalPlanFail       = 4 # enum for state
    uint32 kRetaskDeComposition = 5 # enum for state
    uint32 kFail                = 6 # enum for state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BaseBehaviorStatus(null);
    if (msg.node_key !== undefined) {
      resolved.node_key = msg.node_key;
    }
    else {
      resolved.node_key = ''
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
BaseBehaviorStatus.Constants = {
  KNONE: 0,
  KNOTREADY: 1,
  KREACHED: 2,
  KGLOBALPLANFAIL: 3,
  KLOCALPLANFAIL: 4,
  KRETASKDECOMPOSITION: 5,
  KFAIL: 6,
}

module.exports = BaseBehaviorStatus;
