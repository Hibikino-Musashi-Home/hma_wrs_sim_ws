// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class ReloadMapRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.new_map_yaml = null;
    }
    else {
      if (initObj.hasOwnProperty('new_map_yaml')) {
        this.new_map_yaml = initObj.new_map_yaml
      }
      else {
        this.new_map_yaml = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ReloadMapRequest
    // Serialize message field [new_map_yaml]
    bufferOffset = _serializer.string(obj.new_map_yaml, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ReloadMapRequest
    let len;
    let data = new ReloadMapRequest(null);
    // Deserialize message field [new_map_yaml]
    data.new_map_yaml = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.new_map_yaml.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/ReloadMapRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '535437e45df4181344324bab9bc9f1e8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Set New map config to grid_map_server
    
    # New map config file name (.yaml)
    string new_map_yaml
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ReloadMapRequest(null);
    if (msg.new_map_yaml !== undefined) {
      resolved.new_map_yaml = msg.new_map_yaml;
    }
    else {
      resolved.new_map_yaml = ''
    }

    return resolved;
    }
};

class ReloadMapResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_success = null;
    }
    else {
      if (initObj.hasOwnProperty('is_success')) {
        this.is_success = initObj.is_success
      }
      else {
        this.is_success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ReloadMapResponse
    // Serialize message field [is_success]
    bufferOffset = _serializer.bool(obj.is_success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ReloadMapResponse
    let len;
    let data = new ReloadMapResponse(null);
    // Deserialize message field [is_success]
    data.is_success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/ReloadMapResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fa3e942e5cfe76a6a46f20a0780b2cf3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # True if map is reloaded
    bool is_success
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ReloadMapResponse(null);
    if (msg.is_success !== undefined) {
      resolved.is_success = msg.is_success;
    }
    else {
      resolved.is_success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: ReloadMapRequest,
  Response: ReloadMapResponse,
  md5sum() { return '398edacd418a7441f2789d05b120f6d9'; },
  datatype() { return 'tmc_navigation_msgs/ReloadMap'; }
};
