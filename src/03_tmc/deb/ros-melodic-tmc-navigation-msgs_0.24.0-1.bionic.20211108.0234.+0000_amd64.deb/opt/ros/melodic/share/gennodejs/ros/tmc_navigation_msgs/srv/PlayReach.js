// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class PlayReachRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.reach_flag = null;
    }
    else {
      if (initObj.hasOwnProperty('reach_flag')) {
        this.reach_flag = initObj.reach_flag
      }
      else {
        this.reach_flag = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlayReachRequest
    // Serialize message field [reach_flag]
    bufferOffset = _serializer.bool(obj.reach_flag, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlayReachRequest
    let len;
    let data = new PlayReachRequest(null);
    // Deserialize message field [reach_flag]
    data.reach_flag = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/PlayReachRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'de038f602103d961c902eb6bc9547667';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    # comment (TODO)
    bool reach_flag
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlayReachRequest(null);
    if (msg.reach_flag !== undefined) {
      resolved.reach_flag = msg.reach_flag;
    }
    else {
      resolved.reach_flag = false
    }

    return resolved;
    }
};

class PlayReachResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PlayReachResponse
    // Serialize message field [result]
    bufferOffset = _serializer.bool(obj.result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PlayReachResponse
    let len;
    let data = new PlayReachResponse(null);
    // Deserialize message field [result]
    data.result = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/PlayReachResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eb13ac1f1354ccecb7941ee8fa2192e8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    # comment (TODO)
    bool result
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PlayReachResponse(null);
    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = false
    }

    return resolved;
    }
};

module.exports = {
  Request: PlayReachRequest,
  Response: PlayReachResponse,
  md5sum() { return '09a96e006db1e666eebd26f81027d0d8'; },
  datatype() { return 'tmc_navigation_msgs/PlayReach'; }
};
