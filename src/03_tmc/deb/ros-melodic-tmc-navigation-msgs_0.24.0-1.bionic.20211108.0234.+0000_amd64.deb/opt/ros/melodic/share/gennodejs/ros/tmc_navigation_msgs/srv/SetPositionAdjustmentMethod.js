// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetPositionAdjustmentMethodRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.adjust_precisely = null;
    }
    else {
      if (initObj.hasOwnProperty('adjust_precisely')) {
        this.adjust_precisely = initObj.adjust_precisely
      }
      else {
        this.adjust_precisely = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetPositionAdjustmentMethodRequest
    // Serialize message field [adjust_precisely]
    bufferOffset = _serializer.bool(obj.adjust_precisely, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetPositionAdjustmentMethodRequest
    let len;
    let data = new SetPositionAdjustmentMethodRequest(null);
    // Deserialize message field [adjust_precisely]
    data.adjust_precisely = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetPositionAdjustmentMethodRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1ee8475279c673bb3028a8968cc4ce32';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    # comment (TODO)
    bool adjust_precisely
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetPositionAdjustmentMethodRequest(null);
    if (msg.adjust_precisely !== undefined) {
      resolved.adjust_precisely = msg.adjust_precisely;
    }
    else {
      resolved.adjust_precisely = false
    }

    return resolved;
    }
};

class SetPositionAdjustmentMethodResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetPositionAdjustmentMethodResponse
    // Serialize message field [result]
    bufferOffset = _serializer.bool(obj.result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetPositionAdjustmentMethodResponse
    let len;
    let data = new SetPositionAdjustmentMethodResponse(null);
    // Deserialize message field [result]
    data.result = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetPositionAdjustmentMethodResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eb13ac1f1354ccecb7941ee8fa2192e8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # comment (TODO)
    bool result
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetPositionAdjustmentMethodResponse(null);
    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetPositionAdjustmentMethodRequest,
  Response: SetPositionAdjustmentMethodResponse,
  md5sum() { return '9835ee2a109ef20bf30867040df0f8d3'; },
  datatype() { return 'tmc_navigation_msgs/SetPositionAdjustmentMethod'; }
};
