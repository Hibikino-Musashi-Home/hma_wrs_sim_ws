// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetMovingDirectionModeRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.moving_direction_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('moving_direction_mode')) {
        this.moving_direction_mode = initObj.moving_direction_mode
      }
      else {
        this.moving_direction_mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetMovingDirectionModeRequest
    // Serialize message field [moving_direction_mode]
    bufferOffset = _serializer.int32(obj.moving_direction_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetMovingDirectionModeRequest
    let len;
    let data = new SetMovingDirectionModeRequest(null);
    // Deserialize message field [moving_direction_mode]
    data.moving_direction_mode = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetMovingDirectionModeRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a800af3d6cd2c6bf2a317b5e003c6076';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    # always move in direction of arm.
    int32 kDirectionOfArm = 0
    
    # follower node uniquely determines move direction. 
    int32 kAutoDirection = 1
    
    # always move in oppisite direciton of arm. 
    int32 kOppositeDirectionOfArm = 2
    
    # move in direction determined by local parameter of follower. 
    int32 kDefaultDirection = 3
    
    # mode select parameter. moving direciton of base change depending on mode
    int32 moving_direction_mode
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetMovingDirectionModeRequest(null);
    if (msg.moving_direction_mode !== undefined) {
      resolved.moving_direction_mode = msg.moving_direction_mode;
    }
    else {
      resolved.moving_direction_mode = 0
    }

    return resolved;
    }
};

// Constants for message
SetMovingDirectionModeRequest.Constants = {
  KDIRECTIONOFARM: 0,
  KAUTODIRECTION: 1,
  KOPPOSITEDIRECTIONOFARM: 2,
  KDEFAULTDIRECTION: 3,
}

class SetMovingDirectionModeResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetMovingDirectionModeResponse
    // Serialize message field [result]
    bufferOffset = _serializer.bool(obj.result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetMovingDirectionModeResponse
    let len;
    let data = new SetMovingDirectionModeResponse(null);
    // Deserialize message field [result]
    data.result = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetMovingDirectionModeResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eb13ac1f1354ccecb7941ee8fa2192e8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # result of this service.
    bool result
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetMovingDirectionModeResponse(null);
    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetMovingDirectionModeRequest,
  Response: SetMovingDirectionModeResponse,
  md5sum() { return 'd91b673e88d402595a9890fa8f048302'; },
  datatype() { return 'tmc_navigation_msgs/SetMovingDirectionMode'; }
};
