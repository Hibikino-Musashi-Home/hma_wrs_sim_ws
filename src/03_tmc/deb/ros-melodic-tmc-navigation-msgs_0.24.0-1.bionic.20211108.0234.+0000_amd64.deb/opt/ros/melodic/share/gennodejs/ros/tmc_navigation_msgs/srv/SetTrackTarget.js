// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetTrackTargetRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.track_target = null;
    }
    else {
      if (initObj.hasOwnProperty('track_target')) {
        this.track_target = initObj.track_target
      }
      else {
        this.track_target = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetTrackTargetRequest
    // Serialize message field [track_target]
    bufferOffset = std_msgs.msg.String.serialize(obj.track_target, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetTrackTargetRequest
    let len;
    let data = new SetTrackTargetRequest(null);
    // Deserialize message field [track_target]
    data.track_target = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.track_target);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetTrackTargetRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5339987bab31e9e7215cf3c93c32fe25';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/String track_target
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetTrackTargetRequest(null);
    if (msg.track_target !== undefined) {
      resolved.track_target = std_msgs.msg.String.Resolve(msg.track_target)
    }
    else {
      resolved.track_target = new std_msgs.msg.String()
    }

    return resolved;
    }
};

class SetTrackTargetResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetTrackTargetResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetTrackTargetResponse
    let len;
    let data = new SetTrackTargetResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetTrackTargetResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetTrackTargetResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: SetTrackTargetRequest,
  Response: SetTrackTargetResponse,
  md5sum() { return '5339987bab31e9e7215cf3c93c32fe25'; },
  datatype() { return 'tmc_navigation_msgs/SetTrackTarget'; }
};
