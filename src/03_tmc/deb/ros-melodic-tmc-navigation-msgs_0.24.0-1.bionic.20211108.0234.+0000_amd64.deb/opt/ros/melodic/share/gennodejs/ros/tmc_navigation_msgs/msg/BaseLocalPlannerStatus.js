// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BaseLocalPlannerStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_key = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('node_key')) {
        this.node_key = initObj.node_key
      }
      else {
        this.node_key = '';
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BaseLocalPlannerStatus
    // Serialize message field [node_key]
    bufferOffset = _serializer.string(obj.node_key, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BaseLocalPlannerStatus
    let len;
    let data = new BaseLocalPlannerStatus(null);
    // Deserialize message field [node_key]
    data.node_key = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.node_key.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_navigation_msgs/BaseLocalPlannerStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '78c571ca11025e79148826fea89d5fb3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # The internal status of base path planner.
    
    string node_key # The key of node which send goal to base path planner.
    
    uint32 status # The internal status of base path planner
    
    uint32 kNone         = 0 # No goal is received and waiting.
    uint32 kNotReady     = 1 # Not ready for receiving new goal.
    uint32 kReached      = 2 # Reached at goal and stopped path planning.
    uint32 kPlanned      = 3 # Succeeded in path planning and publishing path to goal.
    uint32 kNoPath       = 4 # Failed in path planning because planner could not plan path to goal.
    uint32 kInvalidStart = 5 # Failed in path planning because start point is in obstacle.
    uint32 kInvalidGoal  = 6 # Failed in path planning because goal point is in obstacle.
    uint32 kFail         = 7 # Failed in path planning because of other reasons.
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BaseLocalPlannerStatus(null);
    if (msg.node_key !== undefined) {
      resolved.node_key = msg.node_key;
    }
    else {
      resolved.node_key = ''
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
BaseLocalPlannerStatus.Constants = {
  KNONE: 0,
  KNOTREADY: 1,
  KREACHED: 2,
  KPLANNED: 3,
  KNOPATH: 4,
  KINVALIDSTART: 5,
  KINVALIDGOAL: 6,
  KFAIL: 7,
}

module.exports = BaseLocalPlannerStatus;
