// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class BaseFinish {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_finish = null;
      this.path_time = null;
    }
    else {
      if (initObj.hasOwnProperty('is_finish')) {
        this.is_finish = initObj.is_finish
      }
      else {
        this.is_finish = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('path_time')) {
        this.path_time = initObj.path_time
      }
      else {
        this.path_time = new std_msgs.msg.Time();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BaseFinish
    // Serialize message field [is_finish]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.is_finish, buffer, bufferOffset);
    // Serialize message field [path_time]
    bufferOffset = std_msgs.msg.Time.serialize(obj.path_time, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BaseFinish
    let len;
    let data = new BaseFinish(null);
    // Deserialize message field [is_finish]
    data.is_finish = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [path_time]
    data.path_time = std_msgs.msg.Time.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_navigation_msgs/BaseFinish';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7c819306b9235feda080138e7e4f1ccd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This message describe whether base path following is finished.
    
    # Whether base path following is fihished.
    std_msgs/Bool is_finish
    
    # The last local path updated time.
    std_msgs/Time path_time
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    ================================================================================
    MSG: std_msgs/Time
    time data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BaseFinish(null);
    if (msg.is_finish !== undefined) {
      resolved.is_finish = std_msgs.msg.Bool.Resolve(msg.is_finish)
    }
    else {
      resolved.is_finish = new std_msgs.msg.Bool()
    }

    if (msg.path_time !== undefined) {
      resolved.path_time = std_msgs.msg.Time.Resolve(msg.path_time)
    }
    else {
      resolved.path_time = new std_msgs.msg.Time()
    }

    return resolved;
    }
};

module.exports = BaseFinish;
