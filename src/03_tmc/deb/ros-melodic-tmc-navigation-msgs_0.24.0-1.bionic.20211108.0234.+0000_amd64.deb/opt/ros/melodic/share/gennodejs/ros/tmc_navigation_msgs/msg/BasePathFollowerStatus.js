// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class BasePathFollowerStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_finish = null;
      this.path_time = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('is_finish')) {
        this.is_finish = initObj.is_finish
      }
      else {
        this.is_finish = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('path_time')) {
        this.path_time = initObj.path_time
      }
      else {
        this.path_time = new std_msgs.msg.Time();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BasePathFollowerStatus
    // Serialize message field [is_finish]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.is_finish, buffer, bufferOffset);
    // Serialize message field [path_time]
    bufferOffset = std_msgs.msg.Time.serialize(obj.path_time, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BasePathFollowerStatus
    let len;
    let data = new BasePathFollowerStatus(null);
    // Deserialize message field [is_finish]
    data.is_finish = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [path_time]
    data.path_time = std_msgs.msg.Time.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_navigation_msgs/BasePathFollowerStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b415d4db6efdd43fff400e99fb0377f5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # this is dummy status file
    
    std_msgs/Bool is_finish  # comment (TODO)
    std_msgs/Time path_time  # comment (TODO)
    uint32 status            # comment (TODO)
    
    uint32 kNone         = 0 # enum for state. kNone is used as a default value.
    uint32 kNotReady     = 1 # enum for state
    uint32 kReached      = 2 # enum for state
    uint32 kPlanned      = 3 # enum for state
    uint32 kNoPath       = 4 # enum for state
    uint32 kInvalidStart = 5 # enum for state
    uint32 kInvalidGoal  = 6 # enum for state
    uint32 kFail         = 7 # enum for state
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    ================================================================================
    MSG: std_msgs/Time
    time data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BasePathFollowerStatus(null);
    if (msg.is_finish !== undefined) {
      resolved.is_finish = std_msgs.msg.Bool.Resolve(msg.is_finish)
    }
    else {
      resolved.is_finish = new std_msgs.msg.Bool()
    }

    if (msg.path_time !== undefined) {
      resolved.path_time = std_msgs.msg.Time.Resolve(msg.path_time)
    }
    else {
      resolved.path_time = new std_msgs.msg.Time()
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
BasePathFollowerStatus.Constants = {
  KNONE: 0,
  KNOTREADY: 1,
  KREACHED: 2,
  KPLANNED: 3,
  KNOPATH: 4,
  KINVALIDSTART: 5,
  KINVALIDGOAL: 6,
  KFAIL: 7,
}

module.exports = BasePathFollowerStatus;
