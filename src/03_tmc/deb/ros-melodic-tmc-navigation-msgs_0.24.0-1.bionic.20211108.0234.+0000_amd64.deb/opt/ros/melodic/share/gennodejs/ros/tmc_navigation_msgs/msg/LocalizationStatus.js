// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LocalizationStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LocalizationStatus
    // Serialize message field [status]
    bufferOffset = _serializer.uint32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LocalizationStatus
    let len;
    let data = new LocalizationStatus(null);
    // Deserialize message field [status]
    data.status = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_navigation_msgs/LocalizationStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b03f850f5e2964fb22183bc9d994a0ea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    uint32 status # the result param of the node which subscribed "run"'s service
    
    uint32 kLocalized           = 0 # Well localized.
    uint32 kAmbiguous           = 1 # Localized but confidence is low.
    uint32 kGotLost             = 2 # Got lost due to low confidence.
    uint32 kRecoveringPose      = 3 # Try to restore correct pose.
    uint32 kGotLostCompletely   = 4 # Cannot restore the pose.
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LocalizationStatus(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
LocalizationStatus.Constants = {
  KLOCALIZED: 0,
  KAMBIGUOUS: 1,
  KGOTLOST: 2,
  KRECOVERINGPOSE: 3,
  KGOTLOSTCOMPLETELY: 4,
}

module.exports = LocalizationStatus;
