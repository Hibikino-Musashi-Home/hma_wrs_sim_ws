// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class FunctionSwitchRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.function_switch = null;
    }
    else {
      if (initObj.hasOwnProperty('function_switch')) {
        this.function_switch = initObj.function_switch
      }
      else {
        this.function_switch = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FunctionSwitchRequest
    // Serialize message field [function_switch]
    bufferOffset = _serializer.bool(obj.function_switch, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FunctionSwitchRequest
    let len;
    let data = new FunctionSwitchRequest(null);
    // Deserialize message field [function_switch]
    data.function_switch = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/FunctionSwitchRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bb83d17ea9e1ddb7cd3de08449fdbb47';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    # function On/OFF switch
    bool function_switch
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FunctionSwitchRequest(null);
    if (msg.function_switch !== undefined) {
      resolved.function_switch = msg.function_switch;
    }
    else {
      resolved.function_switch = false
    }

    return resolved;
    }
};

class FunctionSwitchResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FunctionSwitchResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FunctionSwitchResponse
    let len;
    let data = new FunctionSwitchResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/FunctionSwitchResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # response nothing
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FunctionSwitchResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: FunctionSwitchRequest,
  Response: FunctionSwitchResponse,
  md5sum() { return 'bb83d17ea9e1ddb7cd3de08449fdbb47'; },
  datatype() { return 'tmc_navigation_msgs/FunctionSwitch'; }
};
