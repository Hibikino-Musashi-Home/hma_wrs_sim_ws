// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetNoiseFilterParamRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.radius_search = null;
      this.min_neighbors = null;
    }
    else {
      if (initObj.hasOwnProperty('radius_search')) {
        this.radius_search = initObj.radius_search
      }
      else {
        this.radius_search = 0.0;
      }
      if (initObj.hasOwnProperty('min_neighbors')) {
        this.min_neighbors = initObj.min_neighbors
      }
      else {
        this.min_neighbors = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetNoiseFilterParamRequest
    // Serialize message field [radius_search]
    bufferOffset = _serializer.float64(obj.radius_search, buffer, bufferOffset);
    // Serialize message field [min_neighbors]
    bufferOffset = _serializer.int32(obj.min_neighbors, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetNoiseFilterParamRequest
    let len;
    let data = new SetNoiseFilterParamRequest(null);
    // Deserialize message field [radius_search]
    data.radius_search = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [min_neighbors]
    data.min_neighbors = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetNoiseFilterParamRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '93831fc43b21b7e2ec3b8a28f8b680e7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # The user specifies a number of neighbors which every indices must have
    # within a specified radius to remain in the PointCloud.
    
    # comment (TODO)
    float64 radius_search
    
    # minimum neighbors
    int32 min_neighbors
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetNoiseFilterParamRequest(null);
    if (msg.radius_search !== undefined) {
      resolved.radius_search = msg.radius_search;
    }
    else {
      resolved.radius_search = 0.0
    }

    if (msg.min_neighbors !== undefined) {
      resolved.min_neighbors = msg.min_neighbors;
    }
    else {
      resolved.min_neighbors = 0
    }

    return resolved;
    }
};

class SetNoiseFilterParamResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetNoiseFilterParamResponse
    // Serialize message field [result]
    bufferOffset = _serializer.bool(obj.result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetNoiseFilterParamResponse
    let len;
    let data = new SetNoiseFilterParamResponse(null);
    // Deserialize message field [result]
    data.result = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tmc_navigation_msgs/SetNoiseFilterParamResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eb13ac1f1354ccecb7941ee8fa2192e8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # result of this service.
    bool result
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetNoiseFilterParamResponse(null);
    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SetNoiseFilterParamRequest,
  Response: SetNoiseFilterParamResponse,
  md5sum() { return 'a19ad57243ab0ddbda6bbc761dc2a3df'; },
  datatype() { return 'tmc_navigation_msgs/SetNoiseFilterParam'; }
};
