// Auto-generated. Do not edit!

// (in-package tmc_navigation_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BaseBehaviorState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_key = null;
      this.state = null;
    }
    else {
      if (initObj.hasOwnProperty('node_key')) {
        this.node_key = initObj.node_key
      }
      else {
        this.node_key = '';
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BaseBehaviorState
    // Serialize message field [node_key]
    bufferOffset = _serializer.string(obj.node_key, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = _serializer.uint32(obj.state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BaseBehaviorState
    let len;
    let data = new BaseBehaviorState(null);
    // Deserialize message field [node_key]
    data.node_key = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.node_key.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tmc_navigation_msgs/BaseBehaviorState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6c3bffab192ebe6d591b636a5fb3dffd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Summary(TODO)
    
    string node_key                 # comment (TODO)
    uint32 state                    # comment (TODO)
    
    uint32 kInit                = 0 # enum for state. kInit is used as a default value.
    uint32 kStopped             = 1 # enum for state.
    uint32 kSettingGoal         = 2 # enum for state.
    uint32 kRunning             = 3 # enum for state.
    uint32 kRetrying            = 4 # enum for state.
    uint32 kPaused              = 5 # enum for state.
    uint32 kCanceled            = 6 # enum for state.
    uint32 kReached             = 7 # enum for state.
    uint32 kWaitingForRecovery  = 8 # enum for state.
    uint32 kEmergencyStopping   = 9 # enum for state.
    uint32 kFailed              = 10 # enum for state.
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BaseBehaviorState(null);
    if (msg.node_key !== undefined) {
      resolved.node_key = msg.node_key;
    }
    else {
      resolved.node_key = ''
    }

    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    return resolved;
    }
};

// Constants for message
BaseBehaviorState.Constants = {
  KINIT: 0,
  KSTOPPED: 1,
  KSETTINGGOAL: 2,
  KRUNNING: 3,
  KRETRYING: 4,
  KPAUSED: 5,
  KCANCELED: 6,
  KREACHED: 7,
  KWAITINGFORRECOVERY: 8,
  KEMERGENCYSTOPPING: 9,
  KFAILED: 10,
}

module.exports = BaseBehaviorState;
