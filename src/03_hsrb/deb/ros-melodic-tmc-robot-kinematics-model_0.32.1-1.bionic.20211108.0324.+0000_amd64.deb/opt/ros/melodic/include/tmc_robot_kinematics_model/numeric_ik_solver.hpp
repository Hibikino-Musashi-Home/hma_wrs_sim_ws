/// @file     numeric_ik_sover.hpp
/// @brief    数値解のikのsolver
/// @author   Koji Terada
/// @version  1.0.0
/// @date     2012.2.28
/// @brief    Copyright (C) 2012 Toyota Motor Corporation
/// @note     [1.0.0] 2012.2.28 Newly created

#ifndef ROBOT_KINEMATICS_MODEL_NUMERIC_IK_SOLVER_HPP__
#define ROBOT_KINEMATICS_MODEL_NUMERIC_IK_SOLVER_HPP__

#include <string>

#include <tmc_robot_kinematics_model/ik_solver.hpp>
#include <tmc_robot_kinematics_model/robot_kinematics_model.hpp>

namespace tmc_robot_kinematics_model {

class NumericIKSolver : public IKSolver {
 public:
  /// @param [in] successor Nextで次に渡したい場合のIK
  /// @param [in] robot_model ロボットモデル
  /// @param [in] max_itr 最大繰り返し回数
  /// @param [in] epsilon 目標値との誤差がこれ以下となったら解とみなす
  /// @param [in] converge_threshold 繰り替えしごとの変化量がこれ以下になったら収束とみなす
  NumericIKSolver(IKSolver::Ptr successor,
                  IRobotKinematicsModel::Ptr robot_model,
                  uint32_t max_itr,
                  double epsilon,
                  double converge_threshold)
      : IKSolver(successor), robot_model_(robot_model) , max_itr_(max_itr),
        epsilon_(epsilon), converge_threshold_(converge_threshold) {}
  virtual ~NumericIKSolver() {}
  virtual IKResult Solve(
      const IKRequest& request,
      tmc_manipulation_types::JointState& solution_angle_out,
      Eigen::Affine3d& origin_to_end_out);

  virtual IKResult Solve(
      const IKRequest& request,
      tmc_manipulation_types::JointState& solution_angle_out,
      Eigen::Affine3d& origin_to_base_out,
      Eigen::Affine3d& origin_to_end_out);

 private:
  IRobotKinematicsModel::Ptr robot_model_;
  uint32_t max_itr_;
  double epsilon_;
  double converge_threshold_;
};
}  // namespace tmc_robot_kinematics_model

#ifdef __cplusplus
extern "C" {
#endif  // __cplusplus
// wrapper functions for ctypes
  void* create_solver(void*, int, float, float);
  void* create_request(tmc_manipulation_types::BaseMovementType);
  void* jointstate();
  void* affine3d();
  void set_req_frame_name(void*, char*);
  void set_req_initial_angle_name(void*, char*[], int);
  void set_req_frame_to_end(void*, double*);
  void set_req_origin_to_base(void*, double*);
  void set_req_initial_angle_position(void*, float[], int);
  void set_req_weight(void*, float[], int);
  void set_req_ref_origin_to_end(void*, double*);
  void solve(void*, void*, void*, void*, void*);
  void get_joint_angle(void*, float*, int);
  void get_origin_to_base(void*, double*);
#ifdef __cplusplus
}
#endif  // __cplusplus

#endif
