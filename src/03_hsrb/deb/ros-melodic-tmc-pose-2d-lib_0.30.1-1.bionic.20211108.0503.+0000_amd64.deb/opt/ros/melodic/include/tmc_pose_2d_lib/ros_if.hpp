// Copyright (C) 2020 Toyota Motor Corporation
#ifndef TMC_POSE_2D_LIB_ROS_IF_HPP_
#define TMC_POSE_2D_LIB_ROS_IF_HPP_

#include <string>
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/TransformStamped.h>
#include <nav_msgs/OccupancyGrid.h>
#include <tmc_navigation_msgs/OccupancyGridUint.h>
#include "tmc_pose_2d_lib/distance_map.hpp"
#include "tmc_pose_2d_lib/pose_2d.hpp"

namespace tmc_pose_2d_lib {

DistanceMap RosMsg2DistanceMap(const tmc_navigation_msgs::OccupancyGridUint& msg);
DistanceMap RosMsg2DistanceMap(const nav_msgs::OccupancyGrid& msg);

Pose2d GetPose2dFromRosMsg(const geometry_msgs::PoseWithCovarianceStamped& msg);
Pose2d GetPose2dFromRosMsg(const geometry_msgs::TransformStamped& msg);
Pose2d GetPose2dFromRosMsg(const geometry_msgs::Pose& msg);
Pose2d GetPose2dFromRosMsg(const geometry_msgs::PoseStamped& msg);

geometry_msgs::Pose GetPoseMsg(const Pose2d& pose);
geometry_msgs::PoseStamped GetPoseStamped(const Pose2d& pose, const double& time, const std::string frame_id);
geometry_msgs::PoseWithCovarianceStamped GetPoseWithCovarianceStamped(
  const Pose2d& pose, const double& time, const std::string frame_id);

}  // namespace tmc_pose_2d_lib

#endif  // TMC_POSE_2D_LIB_ROS_IF_HPP_
