// Copyright (C) 2020 Toyota Motor Corporation
#ifndef TMC_POSE_2D_LIB_DISTANCE_MAP_HPP_
#define TMC_POSE_2D_LIB_DISTANCE_MAP_HPP_

#include <math.h>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include "tmc_pose_2d_lib/pose_2d.hpp"

namespace {
// FreeまたはUnexploredを表す定数
const uint8_t kFreeOrUnexplored = 1;
};

namespace tmc_pose_2d_lib {

/// Distance地図データ
class DistanceMap {
 public:
  // コンストラクタ
  DistanceMap(
    Pose2d origin_map_image,
    double resolution,
    size_t width,
    size_t height,
    std::vector<unsigned char> data);


  enum CellType {
    kOutside = 0,
    kUnExplored,
    kFree,
    kHasDistance,
  };

  /// getter
  double resolution() const {return resolution_;}
  size_t width() const {return width_;}
  size_t height() const {return height_;}
  size_t min_u() const {return min_u_;}
  size_t min_v() const {return min_v_;}
  size_t max_u() const {return max_u_;}
  size_t max_v() const {return max_v_;}


  /// setter
  void SetPotentialWidth(double potential_width) {
    potential_width_ = potential_width;
  }
  /// @brief 地図データ値を設定
  bool SetValueAt(const size_t index_u, const size_t index_v, const unsigned char value);
  /// @brief 地図データ値を取得
  bool GetValueAt(const size_t index_u, const size_t index_v, unsigned char& value) const;
  /// @brief image座標系での値から、map座標系での座標値を取得
  bool GetMapPoint(const size_t index_u, const size_t index_v, Point2d& point_map) const;
  /// @brief map座標系の指定した2D点が、地図データ範囲内かどうか判定
  bool InMap(const Point2d& p_map) const;
  /// @brief 指定したマップ座標点の位置の画像データのTypeを調べ、有効な距離が入っている場合はその値を返す
  void CheckTypeAndDistance(const Point2d& p_map, DistanceMap::CellType& type, double& distance) const;
  /// @brief 障害物があるエリアを確認する
  void CalcOccupiedRegion();
  /// @brief image座標系からmap座標系へ座標変換
  void ImageToMap(Pose2d& pose);
  /// @brief map座標系からimage座標系へ座標変換
  void MapToImage(Pose2d& pose);

 private:
  /// map->image座標系 image座標系からmap座標系への変換
  Pose2d origin_map_image_;
  /// map->image座標系 image座標系からmap座標系への逆変換
  Pose2d origin_map_image_inverse_;
  /// グリッドサイズ(m)
  double resolution_;
  /// 地図の幅(グリッド数)
  size_t width_;
  /// 地図の高さ(グリッド数)
  size_t height_;

  /// @brief 地図データ
  std::vector<unsigned char> data_;

  /// 占有、非専有のしきい値
  // (255-data)を正規化して、potential_widthをかけるとそのセルにおける物体までの最短距離になる
  double potential_width_;

  // ポテンシャル値が存在するインデックスの範囲
  size_t min_u_;
  size_t min_v_;
  size_t max_u_;
  size_t max_v_;

  /// @brief map座標系の指定した2D点の、image座標系での値を取得
  bool CheckIndices(const Point2d& p_map, size_t& index_u, size_t& index_v) const;
  bool CheckIndexArea(const size_t index_u, const size_t index_v) const;

  bool IsValid() const;
};

}  // namespace tmc_pose_2d_lib

#endif  // TMC_POSE_2D_LIB_DISTANCE_MAP_HPP_
