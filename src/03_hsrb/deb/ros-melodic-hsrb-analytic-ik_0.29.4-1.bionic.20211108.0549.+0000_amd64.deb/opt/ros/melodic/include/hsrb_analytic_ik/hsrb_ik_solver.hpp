/// @brief HSR-B向けの高速IK
/// @brief Copyright (C) 2015 Toyota Motor Corporation
#ifndef HSRB_ANALYTIC_IK_HSRB_IK_SOLVER_HPP_
#define HSRB_ANALYTIC_IK_HSRB_IK_SOLVER_HPP_

#include <string>

#include <tmc_robot_kinematics_model/ik_solver.hpp>
#include <tmc_robot_kinematics_model/robot_kinematics_model.hpp>

namespace hsrb_analytic_ik {

class HsrbIKSolver : public tmc_robot_kinematics_model::IKSolver {
 public:
  HsrbIKSolver() {}
  /// @param [IN] successor Nextで次に渡したい場合のIK
  /// @param [IN] 初期化に必要なものは追加してください．
  explicit HsrbIKSolver(tmc_robot_kinematics_model::IKSolver::Ptr successor) :
      IKSolver(successor) {}
  virtual ~HsrbIKSolver() {}

  /// IKを解く
  /// @param [IN] request: IKの入力
  /// @param [OUT] solution_angle_out: 解姿勢
  /// @param [OUT] 解の姿勢
  virtual tmc_robot_kinematics_model::IKResult Solve(
      const tmc_robot_kinematics_model::IKRequest& request,
      tmc_manipulation_types::JointState& solution_angle_out,
      Eigen::Affine3d& origin_to_end_out);

  /// IKを解く ただしbaseの移動も許可する
  /// @param [IN] request 目標手先位置や初期値など
  /// @param [OUT] solution_angle_out アームの関節角度の解
  /// @param [OUt] origin_to_base_out 台車部分の解
  /// @param [OUT] origin_to_end_out  解の手先位置．目標手先位置にほぼ一致するはず
  /// @retval kSuccess 成功
  /// @retval kConverge 解でないところに収束
  /// @retval kMaxItr 最大繰り返し回数に到達
  /// @retval kFail 失敗．解なし．
  virtual tmc_robot_kinematics_model::IKResult Solve(
      const tmc_robot_kinematics_model::IKRequest& request,
      tmc_manipulation_types::JointState& solution_angle_out,
      Eigen::Affine3d& origin_to_base_out,
      Eigen::Affine3d& origin_to_end_out);
};

}  // namespace hsrb_analytic_ik
#endif  // HSRB_ANALYTIC_IK_HSRB_IK_SOLVER_HPP_
